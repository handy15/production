/**
 * Created by wangyaru on 2016/5/12.
 * 公共方法
 */
//HTML页面：初始化参数
var initParams = {
    // 页面fr参数值，此配置说明显示H5自定义header的参数值汇总。配置如："spick,spi,test"
    "showMyHeader": "",
    // 手机分辨率：宽度
    "phoneWidth": window.screen.width,
    // 手机分辨率：高度
    "phoneHeight": window.screen.height,
    // 浏览器窗口的宽度
    "clientWidth": document.documentElement.clientWidth,
    // 浏览器窗口的高度
    "clientHeight": document.documentElement.clientHeight,
    // 手机操作系统
    "phoneAllSys": ["android", "ios"],
    // 当前手机操作系统
    "currentPhoneSys": ""
};
//判断手机类型
var browser = {
    versions: function() {
        var u = navigator.userAgent, app = navigator.appVersion;
        return {//移动终端浏览器版本信息
            trident: u.indexOf('Trident') > -1, //IE内核
            presto: u.indexOf('Presto') > -1, //opera内核
            webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
            gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
            mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/), //是否为移动终端
            ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
            android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或者uc浏览器
            iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, //是否为iPhone或者QQHD浏览器
            iPad: u.indexOf('iPad') > -1, //是否iPad
            webApp: u.indexOf('Safari') == -1 //是否web应该程序，没有头部与底部
        };
    }(),
}
function judgePhoneSysType() {
    if (browser.versions.ios || browser.versions.iPhone || browser.versions.iPad) {
        return "ios";
    }
    else if (browser.versions.android) {
        return "android";
    } else {
        return "";
    }
// document.writeln(" 是否为移动终端: " + browser.versions.mobile);
// document.writeln(" ios终端: " + browser.versions.ios);
// document.writeln(" android终端: " + browser.versions.android);
// document.writeln(" 是否为iPhone: " + browser.versions.iPhone);
// document.writeln(" 是否iPad: " + browser.versions.iPad);
// document.writeln(navigator.userAgent);
}
// 初始化定义手机类型
initParams.currentPhoneSys = judgePhoneSysType();

var guangfu = guangfu || {};
$.extend(guangfu,{
    // 判断底部的按钮是否处于页面的底部
    judgePageHeight: function () {
        var clientH = initParams.clientHeight;
        var htmlH = $("html").height();//alert(clientH + ',' + htmlH);
        if( htmlH<clientH ) {
            var $btm = $('.btm').eq(0);
            if($btm.length && $btm.is(':visible')){
                $btm.addClass('btm-absolute');
            }
        }
    },
    /**
     * 表单提交中，多选项目，隐藏域赋值，eg:服务类型
     * 隐藏域的value值格式：1,5,69,60
     * @param $this jquery object
     * @param $obj jquery object input隐藏域
     */
    multipleSelected: function($this,$obj){
        var thisValue = $this.attr('value');
        var $input = $obj;
        var inputValue = $input.val();
        if( $this.hasClass("selected") ) {
            $this.removeClass("selected");
            var reg = new RegExp(',' + thisValue+',|,'+thisValue+'$'+'|^'+thisValue+'(,|$)','g');
            inputValue = inputValue.replace(reg,',');
            inputValue = inputValue.replace(/,*$|^,*/g,'');
        } else {
            $this.addClass("selected");
            if('' != inputValue){
                inputValue += ',';
            }
            inputValue += thisValue;
        }
        $input.val(inputValue);
    },
    /**
     * ios中弹出键盘，fixed失效的问题
     * @param $inputs jquery object,能弹出键盘的表单元素
     */
    iosFixed: function($inputs){
        if(initParams.currentPhoneSys == 'ios'){
            //站位符
            var $blank = $('.blank-place');
            //底部悬浮
            var $fixed = $('.btm');
            $inputs.focus(function(){
                $blank.hide();
                //设置按钮在最底层
                if($fixed.length && $fixed.is(':visible')){
                    $fixed.addClass('btm-static');
                }
            }).blur(function(){
                $blank.show();
                if($fixed.length && $fixed.is(':visible')){
                    $fixed.removeClass('btm-static');
                }
            });
        }
    },
    /**
     * 光标定位到input末尾
     * @param obj dom元素
     */
    cursorToEnd: function(obj){
        var len = obj.value.length;
        if (document.selection) {
            var sel = obj.createTextRange();
            sel.moveStart('character', len);
            sel.collapse();
            sel.select();
        } else if (typeof obj.selectionStart == 'number'
            && typeof obj.selectionEnd == 'number') {
            obj.selectionStart = obj.selectionEnd = len;
        }
    }
});

/**
 * Created by wangyaru on 2016/5/13.
 * 插件：select转为片段展示，点击单选
 */
(function( $ ){
    $.fn.extend({
        Segment: function ( ) {
            $(this).each(function (){
                var self = $(this);
                var wrapper = $("<div>",{'class': "ui-segment"});
                $(this).find("option").each(function (){
                    var option = $("<span>",{'class': 'option','text': $(this).text(),'value': $(this).val()});
                    if ($(this).is(":selected")){
                        option.addClass("active");
                    }
                    wrapper.append(option);
                });
                wrapper.find("span.option").click(function (){
                    wrapper.find("span.option").removeClass("active");
                    $(this).addClass("active");
                    self.val($(this).attr('value'));
                });
                $(this).after(wrapper);
                $(this).hide();
            });
        }
    });
})(jQuery);