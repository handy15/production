
/**
 * 左侧导航 选择样式处理
 */
$('.nav-stacked li').each(function(key,val){
    var preg = $(this).attr('preData');
    if(preg){
        var pattern = ZwzCommonOp.obj_url.parseURL().relative.toLowerCase();
        // console.log(preg);
        // console.log(pattern);
        if(pattern.match(eval(preg))) {
            //if(eval(preg).test(pattern)) {
            $(this).addClass('current');
        }
    }
});