/**
 * 登记项目相关js
 * @param content
 */

//弹层信息处理
function alertMsg(content){
    spi.showBoxAlert({
        width:250,  //弹出框宽度
        height:100,  //弹出框高度
        msg:content, //提示信息，可以是html
        afterConfirm: function(){  //点击“确定”关闭窗口后的回调函数
            $('#click').text('click again!');
        }
    });
}



/**
*登记项目流程编辑 js代码
*/
//图片批量上传
var uploader = new plupload.Uploader({//创建实例的构造方法
    runtimes: 'html5,flash,silverlight,html4', //上传插件初始化选用那种方式的优先级顺序
    browse_button: 'construction_certificate', // 上传按钮
    url: "/image/upload", //远程上传地址
    flash_swf_url: 'plupload/Moxie.swf', //flash文件地址
    silverlight_xap_url: 'plupload/Moxie.xap', //silverlight文件地址
    filters: {
        max_file_size: '2mb', //最大上传文件大小（格式100b, 10kb, 10mb, 1gb）
        mime_types: [//允许文件上传类型
            {title: "files", extensions: "jpg,png,gif"}
        ]
    },
    multi_selection: true, //true:ctrl多文件上传, false 单文件上传
    init: {
        FilesAdded: function(up, files) { //文件上传前
            if ($(".File").children("div.engineering_consulting_service").length > 50) {
                alert("您上传的图片太多了！");
                uploader.destroy();
            } else {
                var div = '';
                plupload.each(files, function(file) { //遍历文件
                    div += ' <div id="' + file['id'] + '"  class="engineering_consulting">\
                                    <span class="FileSpan">&times;</span>\
                                    <div class="progress"><span class="bar"></span><span class="percent">0%</span></div>\
                                </div>';
                });
                $(".construction_certificate").before(div);
                uploader.start();
            }
        },
        UploadProgress: function(up, file) { //上传中，显示进度条
            var percent = file.percent;
            $("#" + file.id).find('.bar').css({"width": percent + "%"});
            $("#" + file.id).find(".percent").text(percent + "%");
        },
        FileUploaded: function(up, file, info) { //文件上传成功的时候触发
            var data = eval("(" + info.response + ")");
            $("#" + file.id).html(
                '<span class="FileSpan" onclick="delImg(this)" >&times;</span>' +
                    '<img class="SellImg" src="'+data.data.url+'"/>' +
                    '<input type="hidden" name="image_path[]" value="'+data.data.path+'">'
            );
        },
        Error: function(up, err) { //上传出错的时候触发
            alert(err.message);
        }
    }
});
uploader.init();


/**
 * ajax form提交
 */
$(function() {
    $('#project_from').ajaxForm({
        url : '/project/save',
        type : 'post',
        dataType : 'json',
        beforeSerialize:function(){
            /**
             * 处理复选框的值，beforsubmit里面 提交不上值 @bug
             * @type {string}
             */
            checkBoxValue();
        },
        beforeSubmit : function() {
            // 验证处理
            var checked = true;
            var project_name = $('input[name=project_name]').val();
            var project_proportion = $('input[name=project_proportion]').val();
            var project_desc = $('#project_desc').val();
            var project_address = $('input[name=project_address]').val();
            var project_built_date = $('input[name=project_built_date]').val();
            var project_area_proportion = $('#project_area_proportion').val();

            if(project_name == ''){
                $('input[name=project_name]').css('border','1px solid red').focus();
                checked = false;
            }

            if(project_proportion == ''){
                $('input[name=project_proportion]').css('border','1px solid red').focus();
                checked = false;
            }

            if($('#project_category_value').val() == ''){
                $('input[name=project_category]').focus();
            }

            if(project_desc == '' ){
                $('#project_desc').css('border','1px solid red').focus();
                checked = false;
            }

            if(project_address == ''){
                $('input[name=project_address]').css('border','1px solid red').focus();
                checked = false;
            }

            if(project_built_date == ''){
                $('input[name=project_built_date]').css('border','1px solid red').focus();
                checked = false;
            }

            if(project_area_proportion == ''){
                $('#project_area_proportion').css('border','1px solid red').focus();
                checked = false;
            }
            return checked;
        },
        success : function(data) {
            if (data.code == '2000') {
                window.location.href='/project/success';
            } else {
                alertMsg(data.msg);
            }
            //  $('input[type=submit]').removeAttr('disabled');
        },
        error : function() {
        }
    });
});


/**
 * 删除图片
 * @param obj
 */
function delImg(obj){
    $(obj).parent().remove();
}

//预计投资额度计算
$('#info_install_mw').bind('input propertychange', function() {
    var info_install_mw_value = $(this).val();
    /**if(!/^[0-9]+(.[0-9]{1,2})?$/.test(info_install_mw_value)){
            spi.showBoxAlert({
                width:250,  //弹出框宽度
                height:100,  //弹出框高度
                msg:'请输入正取数据', //提示信息，可以是html
                afterConfirm: function(){  //点击“确定”关闭窗口后的回调函数
                    $('#click').text('click again!');
                }
            });
            return false;
        }
     */
    if(info_install_mw_value != ''){
        var info_invest_quota_value = info_install_mw_value * 1000 * 8.5
        $('#info_invest_quota').val(info_invest_quota_value);
    }
});

/**
 * 保存草稿操作
 */
$('#dosubmit').click(function(){
    checkBoxValue();
    $.ajax({
        type:'post',
        url:'/project/saveTest',
        data:$('#project_from').serialize(),
        dataType:'json',
        success:function(data){
            if(data.code == '2000') {
                alertMsg('已保存！');
                $('input[name=info_id]').val(data.data.info_id);
                $('input[name=project_id]').val(data.data.project_id);
                //window.location.reload();
            }else{
                alertMsg(data.msg);
            }
        }
    });
});


//复选框的值处理
function checkBoxValue(){
    var project_category_string = '';
    $("input[name='project_category']:checked").each(function () {
        project_category_string += $(this).val()+',';
    });
    $('#project_category_value').val(project_category_string);
}


//获取区域节点
function getAreaNodeDetail(parentId,regionType,htmlId,inputName,checkValue){
    if(parentId){
        $.ajax({
            type:'post',
            url:'/project/getarea',
            data:{parentId:parentId,regionType:regionType,random:Math.round((Math.random()) * 100000000)},
            dataType:'json',
            success:function(data){
                if(data.code == '2000') {
                    var onchangeEvent = '';
                    if(regionType == 2){
                        onchangeEvent = 'onchange="getAreaNodeDetail(this.value,3,\'countyNode\',\'project_county_id\')"';
                    }
                    var htmlContent = ' <select class="sel ml10px" name="'+inputName+'" '+onchangeEvent+' >';
                    htmlContent += '<option value="0">请选择</option>';
                    $(data.data).each(function(key,val){
                        var defaultCheck = '';
                        if(val.region_id == checkValue){
                            defaultCheck = 'selected="selected"';
                        }
                        htmlContent += '<option value="'+val.region_id+'"  '+defaultCheck+' >'+val.region_name+'</option>';
                    });
                    htmlContent += '</select>';
                    $('#'+htmlId).html(htmlContent);
                }
            }
        });
    }
}