/**
 * Created by wangyaru on 2016/3/11.
 * summary: the javascript for channel page(eg. design.html etc).
 */
var channel = {
    init: function(){
        var that = this;
        //优质企业
        $('.enterprise-list').flexslider({
            namespace: "enterp-",
            selector:'.enterprise-ul > li',
            animation: "slide",
            easing:"swing",
            controlNav:false,
            slideshowSpeed: 4000,
            animationSpeed: 1000,
            itemWidth: 236,
            move:4
        });
        //初始化搜索条件
        that.setSearchCondition();
        //选择服务类型
        $('#typeList a').click(function(){
            var $this = $(this);
            $this.addClass('current').siblings('a').removeClass('current');
            //重置显示的搜索条件
            that.setSearchCondition();
        });
        //公司所在地
        $('#allLocation').click(function(){
            var $this = $(this);
            $this.addClass('current');
            //重置省市区县
            $('#province').val('-1');
            $('#city').html('<option value="-1" selected="selected">选择城市</option>');
            $('#area').html('<option value="-1" selected="selected">选择区县</option>');
            that.setSearchCondition();
        });
        //省市区县change
        $('#province,#city,#area').change(function(){
            that.selectCommonChange();
        });
    },
    //省市区县select的change调用函数
    selectCommonChange: function(){
        var that = this;
        //去除‘不限’的选中状态
        $('#allLocation').removeClass('current');
        that.setSearchCondition();
    },
    //当前搜索条件
    setSearchCondition: function (){
        var arr_text = [];
        //服务类型
        var serviceType = $('#typeList').find('.current').text();
        serviceType = serviceType == '不限' ? '' : serviceType;
        if(serviceType){
            arr_text.push(serviceType);
        }
        var $province = $('#province'),$city = $('#city'),$area = $('#area');
        if('-1' != $province.val()){
            var location = $province.children('option:selected').text();
            if('-1' != $city.val()){
                location += $city.children('option:selected').text();
                if('-1' != $area.val()){
                    location += $area.children('option:selected').text();
                }
            }
            arr_text.push(location);
        }
        //设置搜索条件
        var $condition = $('#condition');
        if(arr_text.length){
            $condition.text(arr_text.join(' + ') + ' >');
        }else{
            $condition.text('');
        }
    }
}
$(function(){
    channel.init();
});