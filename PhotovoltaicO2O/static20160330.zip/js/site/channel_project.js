/**
 * Created by wangyaru on 2016/3/11.
 * summary: the javascript for channel page(eg. design.html etc).
 */
var channel = {
    init: function(){
        var that = this;
        //优质企业
        $('.enterprise-list').flexslider({
            namespace: "enterp-",
            selector:'.enterprise-ul > li',
            animation: "slide",
            easing:"swing",
            controlNav:false,
            slideshowSpeed: 4000,
            animationSpeed: 1000,
            itemWidth: 236,
            move:4
        });
        //初始化搜索条件
        that.setSearchCondition();
        //选择项目类型
        that.selectRadio('typeList','projectType',true);
        //选择项目阶段
        that.selectRadio('stageList','stage');
        //选择需求类型
        that.selectRadio('demandList','demand');
        //省市区县change
        that.selectArea();
        //设置项目面积
        that.inputControl();
        that.acreage();
        //不支持placeholder的浏览器处理
        spi.placeholder($('#acreage .input-acreage'));
    },
    /**
     * 选择项目类型、项目阶段、需求类型
     * @param parentId  string  可选项目父元素的id值
     * @param inputName string  对应表单元素input:hidden的name值
     * @param inputName boolean 是否是初始化
     */
    selectRadio: function(parentId,inputName,isInit){
        var that = this;
        var $parent = $('#' + parentId);
        var triggerClick = isInit || false;
        if($parent.length){
            $parent.children('a').click(function(){
                var $this = $(this);
                $this.addClass('current').siblings('a').removeClass('current');
                //项目类型选择，设置项目面积的单位
                if('typeList' == parentId){
                    var thisText = $.trim($this.text());
                    var $inputs = $('#acreage .input-acreage');
                    var tips = '㎡';
                    if('不限' == thisText){
                        tips = '';
                    }else if(-1 != $.inArray(thisText,['地面资源','其他资源'])){
                        tips = '亩';
                    }
                    if(!spi.tools.supportPlaceholder()){
                        $inputs.each(function(index,element){
                            if($(element).val() == $(element).attr('placeholder')){
                                $(element).val(tips);
                            }
                        });
                    }
                    $inputs.attr('placeholder',tips);
                }
                //重置显示的搜索条件
                that.setSearchCondition();
            });
            if(triggerClick){
            	$parent.find('a.current').trigger('click');
            }
        }
    },
    //省市区县select的change调用函数
    selectArea: function(){
        var that = this;
        $('#province,#city,#area').change(function(){
            that.setSearchCondition();
        });
    },
    //项目面积
    acreage: function(){
        var that = this;
        var $inputs = $('#acreage .input-acreage');
        $('#acreage .btn-confirm').click(function(){
            var isPass = true;
            $inputs.each(function(index,element){
                if($(element).val().length>10){
                    isPass = false;
                    return;
                }
            });
            if(isPass){
                var acreageStart = ($inputs.eq(0) && $inputs.eq(0).val()) || '';
                var acreageEnd = ($inputs.eq(1) && $inputs.eq(1).val()) || '';
                if('' != acreageStart && '' != acreageEnd ){
                    if(Number(acreageStart) > Number(acreageEnd)){
                        spi.showBoxAlert({
                            width: 250,
                            height: 120,
                            msg:'<div style="font-size: 14px; text-align: center; padding-top: 10px;">项目面积结束值不能小于起始值</div>',
                            afterConfirm: function(){
                                $inputs.eq(1).focus();
                            }
                        });
                    }else{
                        that.setSearchCondition();
                    }
                }else{
                    that.setSearchCondition();
                }
            }else{
                spi.showBoxAlert({
                    width: 250,
                    height: 120,
                    msg:'<div style="font-size: 14px; text-align: center; padding-top: 10px;">项目面积最多输入10位数字</div>'
                });
            }
        });
    },
    //项目面积文本框内容控制
    inputControl: function(){
        //只允许输入数字
        $('#acreage .input-acreage').on('keyup blur',function(){
            var $this = $(this);
            var newValue = $this.val().replace(/\D/g,'').replace(/^0+([1-9])/,"$1").replace(/^0+$/,"0");
            $this.val(newValue)
        });
    },
    //当前搜索条件
    setSearchCondition: function (){
        var arr_text = [];
        //项目类型、项目阶段、需求类型
        var selectParentIds = ['typeList','stageList','demandList'];
        $.each(selectParentIds,function(index,element){
            var selectedText = $('#'+element).find('.current').text();
            selectedText = selectedText == '不限' ? '' : selectedText;
            if(selectedText){
                arr_text.push(selectedText);
            }
        });
        //项目所在地
        var $province = $('#province'),$city = $('#city'),$area = $('#area');
        if('0' != $province.val()){
        	if($city.val() > 0){
        		var location = $province.children('option:selected').text()+' + ';
        	}else{
        		var location = $province.children('option:selected').text();
        	}
            if('0' != $city.val()){
            	if($area.val() > 0){
            		location += $city.children('option:selected').text()+' + ';
            	}else{
            		location += $city.children('option:selected').text();
            	}
                if('0' != $area.val()){
                    location += $area.children('option:selected').text();
                }
            }
            arr_text.push(location);
        }
        //项目面积
        var $inputs = $('#acreage input.input-acreage');
        var acreageStart = ($inputs.eq(0) && $inputs.eq(0).val()) || '';//项目面积起始值
        var acreageEnd = ($inputs.eq(1) && $inputs.eq(1).val()) || '';//项目面积结束值
        var acreageTxt = '';
        var unit = $inputs.eq(0).attr('placeholder');//项目面积单位
        //不支持placeholder的浏览器需要
        if(!spi.tools.supportPlaceholder()){
            var forbiddenStr = ['㎡','亩'];
            if(-1 != $.inArray(acreageStart,forbiddenStr)){
                acreageStart = '';
            }
            if(-1 != $.inArray(acreageEnd,forbiddenStr)){
                acreageEnd = '';
            }
        }
        if('' != acreageStart && '' == acreageEnd){
            acreageTxt = '>=' + acreageStart + unit;
        }else if('' == acreageStart && '' != acreageEnd){
            acreageTxt = '<=' + acreageEnd + unit;
        }else if('' != acreageStart && '' != acreageEnd){
            acreageTxt = acreageStart + unit + ' 至 ' + acreageEnd + unit;
        }
        if(acreageTxt){
            arr_text.push('('+ acreageTxt + ')');
        }
        //设置搜索条件
        var $condition = $('#condition');
        if(arr_text.length){
            $condition.text(arr_text.join(' + ') + ' >>');
        }else{
            $condition.text('');
        }
    }
}
$(function(){
    channel.init();
});