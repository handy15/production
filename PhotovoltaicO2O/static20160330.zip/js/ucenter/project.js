/**
 * 登记项目相关js
 * @param content
 */

 //DOM加载完毕
$(function(){
    //表单验证
    $("#project_from").Validform({
        tiptype:function(msg,o,cssctl){
            /*
            if(o.type == 3){
                console.log(msg);
                console.log(o.obj.attr('name'));
                console.log(o.obj.attr('ignore'));
            }*/
        },
        ajaxPost:true,
        datatype:{//传入自定义datatype类型，可以是正则，也可以是函数（函数内会传入一个参数）;
            "decimal":function(gets,obj,curform,regxp){
               // console.log(obj);
               // console.log(obj.attr('nullmsg'));
                //参数gets是获取到的表单元素值，obj为当前表单元素，curform为当前验证的表单，regxp为内置的一些正则表达式的引用;
                //验证长度
                if(gets.length > 11){return false;}
                //
                if(gets == "0" || gets == "0." || gets == "0.0" || gets == "0.00"){
                    return true;
                }else{
                    var index = gets.indexOf("0");
                    var length = gets.length;
                    if(index == 0 && length>1){
                        /*0开头的数字串*/
                        var reg = /^[0]{1}[.]{1}[0-9]{1,2}$/;
                        if(!reg.test(gets)){
                            return false;
                        }else{
                            return true;
                        }
                    }else{   /*非0开头的数字*/
                        if(gets.indexOf('.') != '-1'){  //带小数点
                            var reg = /^[1-9]{1}[0-9]{0,7}[.]{0,1}[0-9]{0,2}$/;
                            if(!reg.test(gets)){
                                return false;
                            }else{
                                return true;
                            }
                        }else{  //纯数字处理
                            var reg = /^[0-9]{1,8}$/;
                            if(!reg.test(gets)){
                                return false;
                            }else{
                                return true;
                            }
                        }
                    }
                    return false;
                }
            },
            "decimal_money":function(gets,obj,curform,regxp){
                //参数gets是获取到的表单元素值，obj为当前表单元素，curform为当前验证的表单，regxp为内置的一些正则表达式的引用;
                //验证长度
                if(gets.length > 15){return false;}
                //
                if(gets == "0" || gets == "0." || gets == "0.0" || gets == "0.00" || gets == '0.000' || gets == '0.0000'){
                    return true;
                }else{
                    var index = gets.indexOf("0");
                    var length = gets.length;
                    if(index == 0 && length>1){
                        /*0开头的数字串*/
                        var reg = /^[0]{1}[.]{1}[0-9]{1,2}$/;
                        if(!reg.test(gets)){
                            return false;
                        }else{
                            return true;
                        }
                    }else{  /*非0开头的数字*/
                        if(gets.indexOf('.') != '-1'){  //带小数点
                            var reg = /^[1-9]{1}[0-9]{0,9}[.]{0,1}[0-9]{0,4}$/;
                            if(!reg.test(gets)){
                                return false;
                            }else{
                                return true;
                            }
                        }else{
                            var reg = /^[0-9]{1,10}$/;
                            if(!reg.test(gets)){
                                return false;
                            }else{
                                return true;
                            }
                        }
                    }
                    return false;
                }
            }

        },
        beforeSubmit:function(curform){
            //复选框处理
            var projectArr = new Array();
            $("input[name='project_category[]']:checked").each(function () {
                projectArr.push($(this).val());
            });

            if(projectArr.length <= 0){
                alertMsg('请勾选需求类型！');
                return false;
            }
            //备案名称处理
            var is_record = $('input[name=project_is_record]:checked').val();
            if(is_record == 1 ){
                var record_name = $('input[name=project_record_name]').val().trim();
                if(record_name === ''){
                    alertMsg('请输入备案公司名称！');
                    return false;
                }else if(!/^[\u4E00-\u9FA5\uf900-\ufa2d\w\.\s]{1,20}$/.test(record_name)){
                    alertMsg('备案公司最多20位字符！');
                    return false;
                }
            }
            //图片处理
            var imageLength = $('.engineering_consulting').length;
            if(imageLength <= 0){
                alertMsg('请上传项目现场照片！');
                return false;
            }else if(imageLength > 20){
                alertMsg('项目现场照片最多上传20张！');
                return false;
            }
            //表单提交锁定
            $('input[type=submit]').attr('disabled', "disabled");
            return true;
        },
        callback:function(data){
            if(data.code!="2000"){
                alertMsg(data.msg);
            }else{
                window.location.href='/project/success';
            }
            //表单解锁
            $('input[type=submit]').removeAttr('disabled');
        }
    });

});


//弹层信息处理
function alertMsg(content){
    spi.showBoxAlert({
        width:250,  //弹出框宽度
        height:100,  //弹出框高度
        msg:content, //提示信息，可以是html
        afterConfirm: function(){  //点击“确定”关闭窗口后的回调函数
            $('#click').text('click again!');
        }
    });
}


/**
*登记项目流程编辑 js代码
*/
//图片批量上传
var uploader = new plupload.Uploader({//创建实例的构造方法
    runtimes: 'html5,flash,silverlight,html4', //上传插件初始化选用那种方式的优先级顺序
    browse_button: 'construction_certificate', // 上传按钮
    url: "/image/upload", //远程上传地址
    flash_swf_url: 'plupload/Moxie.swf', //flash文件地址
    silverlight_xap_url: 'plupload/Moxie.xap', //silverlight文件地址
    filters: {
        max_file_size: '2mb', //最大上传文件大小（格式100b, 10kb, 10mb, 1gb）
        mime_types: [//允许文件上传类型
            {title: "files", extensions: "jpg,png,gif"}
        ]
    },
    multi_selection: true, //true:ctrl多文件上传, false 单文件上传
    init: {
        FilesAdded: function(up, files) { //文件上传前
            if ($(".Fil").children("div.engineering_consulting").length > 19) {
                alert("您上传的图片太多了！");
                uploader.destroy();
            } else {
                var div = '';
                plupload.each(files, function(file) { //遍历文件
                    div += ' <div id="' + file['id'] + '"  class="engineering_consulting">\
                                    <span class="FileSpan">&times;</span>\
                                    <div class="progress"><span class="bar"></span><span class="percent">0%</span></div>\
                                </div>';
                });
                $(".construction_certificate").before(div);
                uploader.start();
            }
        },
        UploadProgress: function(up, file) { //上传中，显示进度条
            var percent = file.percent;
            $("#" + file.id).find('.bar').css({"width": percent + "%"});
            $("#" + file.id).find(".percent").text(percent + "%");
        },
        FileUploaded: function(up, file, info) { //文件上传成功的时候触发
            var data = eval("(" + info.response + ")");
            $("#" + file.id).html(
                '<span class="FileSpan" onclick="delImg(this)" >&times;</span>' +
                    '<img class="SellImg" src="'+data.data.url+'"/>' +
                    '<input type="hidden" name="image_path[]" value="'+data.data.path+'">'
            );
        },
        Error: function(up, err) { //上传出错的时候触发
            alert(err.message);
        }
    }
});
uploader.init();


/**
 * 删除图片
 * @param obj
 */
function delImg(obj){
    $(obj).parent().remove();
}

//处理投资额
function dealInvest(info_install_mw_value,info_install_mw_unit){
    if(info_install_mw_value != ''){
        if(info_install_mw_unit == 1){
            var info_invest_quota_value = (info_install_mw_value * 1000 * 1000 * 8.5) / 10000;
        }else{
            var info_invest_quota_value = (info_install_mw_value * 1000 * 8.5) / 10000;
        }
        $('#info_invest_quota').val(info_invest_quota_value);
    }
}


//预计投资额度计算
$('#info_install_mw').bind('input propertychange', function() {
    var info_install_mw_value = $(this).val();
    var info_install_mw_unit = $('#info_install_mw_unit').val();
    dealInvest(info_install_mw_value,info_install_mw_unit);
});



/**
 * 保存草稿操作
 */
$('#dosubmit').click(function(){
    $.ajax({
        type:'post',
        url:'/project/saveTest',
        data:$('#project_from').serialize(),
        dataType:'json',
        success:function(data){
            if(data.code == '2000') {
                alertMsg('已保存！');
                $('input[name=info_id]').val(data.data.info_id);
                $('input[name=project_id]').val(data.data.project_id);
                //window.location.reload();
            }else{
                alertMsg(data.msg);
            }
        }
    });
});


//获取区域节点
function getAreaNodeDetail(parentId,regionType,htmlId,inputName,checkValue){
    if(parentId){
        $.ajax({
            type:'post',
            url:'/project/getarea',
            data:{parentId:parentId,regionType:regionType,random:Math.round((Math.random()) * 100000000)},
            dataType:'json',
            success:function(data){
                if(data.code == '2000') {
                    var onchangeEvent = '';
                    if(regionType == 2){
                        onchangeEvent = 'onchange="getAreaNodeDetail(this.value,3,\'countyNode\',\'project_county_id\')"';
                    }
                    var htmlContent = ' <select class="sel ml10px" name="'+inputName+'" '+onchangeEvent+' >';
                    htmlContent += '<option value="0">请选择</option>';
                    $(data.data).each(function(key,val){
                        var defaultCheck = '';
                        if(val.region_id == checkValue){
                            defaultCheck = 'selected="selected"';
                        }
                        htmlContent += '<option value="'+val.region_id+'"  '+defaultCheck+' >'+val.region_name+'</option>';
                    });
                    htmlContent += '</select>';
                    $('#'+htmlId).html(htmlContent);
                }
            }
        });
    }
}