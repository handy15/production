/**
 * Created by wangyaru on 2016/3/17.
 * summary: the javascript for project_step3.html.
 */
$(function(){
    //兼容低版本浏览器的placeholder
    spi.placeholder($('input[placeholder]'));
    //tab切换
    spi.tabs({
        eventarr:[function(){
            //点击“基本信息”前触发的函数
        },function(){
            //点击“经济评价”前触发的函数
        },function(){
            //点击“项目文件”前触发的函数
        },function(){
            //点击“设备配置”前触发的函数
        },function(){
            //点击“运营情况”前触发的函数
        }]
    });
    //备案公司显示隐藏  ！！！！备案公司隐藏后，需要去掉必填的验证
    $('input[name=project_is_record]').click(function(){
        var $this = $(this);
        var $companyName = $('.company-name');
        if('1' == $this.val()){
            $companyName.show();
        }else{
            $companyName.hide().find('input[type=text]').val('');
        }
    });
});