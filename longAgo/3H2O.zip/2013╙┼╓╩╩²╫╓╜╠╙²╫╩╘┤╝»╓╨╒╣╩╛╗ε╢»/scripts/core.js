//入口页的脚本
function entrance(){
	//轮播图片
	$('.potoslide').slidesjs({
		width:933,
        height:268,
        navigation: {
			active: 0,
			effect: "fade"
        },pagination: {
        	effect: "fade"
        },effect:{
        	fade: {
            	speed: 400
			}
		},play:{
			active:!1,
			effect: "fade",
			interval: 3e3,
			auto:1,
			swap:!0,
			pauseOnHover:1,
			restartDelay: 1000
		}
	});
	$('#map1 area').hover(function(){
		var num =  $(this).attr('flag');
		$('#en1').attr('src','images/img-r' + num + '.png');
	},function(){
		$('#en1').attr('src','images/img-r.png');
	});
}

//内页框架脚本
function inner(){
	var href = GetQueryString("page") ? GetQueryString("page")+".html" : "";
	if("" != href){
		$("#swidow").attr("src",href);
	}
	//导航当前状态
	var $li = $('.inner-nav li').eq(0);
	var liwidth = 0;
	liwidth = Number($li.width()) + Number($li.css('padding-left').replace('px','')) + Number($li.css('padding-right').replace('px','')) + Number($li.css('margin-left').replace('px','')) + Number($li.css('margin-right').replace('px','')) + Number($li.css('border-left-width').replace('px','')) + Number($li.css('border-right-width').replace('px',''));
	$.each($('.inner-nav a'),function(index,element){
		if(href == $(element).attr("href")){
			$(".bgorange").css("left",liwidth*index + 'px');
			$('.inner-nav li').removeClass("inner-nava");
			$(element).parents("li").addClass("inner-nava");
		}
	});
	$('.inner-nav a').click(function(){
		var $this = $(this);//alert($this);
		$.each($('.inner-nav a'),function(index,element){//alert($this);
			if($this.attr("href") === $(element).attr("href")){
				$(".bgorange").animate({
					"left":liwidth*index + 'px'
				},400,function(){
					$(element).parents("li").addClass("inner-nava");
				});
				$('.inner-nav li').removeClass("inner-nava");
			}
		});
	});
}
//精品资源脚本
function jp(){
	$(".jpItem").hover(function(){
		$(this).addClass("jpItem-a");
		if(0!=$(this).children(".jpItem-zh").length){
			$(this).children(".jpItem-zh").fadeIn(200);
		}
	},function(){
		$(this).removeClass("jpItem-a");
		if(0!=$(this).children(".jpItem-zh").length){
			$(this).children(".jpItem-zh").fadeOut(200);
		}
	});
}
//职教专题
function zj(){
	//轮播图片
	$('.zjItem').slidesjs({
		width:974,
        height:321,
        navigation: {
			ptitle:"",
			ptext:"上一页",
			ntitle:"",
			ntext:"下一页"
        },
		pagination: {
			active:0
        },
		effect:{
        	slide:{
				speed:700
			}
		},
		play:{
			active:!1,
			interval: 4e3,
			auto:1,
			pauseOnHover:1,
			restartDelay: 1000
		},
		callback: {
			//loaded: function() {},
			start: function() {$(".leftCorn").show();},
			complete: function() {$(".leftCorn").hide();}
		}
	});
}
//基教资源
function jj(){
	tab($(".stage span[id]"),"click","jja");
	tab($("#xxDiv .ul-subject li[id]"),"click","jja1");
	tab($("#czDiv .ul-subject li[id]"),"click","jja1");
	tab($("#gzDiv .ul-subject li[id]"),"click","jja1");
	substring();
	//生成分页
	var pagesize = 3;
	//小学
	renderPage($("#xx1Div"),pagesize,$("#xx1Div dl").length);
	renderPage($("#xx2Div"),pagesize,$("#xx2Div dl").length);
	renderPage($("#xx3Div"),pagesize,$("#xx3Div dl").length);
	renderPage($("#xx4Div"),pagesize,$("#xx4Div dl").length);
	renderPage($("#xx5Div"),pagesize,$("#xx5Div dl").length);
	//初中
	renderPage($("#cz1Div"),pagesize,$("#cz1Div dl").length);
	renderPage($("#cz2Div"),pagesize,$("#cz2Div dl").length);
	renderPage($("#cz3Div"),pagesize,$("#cz3Div dl").length);
	renderPage($("#cz4Div"),pagesize,$("#cz4Div dl").length);
	renderPage($("#cz5Div"),pagesize,$("#cz5Div dl").length);
	//高中
	renderPage($("#gz1Div"),pagesize,$("#gz1Div dl").length);
	renderPage($("#gz2Div"),pagesize,$("#gz2Div dl").length);
	renderPage($("#gz3Div"),pagesize,$("#gz3Div dl").length);
	renderPage($("#gz4Div"),pagesize,$("#gz4Div dl").length);
	renderPage($("#gz5Div"),pagesize,$("#gz5Div dl").length);
	renderPage($("#gz6Div"),pagesize,$("#gz6Div dl").length);
	renderPage($("#gz7Div"),pagesize,$("#gz7Div dl").length);
	renderPage($("#gz8Div"),pagesize,$("#gz8Div dl").length);
	renderPage($("#gz9Div"),pagesize,$("#gz9Div dl").length);
}
//地市精品
function dsjp(){
	tab($(".cities li[id]"),"click","active1");
	substring();
	//生成分页
	var pagesize = 6;
	renderPage1($("#njDiv"),pagesize,$("#njDiv div.dsjp-item").length);
	renderPage1($("#wxDiv"),pagesize,$("#wxDiv div.dsjp-item").length);
	renderPage1($("#xzDiv"),pagesize,$("#xzDiv div.dsjp-item").length);
	renderPage1($("#szDiv"),pagesize,$("#szDiv div.dsjp-item").length);
	renderPage1($("#lygDiv"),pagesize,$("#lygDiv div.dsjp-item").length);
	renderPage1($("#haDiv"),pagesize,$("#haDiv div.dsjp-item").length);
	renderPage1($("#yzDiv"),pagesize,$("#yzDiv div.dsjp-item").length);
	renderPage1($("#zjDiv"),pagesize,$("#zjDiv div.dsjp-item").length);
	renderPage1($("#tzDiv"),pagesize,$("#tzDiv div.dsjp-item").length);
	renderPage1($("#sqDiv"),pagesize,$("#sqDiv div.dsjp-item").length);
	renderPage1($("#ntDiv"),pagesize,$("#ntDiv div.dsjp-item").length);
	renderPage1($("#ycDiv"),pagesize,$("#ycDiv div.dsjp-item").length);
	renderPage1($("#czDiv"),pagesize,$("#czDiv div.dsjp-item").length);
}
//属性页框架脚本
function property(){
	var href = GetQueryString("pro") ? "property/" + GetQueryString("pro")+".html" : "";
	if("" != href){
		$("#swidow").attr("src",href);
	}
}

//查询url参数
function GetQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
	var r = window.location.search.substr(1).match(reg);
	if (r != null) return unescape(r[2]);
	return null;
}
function isUndefined(s){
	return typeof s==="undefined";
}
function isObject(object){
	return typeof object==="object";
}

//生成分页函数--基教
function renderPage($container,pagesize,totalnum){
	var psize = pagesize;
	var tnum = totalnum;
	var $pcontainer = isObject($container) ? $container : null;
	var pagenum = 0;
	var isrender = 0;
	var phtml = '';
	if($pcontainer){
		if(psize < tnum){
			pagenum = Math.ceil(tnum/psize);
			var currentclass="";
			phtml += '<div class="pager clear"><ul><li class="ptext none" page="0">上一页</li>';
			for(var i=1;i<=pagenum;i++){
				if(1 == i){
					currentclass="current";
				}else{
					currentclass="";
				}
				phtml += '<li class="' + currentclass +'" page="' + i + '">' + i +'</li>';
				isrender++;
			}
			phtml += '<li class="ptext" page="2">下一页</li></ul></div>';
		}
		if(0 != isrender){
			$pcontainer.append(phtml);
			$.each($pcontainer.find('.dl-subject'),function(index,element){
				$(this).attr('page',Math.ceil((index+1)/pagesize));
			});
			//相应分页点击事件
			$pcontainer.find(".pager li").bind("click",function(){
				var $this = $(this);
				var thisTxt = $this.text();
				var currentNum = parseInt($this.attr("page"));
				if(thisTxt != $pcontainer.find('.pager li.current').text()){
					if(1 == currentNum){
						$pcontainer.find(".pager li.ptext").eq(0).hide();
						$pcontainer.find(".pager li.ptext").eq(1).show();
					}else if(pagenum == currentNum){
						$pcontainer.find(".pager li.ptext").eq(0).show();
						$pcontainer.find(".pager li.ptext").eq(1).hide();
					}else{
						$pcontainer.find(".pager li.ptext").show();
					}
					$pcontainer.find(".pager li.ptext").eq(1).attr("page",currentNum+1);
					$pcontainer.find(".pager li.ptext").eq(0).attr("page",currentNum-1);
					$pcontainer.find(".dl-subject").hide();
					$pcontainer.find(".dl-subject[page=" + currentNum + "]").fadeIn();
					$pcontainer.find(".pager li").removeClass("current");
					$pcontainer.find(".pager li[page="+ currentNum + "]").addClass("current");
				}
			});
		}
	}
}
//生成分页函数--地市精品
function renderPage1($container,pagesize,totalnum){
	var psize = pagesize;
	var tnum = totalnum;
	var $pcontainer = isObject($container) ? $container : null;
	var pagenum = 0;
	var isrender = 0;
	var phtml = '';
	if($pcontainer){
		if(psize < tnum){
			pagenum = Math.ceil(tnum/psize);
			var currentclass="";
			phtml += '<div class="pager clear"><ul><li class="ptext none" page="0">上一页</li>';
			for(var i=1;i<=pagenum;i++){
				if(1 == i){
					currentclass="current";
				}else{
					currentclass="";
				}
				phtml += '<li class="' + currentclass +'" page="' + i + '">' + i +'</li>';
				isrender++;
			}
			phtml += '<li class="ptext" page="2">下一页</li></ul></div>';
		}
		if(0 != isrender){
			$pcontainer.append(phtml);
			$.each($pcontainer.find('.dsjp-item'),function(index,element){
				if(1 == (index+1)%pagesize){
					$(this).addClass('index1');
				}
				$(this).attr('page',Math.ceil((index+1)/pagesize));
			});
			//相应分页点击事件
			$pcontainer.find(".pager li").bind("click",function(){
				var $this = $(this);
				var thisTxt = $this.text();
				var currentNum = parseInt($this.attr("page"));
				if(thisTxt != $pcontainer.find('.pager li.current').text()){
					if(1 == currentNum){
						$pcontainer.find(".pager li.ptext").eq(0).hide();
						$pcontainer.find(".pager li.ptext").eq(1).show();
					}else if(pagenum == currentNum){
						$pcontainer.find(".pager li.ptext").eq(0).show();
						$pcontainer.find(".pager li.ptext").eq(1).hide();
					}else{
						$pcontainer.find(".pager li.ptext").show();
					}
					$pcontainer.find(".pager li.ptext").eq(1).attr("page",currentNum+1);
					$pcontainer.find(".pager li.ptext").eq(0).attr("page",currentNum-1);
					$pcontainer.find(".dsjp-item").hide();
					$pcontainer.find(".dsjp-item[page=" + currentNum + "]").fadeIn().css('display',"inline");
					$pcontainer.find(".pager li").removeClass("current");
					$pcontainer.find(".pager li[page="+ currentNum + "]").addClass("current");
				}
			});
		}
	}
}

//tab组的样式切换，对应tab的div同时切换
function tab($object,eventType,activeClass){
	$object = isObject($object) ? $object : null;
	eventType = isUndefined(eventType) ? "mouseover" : eventType;
	activeClass = isUndefined(activeClass) ? "" : activeClass;
	$object.bind(eventType,function(e){
		//选中的菜单
		var $thisMenu = $(this);
		//菜单长度
		var menuLength = $object.length;
		for(var i=0; i<menuLength; i++){
			//统计菜单id值
			var menuid = $object.eq(i).attr('id');
			//隐藏对应菜单的div
			$('#'+menuid+'Div').hide();
		}
		//移除菜单样式
		$object.removeClass(activeClass);
		//设置当前菜单的样式
		$thisMenu.addClass(activeClass);
		//显示当前菜单对应的div
		$('#'+$thisMenu.attr('id')+'Div').show();
	});
}
//截取列表字符长度
var substring = function () {
    $("[ellipsis]").each(function () {
        var $this = $(this);
        var $length = $this.attr("ellipsis") || 20;
        $this.html(subStrAtLen($this.text(), $length));
    });
};

var subStrAtLen = function (assignStr, assignLen) {
    var len = 0;
    var i = 0;
    var flag = 0;
    var tsubstr = '';
    for (; i < assignStr.length; i++) {
        if (assignStr.charCodeAt(i) > 255 || assignStr.charCodeAt(i) < 0) {
            len += 2;
        } else {
            len++;
        }
        if (assignLen < len) {
            tsubstr = assignStr.substr(0, i) + '<label style=\"font-family:Arial;\">...</label>';
            break;
        } else {
            tsubstr = assignStr;
        }
    }
    return tsubstr;
};

//图片透明
function correctPNG(){
	if (!window.XMLHttpRequest){
		for(var i=0; i<document.images.length; i++) { 
			var img = document.images[i];
			if($(img).attr('flag') == 'transparent'){
				var imgName = img.src.toUpperCase();
				if (imgName.substring(imgName.length-3, imgName.length) == "PNG"){ 
					var imgID = (img.id) ? "id='" + img.id + "' " : "" 
					var imgClass = (img.className) ? "class='" + img.className + "' " : "" 
					var imgTitle = (img.title) ? "title='" + img.title + "' " : "title='" + img.alt + "' " 
					var imgStyle = "display:inline-block;" + img.style.cssText  
					if (img.align == "left") imgStyle = "float:left;" + imgStyle 
					if (img.align == "right") imgStyle = "float:right;" + imgStyle 
					if (img.parentElement.href) imgStyle = "cursor:hand;" + imgStyle   
					var strNewHTML = "<span " + imgID + imgClass + imgTitle 
					+ " style=\"" + "width:" + img.width + "px; height:" + img.height + "px;" + imgStyle + ";" 
					+ "filter:progid:DXImageTransform.Microsoft.AlphaImageLoader" 
					+ "(src=\'" + img.src + "\', sizingMethod='scale');\"></span>"  
					img.outerHTML = strNewHTML 
					i = i-1 
				}
			}
		}
	}
}

/*
  SlidesJS 3.0.4 http://slidesjs.com
  (c) 2013 by Nathan Searles http://nathansearles.com
  Updated: June 26th, 2013
  Apache License: http://www.apache.org/licenses/LICENSE-2.0
*/
(function(){(function(e,t,n){var r,i,s;s="slidesjs";i={width:940,height:528,start:1,navigation:{active:!0,effect:"slide",ptitle:"Previous",ptext:"Previous",ntitle:"Next",ntext:"Next"},pagination:{active:!0,effect:"slide"},play:{active:!1,effect:"slide",interval:5e3,auto:!1,swap:!0,pauseOnHover:!1,restartDelay:2500},effect:{slide:{speed:500},fade:{speed:300,crossfade:!0}},callback:{loaded:function(){},start:function(){},complete:function(){}}};r=function(){function t(t,n){this.element=t;this.options=e.extend(!0,{},i,n);this._defaults=i;this._name=s;this.init()}return t}();r.prototype.init=function(){var n,r,i,s,o,u,a=this;n=e(this.element);this.data=e.data(this);e.data(this,"animating",!1);e.data(this,"total",n.children().not(".slidesjs-navigation",n).length);e.data(this,"current",this.options.start-1);e.data(this,"vendorPrefix",this._getVendorPrefix());if(typeof TouchEvent!="undefined"){e.data(this,"touch",!0);this.options.effect.slide.speed=this.options.effect.slide.speed/2}n.css({overflow:"hidden"});n.slidesContainer=n.children().not(".slidesjs-navigation",n).wrapAll("<div class='slidesjs-container'>",n).parent().css({overflow:"hidden",position:"relative"});e(".slidesjs-container",n).wrapInner("<div class='slidesjs-control'>",n).children();e(".slidesjs-control",n).css({position:"relative",left:0});e(".slidesjs-control",n).children().addClass("slidesjs-slide").css({position:"absolute",top:0,left:0,width:"100%",zIndex:0,display:"none",webkitBackfaceVisibility:"hidden"});e.each(e(".slidesjs-control",n).children(),function(t){var n;n=e(this);return n.attr("slidesjs-index",t)});if(this.data.touch){e(".slidesjs-control",n).on("touchstart",function(e){return a._touchstart(e)});e(".slidesjs-control",n).on("touchmove",function(e){return a._touchmove(e)});e(".slidesjs-control",n).on("touchend",function(e){return a._touchend(e)})}n.fadeIn(0);this.update();this.data.touch&&this._setuptouch();e(".slidesjs-control",n).children(":eq("+this.data.current+")").eq(0).fadeIn(0,function(){return e(this).css({zIndex:10})});if(this.options.navigation.active){o=e("<a>",{"class":"slidesjs-previous slidesjs-navigation",href:"#",title:this.options.navigation.ptitle,text:this.options.navigation.ptext}).appendTo(n);r=e("<a>",{"class":"slidesjs-next slidesjs-navigation",href:"#",title:this.options.navigation.ntitle,text:this.options.navigation.ntext}).appendTo(n)}e(".slidesjs-next",n).click(function(e){e.preventDefault();a.stop(!0);return a.next(a.options.navigation.effect)});e(".slidesjs-previous",n).click(function(e){e.preventDefault();a.stop(!0);return a.previous(a.options.navigation.effect)});if(this.options.play.active){s=e("<a>",{"class":"slidesjs-play slidesjs-navigation",href:"#",title:"Play",text:"Play"}).appendTo(n);u=e("<a>",{"class":"slidesjs-stop slidesjs-navigation",href:"#",title:"Stop",text:"Stop"}).appendTo(n);s.click(function(e){e.preventDefault();return a.play(!0)});u.click(function(e){e.preventDefault();return a.stop(!0)});this.options.play.swap&&u.css({display:"none"})}if(this.options.pagination.active){i=e("<ul>",{"class":"slidesjs-pagination"}).appendTo(n);e.each(new Array(this.data.total),function(t){var n,r;n=e("<li>",{"class":"slidesjs-pagination-item"}).appendTo(i);r=e("<a>",{href:"#","data-slidesjs-item":t,html:t+1}).appendTo(n);return r.click(function(t){t.preventDefault();a.stop(!0);return a.goto(e(t.currentTarget).attr("data-slidesjs-item")*1+1)})})}e(t).bind("resize",function(){return a.update()});this._setActive();this.options.play.auto&&this.play();return this.options.callback.loaded(this.options.start)};r.prototype._setActive=function(t){var n,r;n=e(this.element);this.data=e.data(this);r=t>-1?t:this.data.current;e(".active",n).removeClass("active");return e(".slidesjs-pagination li:eq("+r+") a",n).addClass("active")};r.prototype.update=function(){var t,n,r;t=e(this.element);this.data=e.data(this);e(".slidesjs-control",t).children(":not(:eq("+this.data.current+"))").css({display:"none",left:0,zIndex:0});r=t.width();n=this.options.height/this.options.width*r;this.options.width=r;this.options.height=n;return e(".slidesjs-control, .slidesjs-container",t).css({width:r,height:n})};r.prototype.next=function(t){var n;n=e(this.element);this.data=e.data(this);e.data(this,"direction","next");t===void 0&&(t=this.options.navigation.effect);return t==="fade"?this._fade():this._slide()};r.prototype.previous=function(t){var n;n=e(this.element);this.data=e.data(this);e.data(this,"direction","previous");t===void 0&&(t=this.options.navigation.effect);return t==="fade"?this._fade():this._slide()};r.prototype.goto=function(t){var n,r;n=e(this.element);this.data=e.data(this);r===void 0&&(r=this.options.pagination.effect);t>this.data.total?t=this.data.total:t<1&&(t=1);if(typeof t=="number")return r==="fade"?this._fade(t):this._slide(t);if(typeof t=="string"){if(t==="first")return r==="fade"?this._fade(0):this._slide(0);if(t==="last")return r==="fade"?this._fade(this.data.total):this._slide(this.data.total)}};r.prototype._setuptouch=function(){var t,n,r,i;t=e(this.element);this.data=e.data(this);i=e(".slidesjs-control",t);n=this.data.current+1;r=this.data.current-1;r<0&&(r=this.data.total-1);n>this.data.total-1&&(n=0);i.children(":eq("+n+")").css({display:"block",left:this.options.width});return i.children(":eq("+r+")").css({display:"block",left:-this.options.width})};r.prototype._touchstart=function(t){var n,r;n=e(this.element);this.data=e.data(this);r=t.originalEvent.touches[0];this._setuptouch();e.data(this,"touchtimer",Number(new Date));e.data(this,"touchstartx",r.pageX);e.data(this,"touchstarty",r.pageY);return t.stopPropagation()};r.prototype._touchend=function(t){var n,r,i,s,o,u,a,f=this;n=e(this.element);this.data=e.data(this);u=t.originalEvent.touches[0];s=e(".slidesjs-control",n);if(s.position().left>this.options.width*.5||s.position().left>this.options.width*.1&&Number(new Date)-this.data.touchtimer<250){e.data(this,"direction","previous");this._slide()}else if(s.position().left<-(this.options.width*.5)||s.position().left<-(this.options.width*.1)&&Number(new Date)-this.data.touchtimer<250){e.data(this,"direction","next");this._slide()}else{i=this.data.vendorPrefix;a=i+"Transform";r=i+"TransitionDuration";o=i+"TransitionTimingFunction";s[0].style[a]="translateX(0px)";s[0].style[r]=this.options.effect.slide.speed*.85+"ms"}s.on("transitionend webkitTransitionEnd oTransitionEnd otransitionend MSTransitionEnd",function(){i=f.data.vendorPrefix;a=i+"Transform";r=i+"TransitionDuration";o=i+"TransitionTimingFunction";s[0].style[a]="";s[0].style[r]="";return s[0].style[o]=""});return t.stopPropagation()};r.prototype._touchmove=function(t){var n,r,i,s,o;n=e(this.element);this.data=e.data(this);s=t.originalEvent.touches[0];r=this.data.vendorPrefix;i=e(".slidesjs-control",n);o=r+"Transform";e.data(this,"scrolling",Math.abs(s.pageX-this.data.touchstartx)<Math.abs(s.pageY-this.data.touchstarty));if(!this.data.animating&&!this.data.scrolling){t.preventDefault();this._setuptouch();i[0].style[o]="translateX("+(s.pageX-this.data.touchstartx)+"px)"}return t.stopPropagation()};r.prototype.play=function(t){var n,r,i,s=this;n=e(this.element);this.data=e.data(this);if(!this.data.playInterval){if(t){r=this.data.current;this.data.direction="next";this.options.play.effect==="fade"?this._fade():this._slide()}e.data(this,"playInterval",setInterval(function(){r=s.data.current;s.data.direction="next";return s.options.play.effect==="fade"?s._fade():s._slide()},this.options.play.interval));i=e(".slidesjs-container",n);if(this.options.play.pauseOnHover){i.unbind();i.bind("mouseenter",function(){return s.stop()});i.bind("mouseleave",function(){return s.options.play.restartDelay?e.data(s,"restartDelay",setTimeout(function(){return s.play(!0)},s.options.play.restartDelay)):s.play()})}e.data(this,"playing",!0);e(".slidesjs-play",n).addClass("slidesjs-playing");if(this.options.play.swap){e(".slidesjs-play",n).hide();return e(".slidesjs-stop",n).show()}}};r.prototype.stop=function(t){var n;n=e(this.element);this.data=e.data(this);clearInterval(this.data.playInterval);this.options.play.pauseOnHover&&t&&e(".slidesjs-container",n).unbind();e.data(this,"playInterval",null);e.data(this,"playing",!1);e(".slidesjs-play",n).removeClass("slidesjs-playing");if(this.options.play.swap){e(".slidesjs-stop",n).hide();return e(".slidesjs-play",n).show()}};r.prototype._slide=function(t){var n,r,i,s,o,u,a,f,l,c,h=this;n=e(this.element);this.data=e.data(this);if(!this.data.animating&&t!==this.data.current+1){e.data(this,"animating",!0);r=this.data.current;if(t>-1){t-=1;c=t>r?1:-1;i=t>r?-this.options.width:this.options.width;o=t}else{c=this.data.direction==="next"?1:-1;i=this.data.direction==="next"?-this.options.width:this.options.width;o=r+c}o===-1&&(o=this.data.total-1);o===this.data.total&&(o=0);this._setActive(o);a=e(".slidesjs-control",n);t>-1&&a.children(":not(:eq("+r+"))").css({display:"none",left:0,zIndex:0});a.children(":eq("+o+")").css({display:"block",left:c*this.options.width,zIndex:10});this.options.callback.start(r+1);if(this.data.vendorPrefix){u=this.data.vendorPrefix;l=u+"Transform";s=u+"TransitionDuration";f=u+"TransitionTimingFunction";a[0].style[l]="translateX("+i+"px)";a[0].style[s]=this.options.effect.slide.speed+"ms";return a.on("transitionend webkitTransitionEnd oTransitionEnd otransitionend MSTransitionEnd",function(){a[0].style[l]="";a[0].style[s]="";a.children(":eq("+o+")").css({left:0});a.children(":eq("+r+")").css({display:"none",left:0,zIndex:0});e.data(h,"current",o);e.data(h,"animating",!1);a.unbind("transitionend webkitTransitionEnd oTransitionEnd otransitionend MSTransitionEnd");a.children(":not(:eq("+o+"))").css({display:"none",left:0,zIndex:0});h.data.touch&&h._setuptouch();return h.options.callback.complete(o+1)})}return a.stop().animate({left:i},this.options.effect.slide.speed,function(){a.css({left:0});a.children(":eq("+o+")").css({left:0});return a.children(":eq("+r+")").css({display:"none",left:0,zIndex:0},e.data(h,"current",o),e.data(h,"animating",!1),h.options.callback.complete(o+1))})}};r.prototype._fade=function(t){var n,r,i,s,o,u=this;n=e(this.element);this.data=e.data(this);if(!this.data.animating&&t!==this.data.current+1){e.data(this,"animating",!0);r=this.data.current;if(t){t-=1;o=t>r?1:-1;i=t}else{o=this.data.direction==="next"?1:-1;i=r+o}i===-1&&(i=this.data.total-1);i===this.data.total&&(i=0);this._setActive(i);s=e(".slidesjs-control",n);s.children(":eq("+i+")").css({display:"none",left:0,zIndex:10});this.options.callback.start(r+1);if(this.options.effect.fade.crossfade){s.children(":eq("+this.data.current+")").stop().fadeOut(this.options.effect.fade.speed);return s.children(":eq("+i+")").stop().fadeIn(this.options.effect.fade.speed,function(){s.children(":eq("+i+")").css({zIndex:0});e.data(u,"animating",!1);e.data(u,"current",i);return u.options.callback.complete(i+1)})}return s.children(":eq("+r+")").stop().fadeOut(this.options.effect.fade.speed,function(){s.children(":eq("+i+")").stop().fadeIn(u.options.effect.fade.speed,function(){return s.children(":eq("+i+")").css({zIndex:10})});e.data(u,"animating",!1);e.data(u,"current",i);return u.options.callback.complete(i+1)})}};r.prototype._getVendorPrefix=function(){var e,t,r,i,s;e=n.body||n.documentElement;r=e.style;i="transition";s=["Moz","Webkit","Khtml","O","ms"];i=i.charAt(0).toUpperCase()+i.substr(1);t=0;while(t<s.length){if(typeof r[s[t]+i]=="string")return s[t];t++}return!1};return e.fn[s]=function(t){return this.each(function(){if(!e.data(this,"plugin_"+s))return e.data(this,"plugin_"+s,new r(this,t))})}})(jQuery,window,document)}).call(this);

//(function(a) {
//	var b = {
//		defaults: {
//			animation: "horizontal-push",
//			animationSpeed: 600,
//			timer: true,
//			advanceSpeed: 4e3,
//			pauseOnHover: false,
//			startClockOnMouseOut: false,
//			startClockOnMouseOutAfter: 1e3,
//			directionalNav: true,
//			captions: true,
//			captionAnimation: "fade",
//			captionAnimationSpeed: 600,
//			bullets: false,
//			bulletThumbs: false,//分页导航有背景图片
//			bulletThumbLocation: "",//分页导航有背景图片地址
//			afterSlideChange: a.noop,
//			fluid: true,
//			centerBullets: true//分页导航居中
//		},
//		activeSlide: 0,
//		numberSlides: 0,
//		orbitWidth: null,
//		orbitHeight: null,
//		locked: null,
//		timerRunning: null,
//		degrees: 0,
//		//外层添加的div
//		wrapperHTML: '<div class="orbit-wrapper"/>',
//		//计时器
//		timerHTML: '<div class="timer show-on-desktops"><span class="mask"><span class="rotator"></span></span><span class="pause"></span></div>',
//		captionHTML: '<div class="orbit-caption"></div>',
//		//轮显的左右（上一个、下一个）导航
//		directionalNavHTML: '<div class="slider-nav show-on-desktops"><span class="right">Right</span><span class="left">Left</span></div>',
//		//轮显的下部导航
//		bulletHTML: '<ul class="orbit-bullets"></ul>',
//		//初始化
//		init: function(b, c) {
//			var d,e = 0,f = this;
//			this.clickTimer = a.proxy(this.clickTimer, this);
//			this.addBullet = a.proxy(this.addBullet, this);
//			this.resetAndUnlock = a.proxy(this.resetAndUnlock, this);
//			this.stopClock = a.proxy(this.stopClock, this);
//			this.startTimerAfterMouseLeave = a.proxy(this.startTimerAfterMouseLeave, this);
//			this.clearClockMouseLeaveTimer = a.proxy(this.clearClockMouseLeaveTimer, this);
//			this.rotateTimer = a.proxy(this.rotateTimer, this);
//			this.options = a.extend({},this.defaults, c);
//			if (this.options.timer === "false") this.options.timer = false;
//			if (this.options.captions === "false") this.options.captions = false;
//			if (this.options.directionalNav === "false") this.options.directionalNav = false;
//			this.$element = a(b);
//			this.$wrapper = this.$element.wrap(this.wrapperHTML).parent();
//			this.$slides = this.$element.children("img, a, div");
//			this.$element.bind("orbit.next",function() {
//				f.shift("next")
//			});
//			this.$element.bind("orbit.prev",function() {
//				f.shift("prev")
//			});
//			this.$element.bind("orbit.goto",function(a, b) {
//				f.shift(b)
//			});
//			this.$element.bind("orbit.start",function(a, b) {
//				f.startClock()
//			});
//			this.$element.bind("orbit.stop",function(a, b) {
//				f.stopClock()
//			});
//			d = this.$slides.filter("img");
//			if (d.length === 0) {
//				this.loaded()
//			} else {
//				d.bind("imageready",function() {
//					e += 1;
//					if (e === d.length) {
//						f.loaded()
//					}
//				})
//			}
//		},
//		loaded: function() {
//			this.$element.addClass("orbit").css({width: "1px",height: "1px"});
//			this.setDimentionsFromLargestSlide();
//			this.updateOptionsIfOnlyOneSlide();
//			this.setupFirstSlide();
//			if (this.options.timer) {
//				this.setupTimer();
//				this.startClock()
//			}
//			if (this.options.captions) {
//				this.setupCaptions()
//			}
//			if (this.options.directionalNav) {
//				this.setupDirectionalNav()
//			}
//			if (this.options.bullets) {
//				this.setupBulletNav();
//				this.setActiveBullet()
//			}
//		},
//		currentSlide: function() {
//			return this.$slides.eq(this.activeSlide)
//		},
//		setDimentionsFromLargestSlide: function() {
//			var b = this,c;
//			b.$element.add(b.$wrapper).width(this.$slides.first().width());
//			b.$element.add(b.$wrapper).height(this.$slides.first().height());
//			b.orbitWidth = this.$slides.first().width();
//			b.orbitHeight = this.$slides.first().height();
//			c = this.$slides.first().clone();
//			this.$slides.each(function() {
//				var d = a(this),
//				e = d.width(),
//				f = d.height();
//				if (e > b.$element.width()) {
//					b.$element.add(b.$wrapper).width(e);
//					b.orbitWidth = b.$element.width()
//				}
//				if (f > b.$element.height()) {
//					b.$element.add(b.$wrapper).height(f);
//					b.orbitHeight = b.$element.height();
//					c = a(this).clone()
//				}
//				b.numberSlides += 1
//			});
//			if (this.options.fluid) {
//				if (typeof this.options.fluid === "string") {
//					c = a('<img src="http://placehold.it/' + this.options.fluid + '" />')
//				}
//				b.$element.prepend(c);
//				c.addClass("fluid-placeholder");
//				b.$element.add(b.$wrapper).css({
//					//width: "inherit"
//					//modify by wyr
//					width: "auto"
//				});
//				b.$element.add(b.$wrapper).css({
//					//height: "inherit"
//					//modify by wyr
//					height: "auto"
//				});
//				a(window).bind("resize",function() {
//					b.orbitWidth = b.$element.width();
//					b.orbitHeight = b.$element.height()
//				})
//			}
//		},
//		lock: function() {
//			this.locked = true
//		},
//		unlock: function() {
//			this.locked = false
//		},
//		updateOptionsIfOnlyOneSlide: function() {
//			if (this.$slides.length === 1) {
//				this.options.directionalNav = false;
//				this.options.timer = false;
//				this.options.bullets = false
//			}
//		},
//		setupFirstSlide: function() {
//			var a = this;
//			this.$slides.first().css({
//				"z-index": 3
//			}).fadeIn(function() {
//				a.$slides.css({
//					display: "block"
//				})
//			})
//		},
//		//开始计时
//		startClock: function() {
//			var a = this;
//			if (!this.options.timer) {
//				return false
//			}
//			if (this.$timer.is(":hidden")) {
//				this.clock = setInterval(function() {
//					//this.$element.trigger("orbit.next");
//					//modify by wyr
//					if(typeof this.$element != "undefined"){
//						this.$element.trigger("orbit.next");
//					}
//				},this.options.advanceSpeed)
//			} else {
//				this.timerRunning = true;
//				this.$pause.removeClass("active");
//				this.clock = setInterval(this.rotateTimer, this.options.advanceSpeed / 180)
//			}
//		},
//		//计时
//		rotateTimer: function() {
//			var a = "rotate(" + this.degrees + "deg)";
//			this.degrees += 2;
//			this.$rotator.css({
//				"-webkit-transform": a,
//				"-moz-transform": a,
//				"-o-transform": a
//			});
//			if (this.degrees > 180) {
//				this.$rotator.addClass("move");
//				this.$mask.addClass("move")
//			}
//			if (this.degrees > 360) {
//				this.$rotator.removeClass("move");
//				this.$mask.removeClass("move");
//				this.degrees = 0;
//				this.$element.trigger("orbit.next")
//			}
//		},
//		//停止计时
//		stopClock: function() {
//			if (!this.options.timer) {
//				return false
//			} else {
//				this.timerRunning = false;
//				clearInterval(this.clock);
//				this.$pause.addClass("active")
//			}
//		},
//		//启动计时器
//		setupTimer: function() {
//			this.$timer = a(this.timerHTML);
//			this.$wrapper.append(this.$timer);
//			this.$rotator = this.$timer.find(".rotator");
//			this.$mask = this.$timer.find(".mask");
//			this.$pause = this.$timer.find(".pause");
//			this.$timer.click(this.clickTimer);
//			if (this.options.startClockOnMouseOut) {
//				this.$wrapper.mouseleave(this.startTimerAfterMouseLeave);
//				this.$wrapper.mouseenter(this.clearClockMouseLeaveTimer)
//			}
//			if (this.options.pauseOnHover) {
//				this.$wrapper.mouseenter(this.stopClock)
//			}
//		},
//		startTimerAfterMouseLeave: function() {
//			var a = this;
//			this.outTimer = setTimeout(function() {
//				if (!a.timerRunning) {
//					a.startClock()
//				}
//			},this.options.startClockOnMouseOutAfter)
//		},
//		clearClockMouseLeaveTimer: function() {
//			clearTimeout(this.outTimer)
//		},
//		//停止与启动计时器
//		clickTimer: function() {
//			if (!this.timerRunning) {
//				this.startClock()
//			} else {
//				this.stopClock()
//			}
//		},
//		setupCaptions: function() {
//			this.$caption = a(this.captionHTML);
//			this.$wrapper.append(this.$caption);
//			this.setCaption()
//		},
//		setCaption: function() {
//			var b = this.currentSlide().attr("data-caption"),c;
//			if (!this.options.captions) {
//				return false
//			}
//			if (b) {
//				c = a(b).html();
//				this.$caption.attr("id", b).html(c);
//				switch (this.options.captionAnimation) {
//				case "none":
//					this.$caption.show();
//					break;
//				case "fade":
//					this.$caption.fadeIn(this.options.captionAnimationSpeed);
//					break;
//				case "slideOpen":
//					this.$caption.slideDown(this.options.captionAnimationSpeed);
//					break
//				}
//			} else {
//				switch (this.options.captionAnimation) {
//				case "none":
//					this.$caption.hide();
//					break;
//				case "fade":
//					this.$caption.fadeOut(this.options.captionAnimationSpeed);
//					break;
//				case "slideOpen":
//					this.$caption.slideUp(this.options.captionAnimationSpeed);
//					break
//				}
//			}
//		},
//		setupDirectionalNav: function() {
//			var a = this;
//			this.$wrapper.append(this.directionalNavHTML);
//			this.$wrapper.find(".left").click(function() {
//				a.stopClock();
//				a.$element.trigger("orbit.prev")
//			});
//			this.$wrapper.find(".right").click(function() {
//				a.stopClock();
//				a.$element.trigger("orbit.next")
//			})
//		},
//		setupBulletNav: function() {
//			this.$bullets = a(this.bulletHTML);
//			this.$wrapper.append(this.$bullets);
//			this.$slides.each(this.addBullet);
//			this.$element.addClass("with-bullets");
//			if (this.options.centerBullets) this.$bullets.css("margin-left", -this.$bullets.width() / 2)
//		},
//		//添加分页导航
//		addBullet: function(b, c) {
//			var d = b + 1,e = a("<li>" + d + "</li>"),f,g = this;
//			if (this.options.bulletThumbs) {
//				f = a(c).attr("data-thumb");
//				if (f) {
//					e.addClass("has-thumb").css({
//						background: "url(" + this.options.bulletThumbLocation + f + ") no-repeat"
//					})
//				}
//			}
//			this.$bullets.append(e);
//			e.data("index", b);
//			e.hover(function() {
//				g.stopClock();
//				g.$element.trigger("orbit.goto", [e.data("index")])
//			})
//		},
//		//设置当前页的样式
//		setActiveBullet: function() {
//			if (!this.options.bullets) {
//				return false
//			} else {
//				this.$bullets.find("li").removeClass("active").eq(this.activeSlide).addClass("active")
//			}
//		},
//		resetAndUnlock: function() {
//			this.$slides.eq(this.prevActiveSlide).css({
//				"z-index": 1
//			});
//			this.unlock();
//			this.options.afterSlideChange.call(this, this.$slides.eq(this.prevActiveSlide), this.$slides.eq(this.activeSlide))
//		},
//		//翻转
//		shift: function(a) {
//			var b = a;
//			this.prevActiveSlide = this.activeSlide;
//			if (this.prevActiveSlide == b) {
//				return false
//			}
//			if (this.$slides.length == "1") {
//				return false
//			}
//			if (!this.locked) {
//				this.lock();
//				if (a == "next") {
//					this.activeSlide++;
//					if (this.activeSlide == this.numberSlides) {
//						this.activeSlide = 0
//					}
//				} else if (a == "prev") {
//					this.activeSlide--;
//					if (this.activeSlide < 0) {
//						this.activeSlide = this.numberSlides - 1
//					}
//				} else {
//					this.activeSlide = a;
//					if (this.prevActiveSlide < this.activeSlide) {
//						b = "next"
//					} else if (this.prevActiveSlide > this.activeSlide) {
//						b = "prev"
//					}
//				}
//				this.setActiveBullet();
//				this.$slides.eq(this.prevActiveSlide).css({
//					"z-index": 2
//				});
//				if (this.options.animation == "fade") {
//					this.$slides.eq(this.activeSlide).css({
//						opacity: 0,
//						"z-index": 3
//					}).animate({
//						opacity: 1
//					},
//					this.options.animationSpeed, this.resetAndUnlock)
//				}
//				if (this.options.animation == "horizontal-slide") {
//					if (b == "next") {
//						this.$slides.eq(this.activeSlide).css({
//							left: this.orbitWidth,
//							"z-index": 3
//						}).animate({
//							left: 0
//						},
//						this.options.animationSpeed, this.resetAndUnlock)
//					}
//					if (b == "prev") {
//						this.$slides.eq(this.activeSlide).css({
//							left: -this.orbitWidth,
//							"z-index": 3
//						}).animate({
//							left: 0
//						},
//						this.options.animationSpeed, this.resetAndUnlock)
//					}
//				}
//				if (this.options.animation == "vertical-slide") {
//					if (b == "prev") {
//						this.$slides.eq(this.activeSlide).css({
//							top: this.orbitHeight,
//							"z-index": 3
//						}).animate({
//							top: 0
//						},
//						this.options.animationSpeed, this.resetAndUnlock)
//					}
//					if (b == "next") {
//						this.$slides.eq(this.activeSlide).css({
//							top: -this.orbitHeight,
//							"z-index": 3
//						}).animate({
//							top: 0
//						},
//						this.options.animationSpeed, this.resetAndUnlock)
//					}
//				}
//				if (this.options.animation == "horizontal-push") {
//					if (b == "next") {
//						this.$slides.eq(this.activeSlide).css({
//							left: this.orbitWidth,
//							"z-index": 3
//						}).animate({
//							left: 0
//						},
//						this.options.animationSpeed, this.resetAndUnlock);
//						this.$slides.eq(this.prevActiveSlide).animate({
//							left: -this.orbitWidth
//						},
//						this.options.animationSpeed)
//					}
//					if (b == "prev") {
//						this.$slides.eq(this.activeSlide).css({
//							left: -this.orbitWidth,
//							"z-index": 3
//						}).animate({
//							left: 0
//						},
//						this.options.animationSpeed, this.resetAndUnlock);
//						this.$slides.eq(this.prevActiveSlide).animate({
//							left: this.orbitWidth
//						},
//						this.options.animationSpeed)
//					}
//				}
//				if (this.options.animation == "vertical-push") {
//					if (b == "next") {//alert(this.$slides.eq(this.activeSlide).css('top'));
//						this.$slides.eq(this.activeSlide).css({
//							top: -this.orbitHeight,
//							"z-index": 3
//						});
//						this.$slides.eq(this.activeSlide).animate({
//							top: 0
//						},this.options.animationSpeed, this.resetAndUnlock);
//						this.$slides.eq(this.prevActiveSlide).animate({
//							top: this.orbitHeight
//						},this.options.animationSpeed);
//						//alert(this.$slides.eq(this.prevActiveSlide).css('top'));
//					}
//					if (b == "prev") {
//						this.$slides.eq(this.activeSlide).css({
//							top: this.orbitHeight,
//							"z-index": 3
//						}).animate({
//							top: 0
//						},this.options.animationSpeed, this.resetAndUnlock);
//						this.$slides.eq(this.prevActiveSlide).animate({
//							top: -this.orbitHeight
//						},this.options.animationSpeed)
//					}
//				}
//				this.setCaption()
//			}
//		}
//	};
//	a.fn.orbit = function(c) {
//		return this.each(function() {
//			var d = a.extend({},b);
//			d.init(this, c)
//		})
//	}
//})(jQuery);