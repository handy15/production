// JavaScript Document
//首页脚本
function index(){
	substring();
	setNav();
	photoSolid($(".solidimg"));
	correctPNG();
	//接口
	var rrtInterface = "http://rrt_oapi.jsve.edu.cn";
	var learder={
		app:'rrt',
		limit:8
	}
	var school={
		app:'rrt',
		limit:10
	}
	var teacher={
		app:'rrt',
		limit:12
	}
	var student={
		app:'rrt',
		limit:12
	}
	var dynamic={
		app:'rrt',
		limit:10
	}
	//领军人才空间
	$.getJSON(rrtInterface + "/api/leader?jsoncallback=?", learder, function(response){
		if(response.status == "success"){
			var html = '';
			$.each(response.data,function(index,element){
				var imgsrc = element.avatar ? element.avatar : "images/noPicture.jpg";
				var str_tag = element.tag ? element.tag : "";
				html += '<dl class="learder">';
				html += '<dt><a href="' + element.url +'" target="_blank"><img src="' + imgsrc +'" height="61" alt="' + element.name +'" /></a></dt>';
				html += '<dd>';
				html += '<p><a href="' + element.url +'" target="_blank" title="' + element.name +'" ellipsis="10">' + element.name +'</a></p>';
				html += '<p ellipsis="20" title="' + str_tag +'">' + str_tag +'</p>';
				html += '</dd></dl>';
			});
			$("#leader").empty().html(html);
			substring();
		}
	});
	//学校空间
	$.getJSON(rrtInterface + "/api/school?jsoncallback=?", school, function(response){
		if(response.status == "success"){
			var html = '';
			$.each(response.data,function(index,element){
				var imgsrc = element.avatar ? element.avatar : "images/noPicture.jpg";
				if(index % 2 == 0){
					html += '<li>';
				}else{
					html += '<li class="alt">';
				}
				html += '<span class="spaceXX-img"><a href="' + element.url +'" target="_blank"><img src="' + imgsrc +'" height="80" alt="' + element.name +'" /></a></span>';
				html += '<span class="spaceXX-txt"><a href="' + element.url +'" target="_blank" title="' + element.name +'" ellipsis="10">' + element.name +'</a></span>';
				html += '</li>';
			});
			$("#school").empty().html(html);
			substring();
		}
	});
	//教师空间
	$.getJSON(rrtInterface + "/api/teacher?jsoncallback=?", teacher, function(response){
		if(response.status == "success"){
			var html = '';
			$.each(response.data,function(index,element){
				var imgsrc = element.avatar ? element.avatar : "images/noPicture.jpg";
				html += '<li>';
				html += '<span class="spaceXX-img"><a href="' + element.url +'" target="_blank"><img src="' + imgsrc +'" height="80" alt="' + element.name +'" /></a></span>';
				html += '<span class="spaceXX-txt"><a href="' + element.url +'" target="_blank" title="' + element.name +'" ellipsis="10">' + element.name +'</a></span>';
				html += '</li>';
			});
			$("#teacher").empty().html(html);
			substring();
		}
	});
	//学生空间
	$.getJSON(rrtInterface + "/api/student?jsoncallback=?", student, function(response){
		if(response.status == "success"){
			var html = '';
			$.each(response.data,function(index,element){
				var imgsrc = element.avatar ? element.avatar : "images/noPicture.jpg";
				html += '<li>';
				html += '<span class="spaceXX-img"><a href="' + element.url +'" target="_blank"><img src="' + imgsrc +'" height="80" alt="' + element.name +'" /></a></span>';
				html += '<span class="spaceXX-txt"><a href="' + element.url +'" target="_blank" title="' + element.name +'" ellipsis="10">' + element.name +'</a></span>';
				html += '</li>';
			});
			$("#student").empty().html(html);
			substring();
		}
	});
	//动态信息
	$.getJSON(rrtInterface + "/api/dynamic?jsoncallback=?", learder, function(response){
		if(response.status == "success"){
			var html = '';
			$.each(response.data,function(index,element){
				html += '<li>' + element.content + '</li>';
				
			});
			$("#dynamic").empty().html(html);
		}
		scrollInfo($(".dyInfo ul"));
	});
}
//列表页脚本
function list(){
	substring();
	setNav();
	correctPNG();
}
//内容页脚本
function detail(){
	setNav();
	correctPNG();
}

function isUndefined(s){
	return typeof s==="undefined";
}
function isObject(object){
	return typeof object==="object";
}

//截取列表字符长度
var substring = function () {
    $("[ellipsis]").each(function () {
        var $this = $(this);
        var $length = $this.attr("ellipsis") || 20;
        $this.html(subStrAtLen($this.text(), $length));
    });
};

var subStrAtLen = function (assignStr, assignLen) {
    var len = 0;
    var i = 0;
    var flag = 0;
    var tsubstr = '';
    for (; i < assignStr.length; i++) {
        if (assignStr.charCodeAt(i) > 255 || assignStr.charCodeAt(i) < 0) {
            len += 2;
        } else {
            len++;
        }
        if (assignLen < len) {
            tsubstr = assignStr.substr(0, i) + '<label style=\"font-family:Arial;\">...</label>';
            break;
        } else {
            tsubstr = assignStr;
        }
    }
    return tsubstr;
};

function scrollInfo(obj){
	var $this = obj;
	var scrollTimer = null;
	var childrenLen = $this.children().length;
	if(childrenLen > 1){
		$this.hover(function(){
			clearInterval(scrollTimer);
		},function(){
			scrollTimer = setInterval(function(){
				var lineHeight = $this.children().eq(0).height(); 
				$this.animate({ "marginTop" : -lineHeight +"px" }, 600 , function(){
					$this.css({marginTop:0}).children().eq(0).appendTo($this); 
				})
			}, 3000);
		}).trigger("mouseleave");
	}	
}

//图片轮显
function photoSolid(obj){
	if(isObject(obj)){
		var $container = obj;
		//Set Default State of each portfolio piece
		//$(".paging").show();
		//$(".paging a:first").addClass("active");
		//Get size of images, how many there are, then determin the size of the image reel.
		var imageSum = $container.find(".image_reel").children().size();
		if(1 < imageSum){
			//render page
			var htmlPage = '<div class="paging">';
			$container.addClass("window-solid");
			for(var i=1;i<=imageSum;i++){
				if(i==1){
					htmlPage += '<a href="javascript:;" class="pagingActive" rel="' + i + '">' + i + '</a>';
				}else{
					htmlPage += '<a href="javascript:;" rel="' + i + '">' + i + '</a>';
				}
			}
			htmlPage += '</div>';
			$container.append(htmlPage);
			var imageWidth = $container.width();
			var imageReelWidth = imageWidth * imageSum;
			//Adjust the image reel to its new size
			$container.find(".image_reel").width(imageReelWidth+3);
			//Paging + Slider Function
			rotate = function(){
				var triggerID = $active.attr("rel") - 1; //Get number of times to slide
				var image_reelPosition = triggerID * imageWidth; //Determines the distance the image reel needs to slide
				$container.find(".paging a").removeClass('pagingActive'); //Remove all active class
				$active.addClass('pagingActive'); //Add active class (the $active is declared in the rotateSwitch function)
				//Slider Animation
				$container.find(".image_reel").animate({ 
					left: -image_reelPosition
				}, 500);
			}; 
			//Rotation + Timing Event
			rotateSwitch = function(){		
				play = setInterval(function(){ //Set timer - this will repeat itself every 3 seconds
					$active = $container.find('.paging a.pagingActive').next();
					if ( $active.length === 0) { //If paging reaches the end...
						$active = $container.find('.paging a:first'); //go back to first
					}
					rotate(); //Trigger the paging and slider function
				}, 4000); //Timer speed in milliseconds (3 seconds)
			};
			rotateSwitch(); //Run function on launch
			//On Hover
			$container.find(".image_reel").hover(function() {
				clearInterval(play); //Stop the rotation
			}, function() {
				rotateSwitch(); //Resume rotation
			});	
			//On Click
			$container.find(".paging a").live("click",function() {	
				$active = $(this); //Activate the clicked paging
				//Reset Timer
				clearInterval(play); //Stop the rotation
				rotate(); //Trigger rotation immediately
				rotateSwitch(); // Resume rotation
				return false; //Prevent browser jump to link anchor
			});	
		}
	}
}
//图片透明
function correctPNG(){
	if (!window.XMLHttpRequest){
		for(var i=0; i<document.images.length; i++) { 
			var img = document.images[i];
			if($(img).attr('flag') == 'transparent'){
				var imgName = img.src.toUpperCase();
				if (imgName.substring(imgName.length-3, imgName.length) == "PNG"){ 
					var imgID = (img.id) ? "id='" + img.id + "' " : "" 
					var imgClass = (img.className) ? "class='" + img.className + "' " : "" 
					var imgTitle = (img.title) ? "title='" + img.title + "' " : "title='" + img.alt + "' " 
					var imgStyle = "display:inline-block;" + img.style.cssText  
					if (img.align == "left") imgStyle = "float:left;" + imgStyle 
					if (img.align == "right") imgStyle = "float:right;" + imgStyle 
					if (img.parentElement.href) imgStyle = "cursor:hand;" + imgStyle   
					var strNewHTML = "<span " + imgID + imgClass + imgTitle 
					+ " style=\"" + "width:" + img.width + "px; height:" + img.height + "px;" + imgStyle + ";" 
					+ "filter:progid:DXImageTransform.Microsoft.AlphaImageLoader" 
					+ "(src=\'" + img.src + "\', sizingMethod='scale');\"></span>"  
					img.outerHTML = strNewHTML 
					i = i-1 
				}
			}
		}
	}
}

//导航菜单
function setNav(){
	//遍历添加图标样式
	$(".navigation").children("li").each(function(index,element){
		var $childLi = $(element).find("ul li");
		$(element).children("a").addClass("icon" + (index+1));
		if(0 != $childLi.length){
			$childLi.each(function(subIndex,subElement){
				$(subElement).children("a").addClass("icon" + (index+1) + (subIndex+1));
			});
			$(element).hover(function(){
				$(element).addClass("menu-list").children("ul").show();
			},function(){
				$(element).removeClass("menu-list").children("ul").hide();
			});
		}
	});
	$(".navigation li").hover(function(){
		$(this).addClass("liOn");
	},function(){
		$(this).removeClass("liOn");
	});
	//if (!window.XMLHttpRequest){
//		DD_belatedPNG.fix('.navigation li a,.navigation li.menu-list ul');
//	}
}