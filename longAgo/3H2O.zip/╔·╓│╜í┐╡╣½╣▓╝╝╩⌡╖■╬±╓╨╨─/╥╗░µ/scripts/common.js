﻿//截取列表字符长度
var substring = function () {
    $("[ellipsis]").each(function () {
        var $this = $(this);
        var $length = $this.attr("ellipsis") || 20;
        $this.html(subStrAtLen($this.text(), $length));
    });
};

var subStrAtLen = function (assignStr, assignLen) {
    var len = 0;
    var i = 0;
    var flag = 0;
    var tsubstr = '';
    for (; i < assignStr.length; i++) {
        if (assignStr.charCodeAt(i) > 255 || assignStr.charCodeAt(i) < 0) {
            len += 2;
        } else {
            len++;
        }
        if (assignLen < len) {
            tsubstr = assignStr.substr(0, i) + '<label style=\"font-family:Arial;\">...</label>';
            break;
        } else {
            tsubstr = assignStr;
        }
    }
    return tsubstr;
};

//获取当前时间
var getCurrentTime = function ($object) {
    var curTime = new Date();
    $object.html(curTime.getFullYear() + '年'
        + (curTime.getMonth() + 1)
        + '月' + curTime.getDate()
        + '日'
        + '&nbsp;&nbsp;&nbsp;星期'
        + '日一二三四五六'.charAt(curTime.getDay()));
};
var getFullTime = function (time) {
    if (time < 10) {
        return '0' + time.toString();
    } else {
        return time.toString();
    }
};

function isUndefined(s){
	return typeof s==="undefined";
}
function isObject(object){
	return typeof object==="object";
}

function keywords($object,value){
	$object = isObject($object) ? $object : null;
	if($object!=null && !isUndefined($object.val())){
		$object.val(value);
		$object.focusin(function(){
			var textValue=$object.val();
			$object.css('color','#000');
			if(textValue.length == 0 || textValue == value){
				$object.val("");
			}
		}).focusout(function(){
			var textValue=$object.val();
			$object.css('color','');
			if(textValue.length == 0 || textValue == value)
			$object.val(value);
		})
	}
}

function altClass($object,eventType,activeClass){
	$object = isObject($object) ? $object : null; //alert($object);
	eventType = isUndefined(eventType) ? "mouseover" : eventType;//alert(eventType);
	activeClass = isUndefined(activeClass) ? "" : activeClass;//alert(activeClass);
	$object.live(eventType,function(e){
		$thisItem = $(this);
		$object.removeClass(activeClass);
		$thisItem.addClass(activeClass);
	})
}

function tab($object,eventType,activeClass){
	//alert(eventType);
	$object = isObject($object) ? $object : null;
	eventType = isUndefined(eventType) ? "mouseover" : eventType;
	activeClass = isUndefined(activeClass) ? "" : activeClass;
	$object.bind(eventType,function(e){
		//选中的菜单
		var $thisMenu = $(this);
		//菜单长度
		var menuLength = $object.length;
		for(var i=0; i<menuLength; i++){
			//统计菜单id值
			var menuid = $object.eq(i).attr('id');
			//隐藏对应菜单的div
			$('#'+menuid+'Div').hide();
		}
		//移除菜单样式
		$object.removeClass(activeClass);
		//设置当前菜单的样式
		$thisMenu.addClass(activeClass);
		//显示当前菜单对应的div
		$('#'+$thisMenu.attr('id')+'Div').show();
	});
}
function correctPNG(){ 
	for(var i=0; i<document.images.length; i++) { 
		var img = document.images[i];
		if($(img).attr('flag') == 'transparent'){
			var imgName = img.src.toUpperCase();
			if (imgName.substring(imgName.length-3, imgName.length) == "PNG"){ 
				var imgID = (img.id) ? "id='" + img.id + "' " : "" 
				var imgClass = (img.className) ? "class='" + img.className + "' " : "" 
				var imgTitle = (img.title) ? "title='" + img.title + "' " : "title='" + img.alt + "' " 
				var imgStyle = "display:inline-block;" + img.style.cssText  
				if (img.align == "left") imgStyle = "float:left;" + imgStyle 
				if (img.align == "right") imgStyle = "float:right;" + imgStyle 
				if (img.parentElement.href) imgStyle = "cursor:hand;" + imgStyle   
				var strNewHTML = "<span " + imgID + imgClass + imgTitle 
				+ " style=\"" + "width:" + img.width + "px; height:" + img.height + "px;" + imgStyle + ";" 
				+ "filter:progid:DXImageTransform.Microsoft.AlphaImageLoader" 
				+ "(src=\'" + img.src + "\', sizingMethod='scale');\"></span>"  
				img.outerHTML = strNewHTML 
				i = i-1 
			}
		}
	} 
}