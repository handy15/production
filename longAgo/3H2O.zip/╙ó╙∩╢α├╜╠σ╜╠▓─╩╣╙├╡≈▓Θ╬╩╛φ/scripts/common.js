﻿$(function(){
    setInterval(getCurrentTime, 1000);
    //截取字符串
    substring();
});

//截取列表字符长度
var substring = function () {
    $("[ellipsis]").each(function () {
        var $this = $(this);
        var $length = $this.attr("ellipsis") || 20;
        $this.html(subStrAtLen($this.text(), $length));
    });
};
var subStrAtLen = function (assignStr, assignLen) {
    var len = 0;
    var i = 0;
    var flag = 0;
    var tsubstr = '';
    for (; i < assignStr.length; i++) {
        if (assignStr.charCodeAt(i) > 255 || assignStr.charCodeAt(i) < 0) {
            len += 2;
        } else {
            len++;
        }
        if (assignLen < len) {
            tsubstr = assignStr.substr(0, i) + '<label style=\"font-family:Arial;\">...</label>';
            break;
        } else {
            tsubstr = assignStr;
        }
    }
    return tsubstr;
};
//获取当前时间
var getCurrentTime = function () {
    var curTime = new Date();
    $("#CurrentTime").html(curTime.getFullYear() + '年'
        + (curTime.getMonth() + 1)
        + '月' + curTime.getDate()
        + '日' //+ getFullTime(curTime.getHours()) + ':'
       // + getFullTime(curTime.getMinutes()) + ':'
       // + getFullTime(curTime.getSeconds())
        + '&nbsp;星期'
        + '日一二三四五六'.charAt(curTime.getDay()));
};
var getFullTime = function (time) {

    if (time < 10) {
        return '0' + time.toString();
    } else {
        return time.toString();
    }
};
function isUndefined(s){
	return typeof s==="undefined";
}
function isObject(object){
	return typeof object==="object";
}
//input:text value值的显示与隐藏
function keywords($object,value){
	$object = isObject($object) ? $object : null;
	if($object!=null && !isUndefined($object.val())){
		$object.val(value);
		$object.focusin(function(){
			var textValue=$object.val();
			$object.css('color','#b8b9b9');
			if(textValue.length == 0 || textValue == value){
				$object.val("");
			}
		}).focusout(function(){
			var textValue=$object.val();
			$object.css('color','');
			if(textValue.length == 0 || textValue == value)
			$object.val(value);
		})
	}
}
function tab($object,eventType,activeClass){
	//alert(eventType);
	$object = isObject($object) ? $object : null;
	eventType = isUndefined(eventType) ? "mouseover" : eventType;
	activeClass = isUndefined(activeClass) ? "" : activeClass;
	$object.bind(eventType,function(e){
		//选中的菜单
		var $thisMenu = $(this);
		//菜单长度
		var menuLength = $object.length;
		for(var i=0; i<menuLength; i++){
			//统计菜单id值
			var menuid = $object.eq(i).attr('id');
			//隐藏对应菜单的div
			$('#'+menuid+'Div').hide();
		}
		//移除菜单样式
		$object.removeClass(activeClass);
		//设置当前菜单的样式
		$thisMenu.addClass(activeClass);
		//显示当前菜单对应的div
		$('#'+$thisMenu.attr('id')+'Div').show();
	});
}	
	//回到顶部滚动条显示隐藏
  $(window).scroll(function (){
	  var scrollTop=$(document).scrollTop();
	  $('#base_scrollToTop').css('top',scrollTop+500+'px');
	  if(scrollTop>0){$('#base_scrollToTop').css('display','block');}
	  else{$('#base_scrollToTop').css('display','none');}
	  });
 //返回顶部
 /**
 * 回到页面顶部
 * @param acceleration 加速度
 * @param time 时间间隔 (毫秒)
 **/
function goTop(acceleration, time) {
 acceleration = acceleration || 1;
 time = time || 1;
 var x1 = 0;
 var y1 = 0;
 var x2 = 0;
 var y2 = 0;
 var x3 = 0;
 var y3 = 0;
 if (document.documentElement) {
  x1 = document.documentElement.scrollLeft || 0;
  y1 = document.documentElement.scrollTop || 0;
 }
 if (document.body) {
  x2 = document.body.scrollLeft || 0;
  y2 = document.body.scrollTop || 0;
 }
 var x3 = window.scrollX || 0;
 var y3 = window.scrollY || 0;
 // 滚动条到页面顶部的水平距离
 var x = Math.max(x1, Math.max(x2, x3));
 // 滚动条到页面顶部的垂直距离
 var y = Math.max(y1, Math.max(y2, y3));
 // 滚动距离 = 目前距离 / 速度, 因为距离原来越小, 速度是大于 1 的数, 所以滚动距离会越来越小
 var speed = 1 + acceleration;
 window.scrollTo(Math.floor(x / speed), Math.floor(y / speed));
 // 如果距离不为零, 继续调用迭代本函数
 if(x > 0 || y > 0) {
  var invokeFunction = "goTop(" + acceleration + ", " + time + ")";
  window.setTimeout(invokeFunction, time);
 }
}
