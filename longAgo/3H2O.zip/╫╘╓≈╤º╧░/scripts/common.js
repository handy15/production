﻿$(function () {
    //截字符串
    substring();
    //菜单导航
	$(".navigation li").hover(function () {
	$(this).addClass('actived');
	$('#subMenu').show();
	$(this).children("ul").show();
	if($(this).children("ul").children('li').length==0){
		$('#subMenu').append('<div style=\"padding-left:22px; line-height:29px;\">欢迎进入学生自主学习平台！</div>');
		}else{
			calculatePosition(this);
			}
	  }, function () {
		  $('#subMenu').empty();
		  $(this).removeClass('actived');
		  $(this).children("ul").hide();
		  $('#subMenu').hide();
	  });
	//二级菜单
	$(".navigation li ul li").hover(function(){
		$(this).addClass('actived');
		$('#subMenu').empty();
		$('#subMenu').show();
		},function(){
			$(this).removeClass('actived');
			$('#subMenu').hide();
			});
 });

//截取列表字符长度
var substring = function () {
    $("[ellipsis]").each(function () {
        var $this = $(this);
        var $length = $this.attr("ellipsis") || 20;
        $this.html(subStrAtLen($this.text(), $length));
    });
};

var subStrAtLen = function (assignStr, assignLen) {
    var len = 0;
    var i = 0;
    var flag = 0;
    var tsubstr = '';
    for (; i < assignStr.length; i++) {
        if (assignStr.charCodeAt(i) > 255 || assignStr.charCodeAt(i) < 0) {
            len += 2;
        } else {
            len++;
        }
        if (assignLen < len) {
            tsubstr = assignStr.substr(0, i) + '<label style=\"font-family:Arial;\">...</label>';
            break;
        } else {
            tsubstr = assignStr;
        }
    }
    return tsubstr;
};

function getStr(assignStr, assignLen) {
    var len = 0;
    var i = 0;
    var flag = 0;
    var tsubstr = '';
    for (; i < assignStr.length; i++) {
        if (assignStr.charCodeAt(i) > 255 || assignStr.charCodeAt(i) < 0) {
            len += 2;
        } else {
            len++;
        }
        if (assignLen < len) {
            tsubstr = assignStr.substr(0, i);
            break;
        } else {
            tsubstr = assignStr;
        }
    }
    return tsubstr;
};

function isUndefined(s){
	return typeof s==="undefined";
}
function isObject(object){
	return typeof object==="object";
}

function keywords($object,value){
	$object = isObject($object) ? $object : null;
	if($object!=null && !isUndefined($object.val())){
		$object.val(value);
		$object.focusin(function(){
			var textValue=$object.val();
			$object.css('color','#000');
			if(textValue.length == 0 || textValue == value){
				$object.val("");
			}
		}).focusout(function(){
			var textValue=$object.val();
			$object.css('color','');
			if(textValue.length == 0 || textValue == value)
			$object.val(value);
		})
	}
}
//计算二级菜单的位置
function calculatePosition(object){
	var $parentLi=$(object);
	var paddingWidth=0;//每个一级菜单的padding宽度,当padding设置在li上时需要此值
	var subPaddingWidth=0;//每个二级菜单的padding宽度,当padding设置在li上时需要此值
	if($parentLi){
		var thisWidth=$parentLi.width()+paddingWidth;//一级菜单li的宽度
		var parentNavWidth=$parentLi.parents('.menu').width();//菜单总宽度
		var totalWidth=0;//每个一级菜单下 二级菜单总宽度
		var plWidth=0;//当前一级菜单的中心距离菜单menu最左端的距离
		var prWidth=0;//当前一级菜单的中心距离菜单menu最右端的距离
		for(var j=0;j<=$parentLi.index();j++){
			if(j==$parentLi.index()){
				plWidth=plWidth+thisWidth/2;
				}else{
			    var $allPli=$(".navigation>li");
				plWidth=plWidth+$allPli.eq(j).width()+paddingWidth;
				}
			}
		prWidth=parentNavWidth-plWidth;
		var liLength= $parentLi.find("ul li").length;//每个一级菜单下 子菜单的个数
		for(var i=0;i<liLength;i++){
			var liWidth=$parentLi.find("ul li").eq(i).width()+subPaddingWidth;
			totalWidth=totalWidth+liWidth;
		}
		if (!window.XMLHttpRequest){//识别 ie6
			$parentLi.children("ul").css('width',totalWidth+liLength*subPaddingWidth+'px');
		}
		//offseLeft 相对位移
		var offsetLeft=(totalWidth)/2;
		if(offsetLeft<plWidth&&offsetLeft<prWidth){
			 var left=plWidth-offsetLeft;
			 $parentLi.children("ul").css('left',left+'px');
			}else if(offsetLeft>plWidth){
				$parentLi.children("ul").css('left','0px');
				}else if(offsetLeft>prWidth){
					var left=parentNavWidth-totalWidth;
					$parentLi.children("ul").css('left',left+'px');
					}
	}
}

function altClass($object,eventType,activeClass){
	$object = isObject($object) ? $object : null; //alert($object);
	eventType = isUndefined(eventType) ? "mouseover" : eventType;//alert(eventType);
	activeClass = isUndefined(activeClass) ? "" : activeClass;//alert(activeClass);
	$object.live(eventType,function(e){
		$thisItem = $(this);
		$object.removeClass(activeClass);
		$thisItem.addClass(activeClass);
	})
}

function tab($object,eventType,activeClass){
	//alert(eventType);
	$object = isObject($object) ? $object : null;
	eventType = isUndefined(eventType) ? "mouseover" : eventType;
	activeClass = isUndefined(activeClass) ? "" : activeClass;
	$object.bind(eventType,function(e){
		//选中的菜单
		var $thisMenu = $(this);
		//菜单长度
		var menuLength = $object.length;
		for(var i=0; i<menuLength; i++){
			//统计菜单id值
			var menuid = $object.eq(i).attr('id');
			//隐藏对应菜单的div
			$('#'+menuid+'Div').hide();
		}
		//移除菜单样式
		$object.removeClass(activeClass);
		//设置当前菜单的样式
		$thisMenu.addClass(activeClass);
		//显示当前菜单对应的div
		$('#'+$thisMenu.attr('id')+'Div').show();
	});
}
//初始化Dialog
function dialog_Define(id,title,width,height) {
	var $object = $(""+id+"");
	$object.dialog({
		title: title,
		modal: true,
		autoOpen: false,
		resizable:false,
		width: width,
		height: height,
		close: function () {
			// Dialog关闭前操作
		},
		buttons: {
		}
	});
}
	//图片轮显
	function photoSolid(){
		//Set Default State of each portfolio piece
		$(".paging").show();
		$(".paging a:first").addClass("active");
		//Get size of images, how many there are, then determin the size of the image reel.
		var imageWidth = $(".window-solid").width();
		var imageSum = $(".image_reel img").size();
		var imageReelWidth = imageWidth * imageSum;
		//Adjust the image reel to its new size
		$(".image_reel").css({'width' : imageReelWidth});
		//Paging + Slider Function
		rotate = function(){	
			var triggerID = $active.attr("rel") - 1; //Get number of times to slide
			var image_reelPosition = triggerID * imageWidth; //Determines the distance the image reel needs to slide
			$(".paging a").removeClass('active'); //Remove all active class
			$active.addClass('active'); //Add active class (the $active is declared in the rotateSwitch function)
			//Slider Animation
			$(".image_reel").animate({ 
				left: -image_reelPosition
			}, 500);
		}; 
		//Rotation + Timing Event
		rotateSwitch = function(){		
			play = setInterval(function(){ //Set timer - this will repeat itself every 3 seconds
				$active = $('.paging a.active').next();
				if ( $active.length === 0) { //If paging reaches the end...
					$active = $('.paging a:first'); //go back to first
				}
				rotate(); //Trigger the paging and slider function
			}, 4000); //Timer speed in milliseconds (3 seconds)
		};
		rotateSwitch(); //Run function on launch
		//On Hover
		$(".image_reel a").hover(function() {
			clearInterval(play); //Stop the rotation
		}, function() {
			rotateSwitch(); //Resume rotation
		});	
		//On Click
		$(".paging a").click(function() {	
			$active = $(this); //Activate the clicked paging
			//Reset Timer
			clearInterval(play); //Stop the rotation
			rotate(); //Trigger rotation immediately
			rotateSwitch(); // Resume rotation
			return false; //Prevent browser jump to link anchor
		});	
	}
