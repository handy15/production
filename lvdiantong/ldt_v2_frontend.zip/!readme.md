# 绿电通v2 前端开发规则4

标签（空格分隔）： 绿电通

---

## 静态页面 （通用规则）

* 页面的头用`header`标签包裹
* 页面的内容体用`section`标签包裹，并指定`name`属性
* js调用放在`body`最后

## JavaScript 调用规则

> JS采用AMD规范，使用requireJs 加载，无需手工写script标签进行加载。

> 加载库的方式如下：

```html
<script id="J_module" data-name="index" data-dep="swiper"></script>
```
**属性说明：**

* `data-name` : 要加载的js文件名 *注意不要加.js*

* `data-dep` : 依赖库，可多个，用 `,` 隔开


##表单规则

* 凡是需要验证的表单元素，必须有一个`label`,且指定`for = "[元素ID]"`
* 需要验证的元素，指定`data-valid`，该属性赋值时不要使用`"`包裹

    > `data-valid` 有两个属性，如下：
    * `required:  [true|false] ` 指定是否是必填
    * `rule: [正则表达式]`  指定需要验证值的格式 
    *ex：* 
    ```html
    <input type="text" name="userNum" placeholder="户号" id="cardId" data-valid={require:true,rule:"^(\\d{10}|\\d{24})$"}>
    ```
    *`data-vaild`的值直接给json，不要给字符串*
    `rule` 的正则表达式中的`\`必须用`\\`来转义

## JS对样式修正 (仅限宽、高)
    
> 在需要修正宽高的元素上加`data-calc`属性

* `data-calc` 接受一个json值，不用`"`包裹
* 属性说明：
    * `type: [height|width] `: 要修正的样式类型，宽或高
    * `base: 数组 ` :  基准元素的数组
    * `exp:` 按像素计算的计算表达式，用到的基准元素按照base数组的索引填入表达式内，例如：`{0} - 100`。