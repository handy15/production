
requirejs.config({
    baseUrl: '/assets/js',
    paths: {
        "jquery": 'libs/jquery.min',
        "swiper": 'libs/swiper.jquery.min',
        "wxApi": 'jweixin-1.0.0',
        "sweetalert": 'libs/sweetalert.min',
        "dropload": 'libs/dropload.min',
        "fastclick": 'libs/fastclick',
        "zepto": 'libs/zepto.min',
        "APP": 'libs/APP',


    },
    shim: {
        app: ['jquery'],
        swiper: ['jquery'],
        card: ['jquery'],
        wxunity: ['wxApi']
    }
});
function parse_str(query_str){
    var s = query_str.split("&");
    var result = {};
    for(var i=0;i<s.length;i++){
        var d=s[i].split("=");
        var script = "result."+d[0]+" = '"+d[1]+"';";
        eval(script);
    }
    return result;
}

function setCookie(name,value,expiresHours){
    var cookieString=name+"="+encodeURIComponent(value)+"; path=/";
    //判断是否设置过期时间
    if(expiresHours>0){
        var date=new Date();
        date.setTime(date.getTime+expiresHours*3600*1000);
        cookieString=cookieString+"; expires="+date.toGMTString();
    }
    document.cookie=cookieString;
}

function getCookie(name){
    var strCookie=document.cookie;
    var arrCookie=strCookie.split("; ");
    var cityName = '';
    for(var i=0;i<arrCookie.length;i++){
        var arr=arrCookie[i].split("=");
        if(arr[0]==name) {
            if (/^%u/.test(arr[1])) {
                cityName = unescape(arr[1]);
            } else {
                cityName = decodeURIComponent(arr[1]);
            }
        }
    }
    return cityName;
}

function isWeiXin(){
    var ua = window.navigator.userAgent.toLowerCase();
    if(ua.match(/MicroMessenger/i) == 'micromessenger'){
        return true;
    }else{
        return false;
    }
}
require(['app'], function(App){
    var scriptE, module, app, dep, demStr;
    //define a tap event
    $.fn.tap = function( dom, fn ) {
        var eventTypes, position;
        eventTypes = 'touchstart touchmove touchend';
        position = {
            start: 0,
            moved: 0
        };
        if (arguments.length === 1) {
            fn = dom;
            dom = null;
        }
        return this.on(eventTypes, dom, null, function(e){
            var event, touches;
            event = e.originalEvent;
            switch (e.type) {
                case 'touchstart':
                    position.moved = 0;
                    touches = event.touches[0];
                    position.start = touches.pageY;
                    break;
                case 'touchmove':
                    touches = event.touches[0];
                    position.moved = touches.pageY - position.start;
                    break;
                case 'touchend':
                    if (position.moved === 0) {
                        position.moved = 0;
                        fn(e);
                        e.preventDefault();
                    }
                    break;
                default:
            }
        });
    };

    try {
        scriptE = $('#J_module');
        if (scriptE === undefined) {
            module = '';
            demStr = '';
        } else {
            module = scriptE.data('name');
            if (module === undefined)
                module = '';
            demStr = scriptE.data('dep');
            if (demStr === undefined)
                demStr = '';
        }
        dep = demStr.split(',');
        app = new App(module);
        require(dep,function(){
            app.run();
        });
    } catch(err) {
        console.log(err);
    }
});