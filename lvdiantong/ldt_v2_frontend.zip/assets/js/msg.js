/**
 * 信息弹出框插件 v0.1
 * create by 余旺 on 2015-11-06
 */

(function (root, factory) {
    if (typeof exports === 'object') {
        // CommonJs
        module.exports = factory();
    } else if (typeof define === 'function' && define.amd) {
        // AMD
        define([], factory);
    } else {
        root.Msg = factory();
    }
}(this, function () {
    'use strict';

    // 默认配置
    var defaults = {
        // 弹出框类型，可选项：alert | confirm | info
        type: 'alert',

        // 弹出框标题
        title: '提示',

        // 弹出框提示文字
        text: null,

        // 右上角是否显示关闭图标
        closeBtn: false,

        // 回调函数
        onOk: null,
        onCancel: null
    };

    // 简单的对象合并函数，不会覆盖合并
    var extend = function (to, from) {
        var prop, hasProp;
        for (prop in from) {
            hasProp = (to[prop] !== undefined);
            (!hasProp) && (to[prop] = from[prop]);
        }
        return to;
    };

    // 构造函数
    function Message(options) {
        var opts = this.config(options);
        this.draw(opts);
    }

    Message.prototype = {
        /**
         * 配置处理函数
         * @param opts 用户传入的配置
         */
        config: function (opts) {
            // 将默认配置和用户传入的配置合并，并赋值给this.options
            (!this.options) && (this.options = extend({}, opts));
            var opt = extend(this.options, defaults);

            // 检测type属性值是否合法
            var msgType = opt.type;
            switch (msgType) {
                case 'alert':
                case 'confirm':
                case 'info':
                    opt.type = msgType;
                    break;
                default:
                    opt.type = 'alert';
            }

            // 检测closeBtn属性值是否合法
            var isShowCloseBtn = (opt.closeBtn === 'true') || (opt.closeBtn === true);
            opt.closeBtn = isShowCloseBtn ? true : false;

            return opt;
        },

        createBody: function (title, text) {
            var bodyHtml = [
                '<div class="msg-body">',
                '<div class="msg-title">' + title + '</div>',
                '<div class="msg-text">' + text + '</div>',
                '</div>'
            ];
            return bodyHtml.join('');
        },

        createFooter: function (type) {
            var footerHtml = [
                '<div class="msg-footer">',
                '<button class="msg-btn J-msg-cancel" type="button">取消</button>',
                '<button class="msg-btn J-msg-ok" type="button">确定</button>',
                '</div>'
            ];
            (type === 'alert') && footerHtml.splice(1, 1);

            return footerHtml.join('');
        },

        createBox: function (type, title, text) {
            var self = this;
            var msgBox = [
                '<div class="msg-box">',
                '<span class="msg-close">&times;</span>',
                self.createBody(title, text),
                self.createFooter(type),
                '</div>'
            ];

            return msgBox.join('');
        },
        
        draw: function (opt) {
            var self = this;
            self.wrapper = document.createElement('div');

            switch (opt.type) {
                case 'alert':
                    self.wrapper.className = 'mask msg-alert';
                    break;
                case 'confirm':
                    self.wrapper.className = 'mask msg-confirm';
                    break;
                case 'info':
                    self.wrapper.className = 'mask msg-info';
                    break;
                default :
                    self.wrapper.className = 'mask msg-alert';
            }
            self.wrapper.innerHTML = self.createBox(opt.type, opt.title, opt.text);

            document.body.appendChild(self.wrapper);
            self.wrapper.style.display = 'block';
            $('.msg-box').on('touchend', ['.msg-close','.msg-btn'], function(e){
                e.preventDefault();
                var $target = $(e.target);
                if ($target.is('.J-msg-ok') && opt.onOk !== null) {
                    opt.onOk();
                }
                if ($target.is('.J-msg-cancel') && opt.onCancel !== null) {
                    opt.onCancel();
                }
                $(self.wrapper).remove();
            });
        },

        close: function() {
          $('.msg-box').remove();
        }
    };

    return Message;
}));