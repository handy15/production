"use strict";
import React from 'react';
import ReactDom from 'react-dom';
import {Toast, Cells, Cell, CellBody, CellFooter, Dialog} from 'react-weui';
const {Alert} = Dialog;
//import 'weui'
class PayWait extends React.Component {
  state = {
    showLoading: true,
    showToast: false,
    showAlert: false,
    alertMessage: '',
    loading_msg: '等待支付结果',
    success_msg: '支付成功',
    try_times: 0,
    queryHandler: null,
    alert: {
      title: '绿电通',
      buttons: [
        {
          label: '好的',
          onClick: this.hideAlert.bind(this)
        }
      ]
    }
  };
  max_try_times = 10;
  static propTypes = {
    queryUrl: React.PropTypes.string,
    orderId:  React.PropTypes.string,
    options:  React.PropTypes.object
  };

  render() {
    return (
      <section data-name="pay_wait">
        <Cells>
          <Cell>
            <CellBody>
              订单号：
            </CellBody>
            <CellFooter>
              {this.props.orderId}
            </CellFooter>
          </Cell>
          <Cell>
            <CellBody>
              金额：
            </CellBody>
            <CellFooter>
              {this.props.options.total}
            </CellFooter>
          </Cell>
        </Cells>
        <Toast icon="loading" show={this.state.showLoading}>{this.state.loading_msg}</Toast>
        <Toast show={this.state.showToast}>{this.state.success_msg}</Toast>
        <Alert title={this.state.alert.title} buttons={this.state.alert.buttons} show={this.state.showAlert}>{this.state.alertMessage}</Alert>
      </section>
    );
  }
  componentDidMount(){
    this.state.queryHandler = setInterval(()=>this._queryPayStatus(), 3000);
  }
  hideAlert(){
    this.setState({showAlert: false});
    location.href = '/';
  }
  _queryPayStatus() {
    if (this.state.try_times >= this.max_try_times) {
      this.setState({showLoading: false});
      clearInterval(this.state.queryHandler);
      this.setState({showAlert:true, alertMessage:'查询超时,请稍后查看订单状态'});
    } else {
      this.state.try_times++;
      let {queryUrl, orderId} = this.props;
      let data = {orderId: orderId};
      $.ajax({
        url: queryUrl,
        data: data,
        dataType: 'json',
        type: 'post',
        success: (response) => {
          const ret_data = response.data;
          if (ret_data.pay_success) {
            clearInterval(this.state.queryHandler);
            this.setState({showLoading: false, showToast: true, success_msg:'支付成功'});
            if (ret_data.hasOwnProperty('continue')) {
              // console.log(ret_data.continue);
              setTimeout(()=>location.href=ret_data.continue, 300);
            }
          } else {
            if (ret_data.msg != '')
              this.setState({showAlert: true, alertMessage:ret_data.msg})
          }
        }
      });
    }
  }
}

const {query_url, order_id, ...data} = JSON.parse(document.getElementById('options').innerText);

ReactDom.render(
  (<PayWait queryUrl={query_url} orderId={order_id} options={data} />),
  document.getElementById('page-box')
);