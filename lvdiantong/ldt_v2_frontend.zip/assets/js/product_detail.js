/**
 * Created by Administrator on 2015/11/24.
 */
$(function(){
    $(".tab ul li ").bind("touchend",function(){
        $(".tab li").eq($(this).index()).addClass("default").siblings().removeClass('default');
        $(".main p").hide().eq($(this).index()).show();

    });
});