/**
 * Created by houlonglong on 16/1/23.
 */

var $name = $('#name');
var $card = $('#card');
var $bank = $('#bank');
var $phone = $('#phone');
var $yzm = $('#yzm');
var $wx_addcard_tijao=$("#wx_addcard_tijao");

var reg = /[0-9]{4}$/;
$bank.keyup(function(event){
    if(event.keyCode == 8){
        var bank_val = $bank.val();
        bank_val = bank_val.substring(0,bank_val.length);
        console.log(bank_val);
        $bank.val(bank_val)
    }else{
        var reg = /[0-9]{4}$/;
            var textObj = $(this);
            //console.log(reg.test(text));
            if(reg.test(textObj.val())){
                textObj.val(textObj.val() + ' ');
            }

    }
    //alert(event.keyCode);
});


//加载获取光标
$name.focus();
function SetRemainTime() {
    if (curCount == 0) {
        window.clearInterval(InterValObj);//停止计时器
        $("#TestGetCode").removeAttr("disabled");//启用按钮
        $("#TestGetCode").html("发送验证码").css({
            background:"yellow;",
            color:"#fff"
        });
    }
    else {
        curCount--;
        $("#TestGetCode").html( curCount + "秒后重发");
    }
}

$("#TestGetCode").tap(function(){
    var InterValObj; //timer变量，控制时间
    var count = 2; //间隔函数，1秒执行
    var curCount;//当前剩余秒数
    function sendMessage() {
        curCount = count;
        //设置button效果，开始计时
        $("#TestGetCode").attr("disabled", "true");
        $("#TestGetCode").html( curCount + "秒后重发").css({
            background:'#ededed',
            color:"black",
            'border-left':'solid 1px #b7b7b7',
            height:"1.95rem"

        });
        InterValObj = window.setInterval(SetRemainTime, 1000); //启动计时器，1秒执行一次
    }
    //timer处理函数
    function SetRemainTime() {
        if (curCount == 0) {
            window.clearInterval(InterValObj);//停止计时器
            $("#TestGetCode").removeAttr("disabled");//启用按钮
            $("#TestGetCode").html("发送验证码").css({
                background:"#fff",
                color:"#559d39",
                "border-left": '1px solid #dfdfdf',
                height:"1.95rem"
            });
        }
        else {
            curCount--;
            $("#TestGetCode").html( curCount + "秒后重发");
        }
    }



    if($phone.val() == ""){
        $phone.focus();
        return  swal("手机号不能为空");
    }

    if(!/^1[3|4|5|7|8]\d{9}$/.test($phone.val())){
        $phone.focus();
        return  swal("手机号码不正确");
    }
    sendMessage()
    $.ajax({
        url:"http://127.0.0.1:3000/safety/wx_paypwd",
        data:'1111',
        success:function(result){
            return  swal("验证码发送成功，请及时检查您的手机");
        },
        error: function() {
            return  swal("验证码发送失败，请重试，或联系管理员");
        }
    });


})


// 验证身份证
function isCardNo(card) {
    var pattern = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
    return pattern.test(card);
}


$wx_addcard_tijao.tap(function(){
    var pattern = /^[\u4e00-\u9fa5]+$/;
    if(!pattern.test($name.val())){
        $name.focus();
        return swal("姓名必须为中文");
    }

    if(!isCardNo($.trim($card.val()))){
        $card.focus();
        return swal("身份号码不正确");

    }
    var reg = /^(\d{16}|\d{19})$/;
    if(!reg.test($.trim($bank.val()))){
        return swal("银行卡号不正确");
    }
    if($phone.val() == ""){
        return  swal("手机号不能为空");
    }
    if(!/^1[3|4|5|7|8]\d{9}$/.test($phone.val())){
        return  swal("手机号码不正确");
    }
    if($yzm.val() == ""){
        return  swal("验证码不能为空");
    }
    if($yzm.val().length > 4){
        return  swal("验证码必须时四位数字");
    }
    var data = $("form").serialize();
    var url = $('#wx_addcard_tijao').data("url");
    //console.log(data)
    $.getJSON(url, data,
        function(data){
            if(data.success){
                swal('成功!')
            }else{
                swal('失败')
            }
        });
})




