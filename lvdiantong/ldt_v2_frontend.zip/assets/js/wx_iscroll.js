
$(function(){
    var counter = 0;
    // 每页展示4个每页展示4个
    var num = 7;
    var pageStart = 0,pageEnd = 0;
    var $api_json = $(".inner").data("url");

    // dropload
    $('.inner').dropload({
        scrollArea : window,
        domUp : {
            domClass   : 'dropload-up',
            domRefresh : '<div class="dropload-refresh">↓上拉刷新</div>',
            domUpdate  : '<div class="dropload-update">↑释放更新</div>',
            domLoad    : '<div class="dropload-load"><span class="loading"></span>加载中...</div>'
        },
        domDown : {
            domClass   : 'dropload-down',
            domRefresh : '<div class="dropload-refresh">下拉更多</div>',
            domLoad    : '<div class="dropload-load"><span class="loading"></span>加载中...</div>',
            domNoData  : '<div class="dropload-noData">已经最后</div>'
        },
        loadUpFn : function(me){
            $.ajax({
                type: 'GET',
                url: $api_json,
                dataType: 'json',
                success: function(data){
                    var result = '';
                    for(var i = 0; i < data.data.length; i++){
                        if(data.data[i].bill_type == "1"){
                            yanse = "fr lvse";
                        }else {
                            yanse = "fr huangse";
                        }
                        result +='<li class="one">' +
                            '<div class="relevance">' +
                            '<span>'+'关联订单号'+data.data[i].order_id+'</span>'+
                            '<span class="fr">'+data.data[i].create_time+'</span>'+
                            '</div>'+
                            '<div class="relevance_top">' +
                            '<span>'+data.data[i].message+'</span>'+
                            '<span class="'+yanse+'">'+data.data[i].money+'</span>'+
                            '</div>'+
                            '</li>';
                    }
                    // 为了测试，延迟1秒加载
                    setTimeout(function(){
                        $('.boder_top').html(result);
                        // 每次数据加载完，必须重置
                        me.resetload();
                    },10);
                },
                error: function(xhr, type){
                    alert('Ajax error!');
                    // 即使加载出错，也得重置
                    me.resetload();
                }
            });
        },
        loadDownFn : function(me){
            $.ajax({
                type: 'GET',
                url: $api_json,
                dataType: 'json',
                success: function(data){
                    var result = '';
                    counter++;
                    // alert(counter)
                    pageEnd = num * counter;
                    pageStart = pageEnd - num;
                    var yanse = '';
                    for(var i = pageStart; i < pageEnd; i++){

                        if(data.data[i].bill_type == "1"){
                            yanse = "fr lvse";
                        }else {
                            yanse = "fr huangse";
                        }
                        result +='<li class="one">' +
                            '<div class="relevance">' +
                            '<span>'+'关联订单号'+data.data[i].order_id+'</span>'+
                            '<span class="fr">'+data.data[i].create_time+'</span>'+
                            '</div>'+
                            '<div class="relevance_top">' +
                            '<span>'+data.data[i].message+'</span>'+
                            '<span class="'+yanse+'">'+data.data[i].money+'</span>'+
                            '</div>'+
                            '</li>';

                        if((i + 1) >= data.data.length){
                            // 锁定
                            me.lock();
                            // 无数据
                            me.noData();
                            break;
                        }
                    }
                    // 为了测试，延迟1秒加载
                    setTimeout(function(){
                        $('.boder_top').append(result);
                        // 每次数据加载完，必须重置
                        me.resetload();
                    },100);
                },
                error: function(xhr, type){
                    alert('Ajax error!');
                    // 即使加载出错，也得重置
                    me.resetload();
                }
            });
        },
        threshold : 50
    });
});
