$("input").tap("focus",function(e){
    if ($.system.type() == "android") {
        $("#withdrawalPageScroller").css({
            "top": "100px"
        });
    }
}).on("blur",function(e){
    if ($.system.type() == "android") {
        $("#withdrawalPageScroller").css({
            "top": "46px"
        });
    }
});ps