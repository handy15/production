/**
 * Created by yuwang on 2016/1/8 0008.
 */


$('#taocan').tap(function(){
    $('#taocan').removeClass('lvbiankuang_none');
    $('#jiaofei').addClass('lvbiankuang_none');
    $('#jiaofei_order').css("display","none");
    $('#taocan_order').css("display","block");

    //$('#taocan_order').show();
    //$('#jiaofei_order').hide();


});
$('#jiaofei').tap(function(){
    $('#jiaofei').removeClass('lvbiankuang_none');
    $('#taocan').addClass('lvbiankuang_none');
    $('#taocan_order').css("display","none");
    $('#jiaofei_order').css("display","block");
    $('#jiaofei_order').show();
    $('#taocan_order').hide();

});
