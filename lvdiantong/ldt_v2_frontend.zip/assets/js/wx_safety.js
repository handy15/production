
function repeat(target, n) {
    return (new Array(n + 1)).join(target);
}
var re = /[\d]{6}/;
var pay_str = '';
var $PayPassword = $('#PayPassword');
var $PayPassword_hide = $("#PayPassword_hide");
var $confirm_PayPassword = $('#confirm_PayPassword');
var $confirm_PayPassword_hide = $("#confirm_PayPassword_hide");
$PayPassword.focus(function (e) {
});
$PayPassword.blur(function (e) {
});
$PayPassword.keyup(function (e) {
    if (e.keyCode == 8) {
        $PayPassword.val(repeat("*", pay_str.length - 1));
        pay_str = pay_str.substring(0, pay_str.length - 1);
        $PayPassword_hide.val(pay_str);
    } else {
        var userInput = $(this).val();
        if (event.which === 0) {
            event.which = e.keyCode = userInput.charAt(userInput.length - 1).charCodeAt(0);
        }
        pay_str += String.fromCharCode(e.keyCode.toString());
        if (pay_str.length !== 6) {
            pay_str = pay_str.substring(0, 6)
        }
        $PayPassword.val(repeat("*", pay_str.length));
        $PayPassword_hide.val(pay_str)
    }
});
var confirm_str = '';
$confirm_PayPassword.focus(function (e) {
});
$confirm_PayPassword.blur(function (e) {
});
$confirm_PayPassword.keyup(function (e) {
    if (e.keyCode == 8) {
        $confirm_PayPassword.val(repeat("*", confirm_str.length - 1));
        confirm_str = confirm_str.substring(0, confirm_str.length - 1);
        $confirm_PayPassword_hide.val(confirm_str);
    } else {
        var userInput = $(this).val();
        if (event.which === 0) {
            event.which = e.keyCode = userInput.charAt(userInput.length - 1).charCodeAt(0);
        }
        confirm_str += String.fromCharCode(e.keyCode.toString());
        if (confirm_str.length !== 6) {
            confirm_str = confirm_str.substring(0, 6)
        }
        $confirm_PayPassword.val(repeat("*", confirm_str.length));
        $confirm_PayPassword_hide.val(confirm_str);
    }
});
$('#pay_btn').click(function (e) {
    var $this = e.currentTarget;
    var id = $($this).attr("id");
    var $dialog = $('#dialog1');
    var $weui_dialog_title = $('.weui_dialog_title');
    if ($PayPassword_hide.val().length != 6) {
        $weui_dialog_title.text('支付密码必须为6位数字');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false
    }
    if (!re.test($PayPassword_hide.val())) {
        $weui_dialog_title.text('支付密码必须数字');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false
    }
    if ($confirm_PayPassword_hide.val().length !== 6) {
        $weui_dialog_title.text('确认密码必须6位');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false
    }
    if (!re.test($confirm_PayPassword_hide.val())) {
        $weui_dialog_title.text('确认密码必须数字');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false
    }
    if ($confirm_PayPassword_hide.val() !== $PayPassword_hide.val()) {
        $weui_dialog_title.text('两次密码输入不一致');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false
    }
    var url = $('#pay_btn').data("url");
    var data = {new_cashpass: $PayPassword_hide.val(), continue: GetQueryString('continue')};
    $.post(url, data, function (data) {
        $weui_dialog_title.text(data.data.msg);
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            if (data.data.url != '') {
                location.href = UrlDecode(data.data.url);
            }
            $dialog.hide();
        });

    });
});
function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)return (r[2]);
    return null;
}
function asc2str(ascasc) {
    return String.fromCharCode(ascasc);
}
function UrlDecode(str) {
    var ret = "";
    for (var i = 0; i < str.length; i++) {
        var chr = str.charAt(i);
        if (chr == "+") {
            ret += "";
        } else if (chr == "%") {
            var asc = str.substring(i + 1, i + 3);
            if (parseInt("0x" + asc) > 0x7f) {
                ret += asc2str(parseInt("0x" + asc + str.substring(i + 4, i + 6)));
                i += 5;
            } else {
                ret += asc2str(parseInt("0x" + asc));
                i += 2;
            }
        } else {
            ret += chr;
        }
    }
    return ret;
}