(function () {
    'use strict';
    var gulp = require('gulp');
    var path = require('path');
    var jade = require('gulp-jade');
    var coffee = require('gulp-coffee');
    var less = require('gulp-less');
    var csso = require('gulp-csso');
    var concat = require('gulp-concat');
    var jsMin = require('gulp-jsmin');
    var sourceMaps = require('gulp-sourcemaps');
    var exec = require('child_process').exec;
    var jsBuildPath = './public/assets/js'; //实际调用JS的目录
    var cssBuildPath = './public/assets/css'; //实际调用css的目录
    var libPath = './bower_components';
    var npmLibPath = './node_modules';

    gulp.task('default', ['browserify'],function () {
        console.info("命令说明:");
        var info = {
            build: '编译ES2015的js',
            jade: '编译处理jade模板为html',
            sc: '编译coffee文件为js，并把JS文件复制到实际调用地址中',
            cf: '仅编译coffee文件为JS',
            css: '复制所有的css文件到实际目录',
            less: '发布less为style.css',
            vendor: '发布bower安装的JS库到正式调用的位置',
            publish: '发布。执行所有的命令',
            watch: '监视coffee和less的修改'
        };

    });

    gulp.task('jade', function () {
        gulp.src('views/**/*.jade')
            .pipe(jade({pretty: true}))
            .pipe(gulp.dest('public/dist'));
    });
    gulp.task('cf', function(){
        gulp.src("assets/coffee/**/*.coffee")
            .pipe(coffee({bare: true}))
            //.pipe(jsMin())
            .pipe(gulp.dest(jsBuildPath));
    });
    gulp.task('sc', function () {
        gulp.src("assets/js/**/*.js")
            //.pipe(jsMin())
            .pipe(gulp.dest(jsBuildPath));

    });
    gulp.task('css', function(){
        gulp.src('assets/css/**/*.css')
            .pipe(csso())
            .pipe(gulp.dest(cssBuildPath));
    });
    gulp.task('less', function () {
        var lessSrcPath = './assets/less/';
        return gulp.src(path.join(lessSrcPath, 'style.less'))
            //.pipe(sourceMaps.init())
            .pipe(less({paths: [
                path.join(__dirname,'./assets/less'),
                path.join(__dirname,'./assets/less/page'),
                path.join(__dirname,'./assets/less/global')
            ]}))
            .pipe(csso())
            .pipe(sourceMaps.write('./maps'))
            .pipe(gulp.dest(cssBuildPath));
    });
    /**
     * 发布bower里的库到public目录
     */
    gulp.task('vendor', function () {
        var vendor ={
            js: [
                path.join(libPath, 'jquery/dist/jquery.min.js'),
                path.join(libPath, 'Swiper/dist/js/swiper.jquery.min.js'),
                path.join(libPath, 'iscroll/build/iscroll.js'),
                path.join(libPath, 'sweetalert/dist/sweetalert.min.js'),
                path.join(libPath, 'dropload/dist/dropload.min.js'),
                path.join(libPath, 'fastclick/lib/fastclick.js'),
                path.join(libPath, 'weui/dist/example/zepto.min.js'),

            ],
            css: [
                path.join(libPath, 'dropload/dist/dropload.css'),
                path.join(libPath, 'Swiper/dist/css/swiper.min.css'),
                path.join(libPath, 'sweetalert/dist/sweetalert.css'),
                path.join(libPath, 'weui/dist/style/weui.min.css'),
                path.join(libPath, 'weui/dist/example/example.css')
            ],
            needMinJs: [
                path.join(libPath, 'requirejs/require.js')
            ]
        };
        gulp.src(vendor.js)
            .pipe(gulp.dest(path.join(jsBuildPath, 'libs/')));
        gulp.src(vendor.css)
            .pipe(gulp.dest(path.join(cssBuildPath, 'libs/')));
        gulp.src(vendor.needMinJs)
            .pipe(jsMin())
            .pipe(gulp.dest(path.join(jsBuildPath,'libs/')));
    });
    gulp.task('build', function(){
        exec('npm run build');
    });
    gulp.task('publish', ['vendor','css', 'less', 'sc', 'cf','build']);
    gulp.task('push', function(){
        console.info('正在发布JS...');
        gulp.src('public/assets/js/libs/*.js')
            .pipe(gulp.dest('../Public/assets/js/libs/'));
        gulp.src('public/assets/js/pages/*.js')
            .pipe(gulp.dest('../Public/assets/js/pages/'));
        gulp.src('public/assets/js/*.js')
            .pipe(jsMin())
            .pipe(gulp.dest('../Public/assets/js/'));
        console.info('正在发布css...');
        gulp.src('public/assets/css/**/*.css')
            .pipe(gulp.dest('../Public/assets/css/'));
        console.info('正在发布图片');
        gulp.src('public/assets/images/**/*')
            .pipe(gulp.dest('../Public/assets/images/'));
        console.info('Done');
    });
    gulp.task('watch', function(){
       gulp.watch('/assets/dist/js',['js']);
       gulp.watch("assets/coffee/**/*.coffee", ['cf']);
       gulp.watch("assets/less/**/*.less", ['less']);
       gulp.watch("assets/js/*.js", ['sc']);
       gulp.watch("assets/css/**/*.css", ['css']);
    });
})();
