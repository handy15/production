var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.send("hello");
});

router.get('/index', function(req,res,next){
  var is_login = req.query.login;
  res.render('index/index', {title: '',is_login: is_login});
});

router.get('/about', function(req,res,next){
  res.render('index/about', {title: ''});
});
router.get('/upgrade', function(req,res,next){
  res.render('index/upgrade', {title: ''});
});
router.get('/gongyi', function(req,res,next){
  res.render('index/gongyi', {title: ''});
});
module.exports = router;
