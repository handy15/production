var express = require('express');
var router = express.Router();

router.get('/', function(req, res, next) {
   res.render('paycost/index', { title: '缴费户号'});
});

router.get('/new_card', function(req, res, next) {
   res.render('paycost/new_card', { title: '生活缴费'});
});

router.get('/select_city', function(req, res, next) {
   res.render('paycost/select_city', { title: '城市选择'});
});

router.all('/confirm', function(req, res, next){
   pageType = req.query.type;
   balance = req.query.amount;
   if (pageType === undefined)
      pageType = 0;
   if (balance === undefined)
      balance = 200;
   res.render('paycost/confirm', {title: '确认缴费', type: pageType})
});

router.post('/pay', function(req, res, next){
   res.render('paycost/pay', {title: '支付'});
});

router.all('/success', function(req, res, next){
   res.render('paycost/success', {title: '缴费成功'});
});

router.all('/success_wei', function(req, res, next){
   res.render('paycost/success_wei', {title: '缴费成功'});
});

router.get('/wait', function(req,res,next){
   res.render('paycost/wait', {title: '支付结果'});
});
router.get('/balance', function(req,res,next){
   res.render('paycost/balance', {title: '订单支付'});
});
module.exports = router;