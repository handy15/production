var express = require('express');
var router = express.Router();

/* GET ucenter listing. */
router.get('/', function(req, res, next) {
    res.send('respond with a resource');
});

router.get('/wx_safety', function(req,res,next){
    res.render('safety/wx_safety', { title: '设置绿电支付密码' });
});

router.get('/wx_paypwd', function(req,res,next){
    res.render('safety/wx_paypwd', { title: '修改绿电支付密码' });
});
module.exports = router;
