var express = require('express');
var router = express.Router();

/* GET ucenter listing. */
router.get('/', function(req, res, next) {
    res.send('respond with a resource');
});

router.get('/wx_addbank', function(req,res,next){
    res.render('tie_card/wx_addbank', { title: '绑定银行卡' });
});
router.get('/wx_banklist', function(req,res,next){
    res.render('tie_card/wx_banklist', { title: '银行卡' });
});

module.exports = router;
