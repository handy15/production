var express = require('express');
var router = express.Router();

/* GET ucenter listing. */
router.get('/', function(req, res, next) {
    res.send('respond with a resource');
});

router.get('/wx_login', function(req,res,next){
    res.render('ucenter/wx_login', { title: '登录' });
});

router.get('/wx_register', function(req,res,next){
    res.render('ucenter/wx_register', { title: '注册' });
});

router.get('/forget', function(req,res,next){
    res.render('ucenter/forget', { title: '忘记密码' });
});

router.get('/account', function(req, res, next) {
    res.render('ucenter/account', { title: ''}); //绿电中心
});

router.get('/register_new', function(req, res, next) {
    res.render('ucenter/register_new', { title: '注册'});
});
router.get('/bill', function(req, res, next) {
    res.render('ucenter/bill', { title: '绿电交易记录'});
});

router.get('/wx_order', function(req, res, next) {
    res.render('ucenter/wx_order', { title: '绿电订单'});
});

router.get('/wx_resetpwd', function(req, res, next) {
    res.render('ucenter/wx_resetpwd', { title: '忘记密码'});
});

router.get('/tickets', function(req, res, next) {
    res.render('ucenter/tickets', { title: '优惠券'});
});
router.get('/safety', function(req, res, next) {
    res.render('ucenter/safety', { title: '安全管理'});
});

router.get('/faq', function(req, res, next) {
    res.render('ucenter/faq', { title: '常见问题'});
});
module.exports = router;
