var webpack = require('webpack');
var path = require('path');
var base_js_dir = path.resolve(__dirname, 'assets/js');
module.exports = {
  entry: {
    common: ['react','react-dom','react-weui'],
    pay_wait: path.join(base_js_dir, 'pay_wait.jsx')
  },
  output: {
    path: path.resolve(__dirname, 'public/assets/js/pages'),
    filename: '[name].js'
  },
  module: {
    loaders: [
      {
        test: /\.js[x]?$/,
        exclude: /node_modules|bower_components/,
        loader: 'babel'
      }, {
        test: /\.less$/,
        exclude: /node_modules/,
        loader: 'style!css!postcss!less'
      }, {
        test: /\.css/,
        loader: 'style!css'
      }, {
        test: /\.(png|jpg)$/,
        loader: 'url?limit=25000'
      }
    ]
  },
  plugins: [
    new webpack.optimize.UglifyJsPlugin({
      sourceMap: false,
      mangle: false
    }),
    new webpack.optimize.CommonsChunkPlugin(["common"], '[name].js')
  ]
};