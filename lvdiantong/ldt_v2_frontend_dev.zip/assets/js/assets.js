$(function () {
    $(".order").bind("touchend", function () {
        if ($(this).next().is(':hidden')) {
            $('.fr', this).removeClass('smalltop').addClass('smallbot_jian');
            $(this).next().slideDown();
        } else {
            $('.fr', this).addClass('smalltop').removeClass('smallbot_jian');
            $(this).next().slideUp();
        }
        return false;
    });
})