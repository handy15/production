var swiper;
swiper = new Swiper('.swiper-container', {
    pagination: '.swiper-pagination',
    paginationClickable: true,
    loop : true,
    loopAdditionalSlides : 1,
    autoplay : 3000,
    speed:300

});
//微信弹窗
    $('.item-li').tap(function(e){
        var $this = e.currentTarget;
        var id = $($this).attr("id");
        var $dialog = $('#dialog1');
        var $weui_dialog_title =$('.weui_dialog_title');
        var $weui_dialog_bd = $('.weui_dialog_bd ');


        switch(id){
            case 'solar':
                $weui_dialog_title.text('太阳能');
                $weui_dialog_bd .text('太阳能光伏发电是将光能直接转化为电能，太阳能取之不尽，用之不竭，避免如火力发电耗费巨量不可再生资源，最大限度减少雾霾和碳排放，是国家大力提倡并发展的新型绿色能源 。世界著名企业如苹果、可口可乐等都在世界范围使用太阳能绿色清洁能源。');
                $dialog.show();
                $dialog.find('.weui_btn_dialog').tap(function () {
                    $dialog.hide();
                });
            break;

            case 'lvdianjieshao':
                $weui_dialog_title.text('绿电介绍');
                $weui_dialog_bd .text('绿电通的“绿电”是实现“碳中和”的绿色电力。绿电通拥有SPI集团旗下大规模的太阳能光伏电站，用碳中和的方式抵消火力发电所产生的碳排放，让绿色电力走进千家万户。认可绿电通“绿电”的企业有：国美电器、平安银行、红星美凯龙、大中通讯、全时超市等等。');
                $dialog.show();
                $dialog.find('.weui_btn_dialog').tap(function () {
                    $dialog.hide();
                });
                break;

            case 'about_index':
                $weui_dialog_title.text('关于我们');
                $weui_dialog_bd .text('绿电通，是由美国NASDAQ上市企业SPI绿能宝能源互联网股份有限公司倾力打造的绿色电费折扣充缴平台，推动清洁能源代替传统化石能源和中国能源结构优化改革，让每个人都成为太阳能发电的受益者。');
                $dialog.show();
                $dialog.find('.weui_btn_dialog').tap(function () {
                    $dialog.hide();
                });
                break;
           // case 'faq':
                //$('.weui_dialog_title').text('常见问题');
                //$('.weui_dialog_bd ').text('11111111');
                //$dialog.show();
                //$dialog.find('.weui_btn_dialog').one('tap', function () {
                //    $dialog.hide();
                //});
             //   break;

        }


    });


//定位逻辑
function getLocation(){
    if(navigator.geolocation){
        return navigator.geolocation.getCurrentPosition(showPosition);
    }
}
function showPosition(position){
    var x = position.coords.longitude;
    var y = position.coords.latitude;
    changeCity(x,y);
}
function locateCity(){
    //只定位一次
    var is_locate = getCookie('is_locate');
    if (is_locate === 'done') {
        return true;
    }
    setCookie('is_locate', 'done');

    var confirm_msg = "“绿电通”在您使用该应用时想访问您的位置吗？我们以此设置您的缴费城市，并改进我们的服务。";
    if (! confirm(confirm_msg)) {
        //［不允许］
        return;
    }

    document.getElementById('city').innerHTML = "定位中";

    if(isWeiXin()){
        //loadingWindow('正在定位城市…');
        new wxUnity({
            apiList: ['getLocation'],
            register: function() {
                wx.getLocation({
                    success: function (res) {
                        changeCity(res.longitude, res.latitude);
                    },
                    fail: function (res) {
                        if (res.errMsg == 'getLocation:fail') {
                            //closeLoading();
                            require(['msg'], function (Msg) {
                                new Msg({
                                    text: '请在设置中打开微信定位服务'
                                });
                            });
                        }
                    }
                });
            }
        });
    }else{
        getLocation();
    }
    //setTimeout('closeLoading()', 3000);
    setTimeout(function () {
        if (document.getElementById('city').innerHTML === "定位中") {}
        document.getElementById('city').innerHTML = "请选择";
    }, 3000);
}

function changeCity(x,y){
    var apiUrl = $('#location').data('api');
    $.ajax({
        dataType: "json",
        url: apiUrl + "?x=" + x + "&y=" + y,
        //url: "/data.json",
        timeout: 3000,
        success: function(json){
            //closeLoading();
            var code = json.data.code;
            var name = json.data.name;
            if(code != ''){
                document.getElementById('city').innerHTML = name;
                setCookie('city_code',code);
                setCookie('city_name',name);
            }
            else {
                require(['msg'], function(Msg){
                    new Msg({
                        text: name + '暂未开通缴费'
                    });
                });
            }
        },
        error: function(x, t,m) {
            //closeLoading();
            if(t==="timeout") {
                //超时处理
            }
        }
    });
}

require(['msg','sweetalert'], function(Msg,swal){
    var code = getCookie('city_code');
    var name = getCookie('city_name');
    if((code != '') && (name != '')){
        document.getElementById('city').innerHTML = name;
    }else{
        try {
            locateCity();
        } catch (er) {
            //closeLoading();
            new Msg({
                text: '暂时无法定位，请手动选择城市。'
            });
        }
  	}
    //点击判断有效的缴费城市
    $('#jian-ju').tap(function(e){
      var code = getCookie('city_code');
      if(code == ''){
        new Msg({
            text: '请选择需要缴费的城市'
        });
        $('.msg-btn').tap(function(e){
            location.href = '/index.php?m=WeChat&c=Paycost&a=cityList&callback=package';
        });
      }else{
        location.href = '/Wechat/Package/index';
      }
    });
    $('#jianju').tap(function(e){
      var code = getCookie('city_code');
      if(code == ''){
        new Msg({
            text: '请选择需要缴费的城市'
        });
        $('.msg-btn').tap(function(e){
            location.href = '/index.php?m=WeChat&c=Paycost&a=cityList&callback=paycost';
        });
      }else{
        location.href = '/Wechat/Paycost/index';
      }
    });
    //点击到缴费城市列表页
    $('#location').tap(function(e){
        location.href = '/index.php?m=WeChat&c=Paycost&a=cityList&callback=index';
    });
    $('#touright').tap(function(e){
        location.href = $('#touright').data('url');
    });
    $('#about').tap(function(e){
        location.href = '/Wechat/Index/about';
    });

    $(".icon-ic02").tap(function () {
        swal(JSON.parse($("#J-icon-ic02").html()));
    });
    $(".icon-ic01").tap(function () {
        swal(JSON.parse($("#J-icon-ic01").html()));
    });
    $(".icon-ic03").tap(function () {
        swal(JSON.parse($("#J-icon-ic03").html()));
    });
});


