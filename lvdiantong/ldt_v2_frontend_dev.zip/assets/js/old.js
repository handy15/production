/**
 * 1.0版本中的JS，新版中需要用到的部分，以后逐渐替代
 */
function loadingWindow(msg) {
    msg = msg || '正在请求请稍后...';
    $('.loading,.loadingMask').remove();
    $('body').append('<div class="loading"><span>' + msg +'</span></div><div class="loadingMask"></div>');
}

function closeLoading() {
    $('.loading,.loadingMask').remove();
}

function getBill(form, Msg) {
    var abort={};
    abort['url'] = form.data('url');
    abort['data'] = form.serialize();
    abort['dataType'] = 'json';
    abort['success'] = function(data){
        switch(data.status){
            case 0:
                var url = form.attr('action');
                window.location.href=url+'&cid='+data.data.cid+'&cardId='+data.data.cardId+'&ticketId='+data.data.ticketId;
                i = 0;
                break;
            case 1:
                i++;
                if(i<n){
                    $.ajax(abort);
                }else{
                    i = 0;
                    closeLoading();
                    new Msg({text: data.message});
                }
                break;
            case 2:
                closeLoading();
                new Msg({text: data.message});
                i = 0;
                break;
            case 3:
                closeLoading();
                new Msg({text: data.message});
                i = 0;
                break;
            case 4:
                closeLoading();
                new Msg({text: data.message});
                i = 0;
                break;
            default:
                closeLoading();
                new Msg({text: data.message});
                i = 0;
                break;
        }
    };
    abort['error'] = function(data){
        //网络繁忙
        closeLoading();
    };

    loadingWindow();
    $.ajax(abort);
}