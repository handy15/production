$("iframe").hide();
function showTime(){
    $("iframe").show();
    $("iframe").contents().find(".title_inner").html('您访问的页面打不开，但我们可以一起帮他们回家!');
};
setInterval ("showTime()", 100);
