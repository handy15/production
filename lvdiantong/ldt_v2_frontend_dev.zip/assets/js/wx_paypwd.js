$('#mobiles').focus();
function repeat(target, n) {
    return (new Array(n + 1)).join(target);
}
var input_str = '';
var new_str = '';
var news_str = '';
var re = /[\d]{6}/;
var $yuanmima = $("#yuanmima");
var $yuanmima_yc = $('#yuanmima_yc');
var $xinmima = $("#xinmima");
var $xinmima_yc = $("#xinmima_yc");
var $xinmimas = $("#xinmimas");
$yuanmima.focus(function () {
    input_str = $(this).val();
});
$yuanmima.blur(function (e) {
});
$yuanmima.keyup(function (e) {

    if (e.keyCode == 8) {

        $yuanmima.val(repeat("*", input_str.length - 1));
        input_str = input_str.substring(0, input_str.length - 1);
        $yuanmima_yc.val(input_str);
    } else {
        var userInput = $(this).val();
        if (event.which === 0) {
            event.which = e.keyCode = userInput.charAt(userInput.length - 1).charCodeAt(0);
        }
        input_str += String.fromCharCode(e.keyCode.toString());
        if (input_str.length !== 6) {
            input_str = input_str.substring(0, 6)
        }
        $yuanmima.val(repeat("*", input_str.length));
        $yuanmima_yc.val(input_str);
    }
});
$xinmima.focus(function (e) {
});
$xinmima.blur(function (e) {
});
$xinmima.keyup(function (e) {
    if (e.keyCode == 8) {
        $xinmima.val(repeat("*", new_str.length - 1));
        new_str = new_str.substring(0, new_str.length - 1);
        $xinmima_yc.val(new_str);
    } else {
        var userInput = $(this).val();
        if (event.which === 0) {
            event.which = e.keyCode = userInput.charAt(userInput.length - 1).charCodeAt(0);
        }
        new_str += String.fromCharCode(e.keyCode.toString());
        if (new_str.length !== 6) {
            new_str = new_str.substring(0, 6)
        }
        $xinmima.val(repeat("*", new_str.length));
        $xinmima_yc.val(new_str);
    }
});
$xinmimas.focus(function (e) {
});
$xinmimas.blur(function (e) {
});
var $xinmimas_yc = $("#xinmimas_yc");
$xinmimas.keyup(function (e) {
    if (e.keyCode == 8) {
        $xinmimas.val(repeat("*", news_str.length - 1));
        news_str = news_str.substring(0, news_str.length - 1);
        $xinmimas_yc.val(news_str);
    } else {
        var userInput = $(this).val();
        if (event.which === 0) {
            event.which = e.keyCode = userInput.charAt(userInput.length - 1).charCodeAt(0);
        }
        news_str += String.fromCharCode(e.keyCode.toString());
        if (news_str.length !== 6) {
            news_str = news_str.substring(0, 6)
        }
        $xinmimas.val(repeat("*", news_str.length));
        $xinmimas_yc.val(news_str);
    }
});
$('#jide').tap(function () {
    $('#wangji').removeClass('lvbiankuang');
    $('#jide').addClass('lvbiankuang');
    $('.yuanlaizhifu').show();
    $('.wangjizhifu').hide();
    $('#yuanmima').focus();
})
$('#paypwd').tap(function (e) {
    var $this = e.currentTarget;
    var id = $($this).attr("id");
    var $dialog = $('#dialog');
    var $weui_dialog_title = $('.weui_dialog_title');
    var yuanmima_yc = $('#yuanmima_yc').val();
    var xinmima_yc = $('#xinmima_yc').val();
    var xinmimas_yc = $('#xinmimas_yc').val();
    if (yuanmima_yc.length != 6) {
        $weui_dialog_title.text('原密码必须为6位数字');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false
    }
    if (re.test(yuanmima_yc) == false) {
        $weui_dialog_title.text('原密码必须数字');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false
    }
    ;
    if (xinmima_yc.length !== 6) {
        $weui_dialog_title.text('新密码必须6位');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    if (re.test(xinmima_yc) == false) {
        $weui_dialog_title.text('新密码必须数字');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    ;
    if (yuanmima_yc == xinmima_yc) {
        $weui_dialog_title.text('新密码不能和原密码相同');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    if (xinmimas_yc.length !== 6) {
        $weui_dialog_title.text('确认密码必须6位');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    if (re.test(xinmimas_yc) == false) {
        $weui_dialog_title.text('确认密码必须数字');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    if (xinmima_yc !== xinmimas_yc) {
        $weui_dialog_title.text('确认密码和新密码不一致，请重新输入');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    var data = {old_cashpass: yuanmima_yc, new_cashpass: xinmima_yc, type: 1, continue: GetQueryString('continue')};
    var url = $('#paypwd').data("url");
    $.post(url, data, function (data) {
        $weui_dialog_title.text(data.data.msg);
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            if (data.data.url != '') {
                location.href = UrlDecode(data.data.url);
            }
            $dialog.hide();
        });
        return false;
    });
});
$('#wangji').tap(function () {
    $('#jide').removeClass('lvbiankuang');
    $('#wangji').addClass('lvbiankuang');
    $('.wangjizhifu').show();
    $('.yuanlaizhifu').hide();
    $('#mobiles').focus();
})
function SetRemainTime() {
    if (curCount == 0) {
        window.clearInterval(InterValObj);
        $("#TestGetCode").removeAttr("disabled");
        $("#TestGetCode").html("发送验证码").css({background: "yellow;", color: "#fff"});
    }
    else {
        curCount--;
        $("#TestGetCode").html(curCount + "秒后重发");
    }
}
$("#TestGetCode").tap(function (e) {
    var $this = e.currentTarget;
    var id = $($this).attr("id");
    var $dialog = $('#dialog1');
    var $weui_dialog_title = $('.weui_dialog_title');
    var InterValObj;
    var count = 90;
    var curCount;

    function sendMessage() {
        curCount = count;
        $("#TestGetCode").attr("disabled", "true");
        $("#TestGetCode").html(curCount + "秒后重发").css({
            background: '#ededed',
            color: "black",
            border: 'solid 1px #b7b7b7'
        });
        InterValObj = window.setInterval(SetRemainTime, 1000);
    }

    function SetRemainTime() {
        if (curCount == 0) {
            window.clearInterval(InterValObj);
            $("#TestGetCode").removeAttr("disabled");
            $("#TestGetCode").html("发送验证码").css({background: "#4c9021", color: "#fff", boder: 'none'});
        }
        else {
            curCount--;
            $("#TestGetCode").html(curCount + "秒后重发");
        }
    }

    if ($('#mobiles').val() == "") {
        $weui_dialog_title.text('手机号码不能为空');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false
    }
    ;
    if (!/^1[3|4|5|7|8]\d{9}$/.test($('#mobiles').val())) {
        $weui_dialog_title.text('手机号码不正确');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false
    }
    sendMessage()
    $.ajax({
        type: 'POST', url: "/api/user/smsVerify", data: {mobile: $('#mobiles').val()}, success: function (data) {
            $weui_dialog_title.text(data.data.msg);
            $dialog.show();
            $dialog.find('.weui_btn_dialog').tap(function () {
                $dialog.hide();
            });

        }, error: function () {
            $weui_dialog_title.text('验证码发送失败，请重试，或联系管理员');
            $dialog.show();
            $dialog.find('.weui_btn_dialog').tap(function () {
                $dialog.hide();
            });
            return false
        }
    });
})
var $new_pwd = $("#new_pwd");
var $new_pwdhide = $("#new_pwdhide");
var new_pwd_str = '';
$new_pwd.focus(function (e) {
});
$new_pwd.blur(function (e) {
});
$new_pwd.keyup(function (e) {
    if (e.keyCode == 8) {
        $(this).val(repeat("*", new_pwd_str.length - 1));
        new_pwd_str = new_pwd_str.substring(0, new_pwd_str.length - 1);
        $new_pwdhide.val(new_pwd_str);
    } else {
        var userInput = $(this).val();
        if (event.which === 0) {
            event.which = e.keyCode = userInput.charAt(userInput.length - 1).charCodeAt(0);
        }
        new_pwd_str += String.fromCharCode(e.keyCode.toString());
        if (new_pwd_str.length !== 6) {
            new_pwd_str = new_pwd_str.substring(0, 6)
        }
        $new_pwd.val(repeat("*", new_pwd_str.length))
        $new_pwdhide.val(new_pwd_str);
    }
});
var $new_pwds = $("#new_pwds");
var $new_pwdshide = $("#new_pwdshide");
var $new_pwds_str = "";
$new_pwds.focus(function (e) {
});
$new_pwds.blur(function (e) {
});
$new_pwds.keyup(function (e) {
    if (e.keyCode == 8) {
        $(this).val(repeat("*", $new_pwds_str.length - 1));
        $new_pwds_str = $new_pwds_str.substring(0, $new_pwds_str.length - 1);
        $new_pwdshide.val($new_pwds_str);
    } else {
        var userInput = $(this).val();
        if (event.which === 0) {
            event.which = e.keyCode = userInput.charAt(userInput.length - 1).charCodeAt(0);
        }
        $new_pwds_str += String.fromCharCode(e.keyCode.toString());
        if ($new_pwds_str.length !== 6) {
            $new_pwds_str = $new_pwds_str.substring(0, 6)
        }
        $new_pwds.val(repeat("*", $new_pwds_str.length));
        $new_pwdshide.val($new_pwds_str);
    }
});
$('#forget_btn').tap(function (e) {
    var $this = e.currentTarget;
    var id = $($this).attr("id");
    var $dialog = $('#dialog1');
    var $weui_dialog_title = $('.weui_dialog_title');
    var mobiles = $('#mobiles').val();
    var validatecode = $('#validatecode').val();
    var new_pwdhide = $('#new_pwdhide').val();
    var new_pwdhides = $('#new_pwdshide').val();
    if (mobiles == "") {
        $weui_dialog_title.text('手机号不能为空');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    if (!/^1[3|4|5|7|8]\d{9}$/.test(mobiles)) {
        $weui_dialog_title.text('手机号码不正确');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    if (validatecode.length !== 4) {
        $weui_dialog_title.text('验证码必须四位');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    if (validatecode == "") {
        $weui_dialog_title.text('验证码必须四位不能为空');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    if (new_pwdhide.length != 6) {
        $weui_dialog_title.text('新密码必须6位');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    if (re.test(new_pwdhide) == false) {
        $weui_dialog_title.text('新密码必须数字');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    if (new_pwdhides.length !== 6) {
        $weui_dialog_title.text('确认密码必须6位');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    if (re.test(new_pwdhides) == false) {
        $weui_dialog_title.text('确认密码必须数字');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    if (new_pwdhide !== new_pwdhides) {
        $weui_dialog_title.text('确认密码和新密码不一致，请重新输入');
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            $dialog.hide();
        });
        return false;
    }
    var url = $('#forget_btn').data("url");
    var data = {
        mobile: mobiles,
        captcha: validatecode,
        new_cashpass: new_pwdhide,
        type: 2,
        continue: GetQueryString('continue')
    };
    $.post(url, data, function (data) {
        $weui_dialog_title.text(data.data.msg);
        $dialog.show();
        $dialog.find('.weui_btn_dialog').tap(function () {
            if (data.data.url != '') {
                location.href = UrlDecode(data.data.url);
            }
            $dialog.hide();
        });

    });
});
function GetQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)return (r[2]);
    return null;
}
function asc2str(ascasc) {
    return String.fromCharCode(ascasc);
}
function UrlDecode(str) {
    var ret = "";
    for (var i = 0; i < str.length; i++) {
        var chr = str.charAt(i);
        if (chr == "+") {
            ret += "";
        } else if (chr == "%") {
            var asc = str.substring(i + 1, i + 3);
            if (parseInt("0x" + asc) > 0x7f) {
                ret += asc2str(parseInt("0x" + asc + str.substring(i + 4, i + 6)));
                i += 5;
            } else {
                ret += asc2str(parseInt("0x" + asc));
                i += 2;
            }
        } else {
            ret += chr;
        }
    }
    return ret;
}