$('#btn').tap(function(){

    sendMessage()
})

var InterValObj; //timer变量，控制时间
var count = 90; //间隔函数，1秒执行
var curCount;//当前剩余秒数

function sendMessage() {
    curCount = count;
    //设置button效果，开始计时
    $("#btn").attr("disabled", "true");
    $("#btn").html( curCount + "秒后重发").css({
        background:"#f4f4f4",
        color:"#a5a5a5"
    });
    InterValObj = window.setInterval(SetRemainTime, 1000); //启动计时器，1秒执行一次
    //向后台发送处理数据
    $.ajax({
        type: "POST", //用POST方式传输
        dataType: "text", //数据格式:JSON
        url: '', //目标地址

    });
}

//timer处理函数
function SetRemainTime() {
    if (curCount == 0) {
        window.clearInterval(InterValObj);//停止计时器
        $("#btn").removeAttr("disabled");//启用按钮
        $("#btn").html("发送验证码").css({
            background:"#fff",
            color:"#559d39"
        });
    }
    else {
        curCount--;
        $("#btn").html( curCount + "秒后重发");
    }
}