$(function () {
    var ticket_close = $("#ticket_close");
    $(ticket_close).on("click", function (e) {
        $("#search").val("")
    });
    $("#submit").click(function () {
        var url = "/index.php?m=Wechat&c=Ucenter&a=activTicket";
        var code = $("#search").val();
        if (code != "") {
            loadingWindow("正在激活，请稍后...");
            window.location.href = url + "&code=" + code
        }
    })
});