define(function() {
  var App;
  return App = (function() {
    function App(name1) {
      this.name = name1;
      if ($('form') !== void 0) {
        this._formValid();
      }
      if ($('[data-calc]') !== void 0) {
        this._fixStyle();
      }
      this._initBind();
    }

    App.prototype.run = function() {
      if (this[this.name] !== void 0) {
        return this[this.name].call();
      } else {
        return require([this.name], (function(_this) {
          return function() {};
        })(this));
      }
    };

    App.prototype._formValid = function() {
      return $('form').bind('submit', function(e) {
        var $form, err, err_msg, error, isSuccess;
        $form = $(this);
        isSuccess = true;
        err_msg = '';
        try {
          $form.find('[data-valid]').each(function(i, e) {
            var id, item, name, opts, ruleReg, value;
            item = $(e);
            opts = item.data('valid');
            id = item.attr('id');
            name = $("label[for='" + id + "']").text();
            value = item.val();
            if (opts.require && value === '') {
              err_msg = "请填写 " + name;
              isSuccess = false;
            }
            if (opts.hasOwnProperty('rule')) {
              ruleReg = new RegExp(opts.rule);
              if (!ruleReg.test(value)) {
                err_msg = "填写的" + name + "格式不正确";
                item.focus();
                return isSuccess = false;
              }
            }
          });
          if (!isSuccess) {
            require(['msg'], function(Msg) {
              return new Msg({
                type: 'alert',
                text: err_msg
              });
            });
          }
        } catch (error) {
          err = error;
          isSuccess = false;
          console.log(err);
        }
        e.cancelBubble = !isSuccess;
        return isSuccess;
      });
    };

    App.prototype._fixStyle = function() {
      return $('[data-calc]').each(function(i, m) {
        var calcType, endValue, exp, k, opts, ref;
        opts = $(m).data('calc');
        if (opts.hasOwnProperty('type') && opts.hasOwnProperty('base') && opts.hasOwnProperty('exp')) {
          exp = opts.exp;
          calcType = opts.type.replace('max-', '');
          ref = opts.base;
          for (i in ref) {
            k = ref[i];
            exp = exp.replace("{" + i + "}", $(k)[calcType]());
          }
          endValue = eval(exp);
          return $(m).css(opts.type, endValue);
        }
      });
    };

    App.prototype._initBind = function() {
      $('a.go-back').tap(function(e) {
        var $this, href;
        $this = $(e.currentTarget);
        href = $this.data('href');
        if (href === void 0 || href === '') {
          return history.go(-1);
        } else {
          return location.href = href;
        }
      });
      return $('[data-go]').tap(function(e) {
        var url;
        url = $(e.currentTarget).data('go');
        if (url !== void 0) {
          location.href = url;
        }
        e.cancelBubble = false;
        return e.stopPropagation();
      });
    };

    return App;

  })();
});
