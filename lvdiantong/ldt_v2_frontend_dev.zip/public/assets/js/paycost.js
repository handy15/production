var Paycost, paycost;

Paycost = (function() {
  function Paycost() {}

  Paycost.prototype.init = function() {
    var actionName, err, error1, section;
    section = $('section[data-name]').not('[hidden]').eq(0);
    actionName = section.data('name');
    try {
      return this[actionName].call();
    } catch (error1) {
      err = error1;
      return console.warn(err);
    }
  };

  Paycost.prototype.index = function() {
    var blocks, delItem, options;
    blocks = {
      lists: 'ul.link-list',
      form: '#form-pay',
      cardMenu: '.card-menu',
      inputs: {
        cardId: '#cardId',
        companyId: '#companyId'
      }
    };
    options = $('section').data('option');
    delItem = function(item) {
      var $this, cid, param, removeUrl;
      $this = item;
      cid = $this.data('cid');
      if (options !== void 0 && options.hasOwnProperty('removeUrl')) {
        removeUrl = options.removeUrl;
        param = {
          cardId: cid
        };
        return $.ajax({
          url: removeUrl,
          type: 'get',
          data: param,
          success: function(req) {
            var ref;
            return ($this.remove() === (ref = req.msg) && ref === 'ok');
          },
          statusCode: {
            404: function(error) {
              return console.warn('未找到该户号');
            },
            500: function() {
              return console.warn('服务器内部错误');
            }
          }
        });
      }
    };
    return $(blocks.lists).tap('li', function(e) {
      var $target, $this, form;
      $this = $(e.currentTarget);
      $target = $(e.target);
      if ($target.is(blocks.cardMenu)) {
        require(['msg'], function(Msg) {
          return new Msg({
            type: 'confirm',
            title: '请确认',
            text: '是否确认要删除该户号',
            onOk: function() {
              return delItem($this);
            }
          });
        });
        return false;
      }
      $(blocks.inputs.cardId).val($this.find('.card-number').text());
      $(blocks.inputs.companyId).val($this.data('company'));
      $this.addClass('animation-touch');
      form = $(blocks.form);
      return setTimeout(function() {
        require(['msg'], function(Msg) {
          return getBill(form, Msg);
        });
        return $this.removeClass('animation-touch');
      }, 400);
    });
  };

  Paycost.prototype.new_card = function() {
    var blocks;
    blocks = {
      comShowName: '#companyName',
      companySelector: '#company',
      companyList: '#companyList',
      closeComList: 'a.panel-close',
      selectCity: '#selectCity',
      inputCID: '#companyId',
      inputCard: '#cardId',
      form: '#form-pay',
      btnScan: '.icon-scan'
    };
    new wxUnity({
      apiList: ['scanQRCode'],
      register: function() {
        return $(blocks.btnScan).tap(function(e) {
          return wx.scanQRCode({
            needResult: 1,
            desc: '扫描电费单上二维码或条形码',
            success: function(res) {
              var bill, resultStr;
              resultStr = res.resultStr;
              bill = '';
              if (resultStr.indexOf(',') > 0) {
                bill = resultStr.split(',')[1];
              } else {
                bill = parse_str(resultStr).bk;
              }
              if (bill != null) {
                return $(blocks.inputCard).val(bill);
              }
            },
            error: function(msg) {
              return console.warn(msg);
            }
          });
        });
      }
    });
    $(blocks.selectCity).tap(function(e) {
      var $this, goUrl;
      $this = $(e.currentTarget);
      goUrl = $this.data('url') + '&' + 'cityCode=' + $this.data('cityCode');
      return location.href = goUrl;
    });
    $(blocks.inputCID).bind('selectCom', function(e, selIndex) {
      var $this, item, lists;
      $this = $(e.target);
      lists = $(blocks.companyList).find('li');
      if (!$.isNumeric(selIndex)) {
        selIndex = lists.find('.current').index();
      }
      if ((0 <= selIndex && selIndex < lists.length)) {
        item = lists.eq(selIndex);
      } else {
        return false;
      }
      item.addClass('current');
      $this.val(item.data('cid'));
      return $(blocks.comShowName).text(item.text());
    });
    $(blocks.inputCID).trigger('selectCom', 0);
    $(blocks.companySelector).on('touchend', function(e) {
      $("#cardId").blur();
      $(blocks.companyList).show().find('.mask-panel').addClass('animation-slide');
      return e.preventDefault();
    });
    $(blocks.companyList).tap([blocks.closeComList, 'i.icon-close', '.mask'], function(e) {
      return $(blocks.companyList).hide();
    }).find('li').tap(function(e) {
      var $target;
      $target = $(e.currentTarget);
      $target.addClass('current').siblings().removeClass('current');
      $(blocks.inputCID).trigger('selectCom', $target.index());
      return $(blocks.companyList).hide();
    });
    return $(blocks.form).on('submit', function(e) {
      var $this, cardId, city;
      if (e.cancelBubble) {
        return false;
      }
      city = $('#selectCity > div > span.text-box > em').text();
      $this = $(this);
      cardId = $(blocks.inputCard).val();
      require(['msg'], function(Msg) {
        if (/北京/.test(city) && !(/^\d{10}$/.test(cardId))) {
          new Msg({
            text: '请确认您输入的户号是10位有效户号'
          });
          return false;
        }
        return getBill($this, Msg);
      });
      return false;
    });
  };

  Paycost.prototype.city = function() {
    var blocks, cityListData, returnUrl;
    blocks = {
      cityInput: 'input.search-input',
      cityListBox: '.city-list-box',
      cityData: '#J-city_list',
      cityTemplate: '#J_city-template'
    };
    cityListData = JSON.parse($(blocks.cityData).text());
    returnUrl = $('[data-option-url]').data('optionUrl');
    $(blocks.cityListBox).bind('renderCity', function(e, sk) {
      var $this, city, count, group, i, j, key, len, newList, reg, results, searchKey, template;
      searchKey = sk === void 0 ? '' : sk;
      $this = $(e.target);
      $this.html('');
      template = $(blocks.cityTemplate).html();
      reg = new RegExp(searchKey);
      results = [];
      for (key in cityListData) {
        group = cityListData[key];
        if (group.length > 0) {
          newList = $(template).clone();
          newList.find('dt').text(key);
          count = 0;
          for (i = j = 0, len = group.length; j < len; i = ++j) {
            city = group[i];
            if (searchKey === '' || city.initial.toLowerCase() === searchKey.substr(0, city.initial.length) || reg.test(city.name)) {
              newList.append($('<dd class="list-item"></dd>').text(city.name).data('city', city));
              count++;
            }
          }
          if (count > 0) {
            results.push($this.append(newList));
          } else {
            results.push(void 0);
          }
        } else {
          results.push(void 0);
        }
      }
      return results;
    }).trigger('renderCity');
    $(blocks.cityListBox).tap('dd', function(e) {
      var $this, cityCode, cityName, url;
      $this = $(e.currentTarget);
      cityCode = $this.data('city');
      cityName = cityCode.name;
      url = returnUrl + '&' + 'cityCode=' + cityCode.code;
      setCookie('city_name', cityName);
      setCookie('city_code', cityCode.code);
      return location.href = url;
    });
    return $(blocks.cityInput).bind('keyup', function(e) {
      var $this;
      $this = $(this);
      return $(blocks.cityListBox).trigger('renderCity', $this.val().toLowerCase());
    });
  };

  Paycost.prototype.confirm = function() {
    var $defaultPayment, Msg, blocks, defaultOpts, getTotal, hitCount, payKey, payment_count, saveKey, ticket, total, totalPrice;
    saveKey = 'paycost_confirm';
    blocks = {
      payTypeList: '.payment-list',
      iconSelect: '.J_sel-icon',
      total: '#total-price',
      originPrice: '#originPrice',
      orderSelector: '#payDate',
      payNumSelector: '#payNum',
      inputs: {
        balance: '#balancePaid',
        wePay: '#weixinPaid',
        quickPay: '#kuaiqianPaid',
        aliPay: '#aliPaid',
        umsPay: '#umsPaid',
        ticketUse: '#ticketUse',
        paymentDay: '#mentday',
        realPrice: '#realPrice',
        total: '#total',
        cno: '#cno',
        apiType: '#apiType',
        card: '#cardId'
      }
    };
    defaultOpts = {
      selOrderIndex: 0,
      payments: {
        balance: 0,
        wePay: 0,
        quickPay: 0,
        aliPay: 0,
        umsPay: 0
      },
      ticketId: ''
    };
    Msg = require('msg');
    getTotal = function(priceText) {
      var arrPrice, totalPrice;
      arrPrice = ("" + priceText).split('.');
      if (arrPrice.length === 1) {
        arrPrice.push('00');
      }
      if (arrPrice[0] === 'undefined') {
        arrPrice[0] = $(blocks.payNumSelector).find(':checked').val();
      }
      totalPrice = {
        dec: arrPrice[0],
        mix: arrPrice[1]
      };
      return totalPrice;
    };
    totalPrice = getTotal($(blocks.orderSelector).find(':checked').data('total'));
    total = totalPrice.dec + '.' + totalPrice.mix;
    $(blocks.originPrice).text(total);
    $(blocks.inputs.total).val(total);
    ticket = new Ticket({
      ticketInputDom: blocks.inputs.ticketUse,
      enableTicketType: 2,
      maxTicketAmount: +total
    });
    ticket.init();
    $(blocks.inputs.ticketUse).bind('change', function(e, ticketAmount) {
      var r_dec, realPrice;
      if ($.isNumeric(ticketAmount)) {
        if (ticketAmount <= 0) {
          ticket.unSelect(blocks.inputs.ticketUse);
        }
        r_dec = parseInt(totalPrice.dec);
        if (r_dec <= ticketAmount) {
          ticketAmount = 0;
          ticket.unSelect(blocks.inputs.ticketUse);
          require(['msg'], function(Msg) {
            return new Msg({
              text: '您的缴费金额无法使用选择的绿电券'
            });
          });
        }
        r_dec -= +ticketAmount;
        realPrice = r_dec + "." + totalPrice.mix;
        $(blocks.inputs.realPrice).val(realPrice);
        $(blocks.total).text(realPrice);
        return $('.J_ticketSelector > .strong').text(ticketAmount);
      }
    }).trigger('change', ticket.getCurrentTicketAmount());
    if ($(blocks.orderSelector).length > 0) {
      $(blocks.orderSelector).bind('change', function(e) {
        var newData, newTotal, ticketAmount;
        newData = $(e.target).find(':checked');
        newTotal = newData.data('total');
        $(blocks.inputs.total).val(newTotal);
        ticket.changeMaxAmount(+newTotal);
        totalPrice = getTotal($(blocks.inputs.total).val());
        $(blocks.originPrice).text(newTotal);
        $(blocks.inputs.cno).val(newData.data('cno'));
        ticketAmount = ticket.getCurrentTicketAmount();
        $(blocks.inputs.ticketUse).trigger('change', ticketAmount);
        return $(blocks.inputs.paymentDay).val(newData.val());
      });
    }
    if ($(blocks.payNumSelector).length > 0) {
      $(blocks.payNumSelector).bind('change', function(e) {
        var newData, newVal, ticketAmount;
        newData = $(e.target).find(':checked');
        newVal = newData.val();
        $(blocks.inputs.total).val(newVal);
        ticketAmount = ticket.getCurrentTicketAmount();
        totalPrice = getTotal($(blocks.inputs.total).val());
        return $(blocks.inputs.ticketUse).trigger('change', ticketAmount);
      });
    }
    payment_count = 0;
    if (!payment_count) {
      $defaultPayment = $('[data-payment]').first();
      $defaultPayment.find('.J_sel-icon').removeClass('icon-sel').addClass('icon-ok');
      payKey = $defaultPayment.data('payment');
      $(blocks.inputs[payKey]).val(1);
    }
    $(blocks.payTypeList).tap('li', function(e) {
      var $this, add_class_name, key, new_value, payment, ref, remove_class_name, target, value;
      $this = $(e.currentTarget);
      payment = $this.data('payment');
      target = $(blocks.inputs[payment]);
      new_value = target.val() ^ 1;
      if (new_value) {
        remove_class_name = 'icon-sel';
        add_class_name = 'icon-ok';
      } else {
        remove_class_name = 'icon-ok';
        add_class_name = 'icon-sel';
      }
      target.val(new_value);
      if (new_value === 1 && payment !== 'balance') {
        ref = defaultOpts.payments;
        for (key in ref) {
          value = ref[key];
          if (key === payment || key === 'balance') {
            continue;
          }
          $(blocks.inputs[key]).val(0);
          $("[data-payment='" + key + "']").find(blocks.iconSelect).removeClass('icon-ok').addClass('icon-sel');
        }
      }
      return $this.find(blocks.iconSelect).removeClass(remove_class_name).addClass(add_class_name);
    });
    hitCount = 0;
    return $('form').on('submit', function(e) {
      var ali, b, card, cno, q, ums, w;
      if (hitCount > 0) {
        return false;
      }
      b = $(blocks.inputs.balance).val();
      w = $(blocks.inputs.wePay).val();
      q = $(blocks.inputs.quickPay).val();
      ali = $(blocks.inputs.aliPay).val();
      ums = $(blocks.inputs.umsPay).val();
      card = $(blocks.inputs.card).val();
      cno = $(blocks.inputs.cno).val();
      if (cno === '010' && !(/^\d{10}$/.test(card))) {
        alert('请输入正确的10位户号');
        location.href = history.back();
        return false;
      }
      if (confirm("请确认您要缴费的户号是： " + card)) {
        if ((+b < 1 || b === '') && (+w < 1 || w === '') && (+q < 1 || q === '') && (+ali < 1 || ali === '') && (+ums < 1 || ums === '')) {
          require(['msg'], function(Msg) {
            return new Msg({
              text: '请至少选择一种支付方式'
            });
          });
          return false;
        }
        hitCount++;
        return true;
      }
      return false;
    });
  };

  return Paycost;

})();

paycost = new Paycost();

paycost.init();
