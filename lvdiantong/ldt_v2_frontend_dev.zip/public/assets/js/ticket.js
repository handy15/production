var Ticket;

Ticket = (function() {
  function Ticket(options) {
    this.options = options;
  }

  Ticket.prototype.init = function() {
    var $default, $defaultData, blocks, currentTicketAmount, defaultId, defaultOptions, i, len, ref, ticketLi;
    defaultOptions = {
      enableTicketType: 2,
      ticketInputDom: 'input[name="ticketUse"]',
      maxTicketAmount: 15
    };
    currentTicketAmount = 0;
    this.options = $.extend(defaultOptions, this.options);
    blocks = {
      ticketList: '#ticket-list',
      ticketSelector: '.J_ticketSelector',
      ticketWrapper: '.ticket-wrapper'
    };
    $default = null;
    defaultId = $(this.options.ticketInputDom).val();
    ref = $(blocks.ticketWrapper).find('li[data-tk-check]');
    for (i = 0, len = ref.length; i < len; i++) {
      ticketLi = ref[i];
      if ($(ticketLi).data('tk').type === this.options.enableTicketType && $(ticketLi).data('tk').amount < this.options.maxTicketAmount) {
        if (defaultId) {
          if ($(ticketLi).data('tk').id === +defaultId) {
            $default = $(ticketLi);
            break;
          }
        } else {
          $default = $(ticketLi);
          break;
        }
      }
    }
    if ($default != null) {
      $default.data('tk-check', 1).find('i.icon-sel').removeClass('icon-sel').addClass('icon-ok');
      $defaultData = $default.data('tk');
    }
    if ($defaultData !== void 0) {
      $(this.options.ticketInputDom).val($defaultData.id);
      currentTicketAmount = $defaultData.amount;
    }
    $(blocks.ticketSelector).tap(function(e) {
      e.preventDefault();
      return $(blocks.ticketList).show().find('.mask-panel').addClass('animation-slide');
    });
    $(blocks.ticketList).on('touchend', (function(_this) {
      return function(e) {
        var $this;
        e.preventDefault();
        $this = $(e.currentTarget);
        if (e.target.className === 'mask') {
          $this.hide().find('.mask-panel').removeClass('animation-slide');
          return $(_this.options.ticketInputDom).trigger('change', currentTicketAmount);
        }
      };
    })(this));
    $('.panel-header').on('touchend', function(e) {
      $(blocks.ticketWrapper).find('.icon-ok').removeClass('icon-ok').addClass('icon-sel').parent().data('tk-check', 0);
      currentTicketAmount = 0;
      $('.mask').trigger('touchend');
      return $('#ticketUse').val('');
    });
    return $(blocks.ticketWrapper).tap('li', (function(_this) {
      return function(e) {
        var $this, checked, ticketData;
        $this = $(e.currentTarget);
        checked = parseInt($this.data('tk-check'));
        ticketData = $this.data('tk');
        if (!((ticketData != null) && ticketData.type === _this.options.enableTicketType)) {
          return false;
        }
        checked = +checked ^ 1;
        if (checked && !ticketData.expired && ticketData.type === _this.options.enableTicketType) {
          $this.parent().find('i.icon-ok').removeClass('icon-ok').addClass('icon-sel').parent().data('tk-check', 0);
          $this.data('tk-check', 1).find("i").eq(0).removeClass('icon-sel').addClass('icon-ok');
          $(_this.options.ticketInputDom).val(ticketData.id);
          currentTicketAmount = ticketData.amount;
          return $('.mask').trigger('touchend');
        } else {
          $this.data('tk-check', 0).find('i').eq(0).removeClass('icon-ok').addClass('icon-sel');
          $(_this.options.ticketInputDom).val('');
          return currentTicketAmount = 0;
        }
      };
    })(this));
  };

  Ticket.prototype.getCurrentTicketAmount = function() {
    var $target, amount, ticketData;
    amount = 0;
    $target = $('.ticket-wrapper').find('i.icon-ok').parent();
    if ($target === null) {
      return 0;
    }
    ticketData = $target.data('tk');
    if (ticketData !== void 0) {
      amount = ticketData.amount;
    }
    return amount;
  };

  Ticket.prototype.unSelect = function(inputDom) {
    var $target;
    $target = $('.ticket-wrapper').find('i.icon-ok').removeClass('icon-ok').addClass('icon-sel').parent();
    $target.data('tk-check', 0);
    return $(inputDom).val('');
  };

  Ticket.prototype.changeMaxAmount = function(maxAmount) {
    if ($.isNumeric(maxAmount)) {
      return this.options.maxTicketAmount = maxAmount;
    }
  };

  return Ticket;

})();
