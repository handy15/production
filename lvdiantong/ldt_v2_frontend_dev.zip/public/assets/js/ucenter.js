var Ucenter, ucenter;

Ucenter = (function() {
  function Ucenter() {}

  Ucenter.prototype.init = function() {
    var actionName, err, error, section;
    section = $('section[data-name]').not('[hidden]').eq(0);
    actionName = section.data('name');
    try {
      return this[actionName].call();
    } catch (error) {
      err = error;
      return console.warn(err);
    }
  };

  Ucenter.prototype.tickets = function() {
    var Msg, blocks, tapLock;
    Msg = require('msg');
    tapLock = false;
    blocks = {
      ticketWrapper: '.ticket-wrapper > ul',
      activeButton: 'button.ticket-active',
      ticketInput: 'input[name="ticketCode"]',
      clearTextButton: '.icon-cross'
    };
    $(blocks.clearTextButton).tap(function() {
      return $(blocks.ticketInput).val('');
    });
    $(blocks.ticketWrapper).tap('li', function(e) {
      var $this, url;
      $this = $(e.currentTarget);
      url = $this.data('go');
      if (url != null) {
        return location.href = url;
      }
    });
    return $(blocks.activeButton).tap(function(e) {
      var activeUrl, data, ticketCode;
      if (tapLock) {
        return false;
      }
      ticketCode = $(blocks.ticketInput).val().trim();
      if (ticketCode === '') {
        new Msg({
          text: '请输入激活码'
        });
        return false;
      }
      tapLock = true;
      activeUrl = $(e.target).data('activeUrl');
      data = {
        code: ticketCode
      };
      loadingWindow('正在激活请稍后');
      return $.getJSON(activeUrl, data, function(res) {
        var $newTicket, i, jumpUrl, len, ref, ticketClass, ticketName, tkData, tpl;
        closeLoading();
        if (res.success) {
          new Msg({
            text: '激活成功'
          });
          if (res.data != null) {
            tpl = $('#J_ticket-tpl').html();
            ref = res.data;
            for (i = 0, len = ref.length; i < len; i++) {
              tkData = ref[i];
              switch (+tkData.limit_use_type) {
                case 3:
                  ticketName = '套餐券';
                  ticketClass = 'card-orange';
                  jumpUrl = '/wechat/package';
                  break;
                default:
                  ticketName = '绿电券';
                  ticketClass = 'card-green';
                  jumpUrl = '/wechat/paycost';
              }
              $newTicket = $(tpl);
              $newTicket.addClass(ticketClass).data('go', jumpUrl).find('.tk-title').prepend(ticketName).find('.tk-price').text(tkData.coupon_amount);
              $newTicket.find('.tk-desc').html(tkData.coupon_name + '<br>' + tkData.description);
              $newTicket.find('.tk-express').text('有效期 ' + tkData.coupon_start_date_format + ' 至 ' + tkData.coupon_expire_date_format);
              $(blocks.ticketWrapper).prepend($newTicket);
            }
          }
        } else {
          new Msg({
            title: '激活失败',
            text: res.msg
          });
        }
        return tapLock = false;
      });
    });
  };

  return Ucenter;

})();

ucenter = new Ucenter();

ucenter.init();
