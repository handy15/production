var wx, wxUnity,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

wx = require('wxApi');

wxUnity = (function() {
  function wxUnity(config) {
    var defaultConfig, dtd;
    this.config = config;
    this._getSignature = bind(this._getSignature, this);
    defaultConfig = {
      signatureUrl: '/api/weixin/signature',
      localUrl: encodeURIComponent(location.href),
      apiList: ['scanQRCode'],
      register: function() {
        return console.warn('not any register function');
      }
    };
    this.config = $.extend(defaultConfig, this.config);
    dtd = $.Deferred();
    $.when(this._getSignature(dtd)).done((function(_this) {
      return function() {
        var wx_config;
        wx_config = $.extend({
          debug: false,
          jsApiList: _this.config.apiList
        }, _this.wxOptions);
        return wx.config(wx_config);
      };
    })(this));
    wx.error(function(res) {
      return console.wran(res);
    });
    wx.ready((function(_this) {
      return function() {
        return _this.config.register();
      };
    })(this));
  }

  wxUnity.prototype._getSignature = function(dtd) {
    var url;
    url = this.config.signatureUrl + "?url=" + this.config.localUrl;
    $.getJSON(url, (function(_this) {
      return function(res) {
        _this.wxOptions = res.data;
        return dtd.resolve();
      };
    })(this));
    return dtd;
  };

  return wxUnity;

})();
