var express = require('express');
var fs = require('fs');
var path = require('path');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.send("hello");
});
router.get('/removeCard', function(req, res, next){
    res.send({success: true});
});
router.all('/weixin/signature', function(req, res, next) {
  var obj = {
      appId: 'wxa91cef8d5d88f89a',
      timestamp: 1449217452,
      nonceStr: 'GkWITDGgnr2fwJ0m9E8NYzWKVZvdVC',
      signature: '99b0f8f61c448a4fcef4adca115503a094690a65'
  };
  res.send(obj);
});

router.all('/queryPayStatus', function(req, res, next){
  fs.readFile(path.resolve(__dirname,'../public/data/queryOrderStatus.json'),
  'utf8', function(err, content){
      res.send(JSON.parse(content));
  });
});
module.exports = router;
