var express = require('express');
var router = express.Router();
router.get('/', function(req, res, next) {
    res.send('respond with a resource');
});

router.get('/product_detail', function(req, res, next) {
    res.render('package/product_detail', { title: '绿电资产'});
});
router.get('/assets', function(req, res, next) {
    res.render('package/assets', { title: ''});
});

router.get('/account', function(req, res, next) {
    res.render('package/account', { title: ''});
});


module.exports = router;