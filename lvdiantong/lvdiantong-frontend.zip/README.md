﻿npm run build  == gulp

php app/bin/ptphp.php --cli=deploy --action=dev_frontend