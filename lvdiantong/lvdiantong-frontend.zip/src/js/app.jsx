import React                    from 'react'
import ReactDOM                 from 'react-dom'
import createHashHistory        from 'history/lib/createHashHistory'

import {
    Router,
    useRouterHistory
}                               from 'react-router';

import FrontRoutes             from './routes/front.jsx'
const history = useRouterHistory(createHashHistory)({ queryKey: false })

ReactDOM.render(
    <Router children={FrontRoutes} history={history}/>,
    document.getElementById('root')
);