import "../../css/frontend.css";
import '../../less/frontend.less';

window.Utils = require("../utils");

if(!window.API_URL){
    window.API_URL = "http://local.dian.solarbao.com/service/api.php";
}

window.get_access_token = function(){
    return window.localStorage.access_token ? window.localStorage.access_token:"";
}
window.set_access_token = function(response){
    if (response.access_token && window.localStorage.access_token != response.access_token) {
        window.localStorage.access_token = response.access_token;
    }
}