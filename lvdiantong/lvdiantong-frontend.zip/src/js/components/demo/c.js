'use strict';

console.info('require page c.11111');

require('commonCss');

require('zepto');

// 直接使用npm模块
var _ = require('lodash');

var report = require('./helpers/report');
var bar = require('./helpers/bar');
var url = require('./utils/url');
