'use strict';

require('../../css/components/dialog.css');

console.info('require dialog module.');

var mask = require('./mask');

function Dialog() {
    // todo
}

module.exports = Dialog;
