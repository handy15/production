'use strict';

console.info('require mask module.');

function mask() {
    // todo
}

module.exports = mask;
