'use strict';

require('../../css/components/toast.css');

console.info('require toast module.');

function Toast() {
    // todo
}

module.exports = Toast;
