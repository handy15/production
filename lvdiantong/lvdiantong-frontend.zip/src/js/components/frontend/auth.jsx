import React,{Component} from 'react';
import { QueueAnim } from 'antd';

import "../../common/frontend.jsx";

export default class Auth extends Component {
    render() {
        const key = this.props.location.pathname;
        console.log(key)
        //return (
        //    <div>
        //        {React.cloneElement(this.props.children || null, {key: key})}
        //    </div>
        //);
        return (
            <QueueAnim type={['right', 'left']} className="pt-router-wrap">
                {React.cloneElement(this.props.children || null, {key: key})}
            </QueueAnim>
        );
    }
}
