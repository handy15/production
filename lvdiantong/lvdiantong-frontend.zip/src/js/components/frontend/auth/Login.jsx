import React , { Component } from 'react';
import { QueueAnim} from 'antd';
const ReactRouter = require('react-router');
let { Link } = ReactRouter;
import reqwest from 'reqwest';
import Header from '../../../components/frontend/common/Header.jsx';
const Login = React.createClass({
    getInitialState() {
        return {
            formData: {
                username: '',
                password: ''
            },
            paddingTop:'0',
            loading: false,
            loading_msg:"提交中",
            show_toast:false,
            toast_msg:"成功",
            alert_show:false,
            display:'block'
        };
    },
    contextTypes: {
        router: React.PropTypes.object.isRequired
    },
    alert(msg,func){
        if(func == undefined) func = fasle;
        this.setState({
            alert_show:true,
            alert_msg:msg,
            alert_func:func
        });
    },
    handleSubmit(e){
        e.preventDefault();

        this.handleAjax();

    },
    handleAjax:function(){
        "use strict";
        var self = this;
        if (this.state.formData.username.length < 1) {
            return this.alert("用户名不合法",function(){
                self.refs.mobile.focus()
            });
        }
        if (this.state.formData.password.length < 6) {
            return this.alert("密码不能少于6位",function(){
                self.refs.password.focus()
            });
        }
        this.setState({loading: true});
        var data = {};
        data.username = this.state.formData.username;
        data.password = this.state.formData.password;
        data.action = "login";
        data.controller = "auth";
        data.access_token = get_access_token();
        //console.log(data);
        reqwest({
            url: API_URL,
            method: 'post',
            data: data,
            type: 'json',
            success: (response) => {
                //debugger;
                set_access_token(response);
                if (response.error > 0) {
                    this.setState({
                        loading: false,
                        alert_show:true,
                        alert_msg:response.result,
                        alert_func:null
                    });
                } else {
                    window.localStorage.logined = true;
                    this.setState({
                        loading: false,
                        alert_show:true,
                        alert_msg:response.result.message,
                        alert_func:function(){
                            var continue_url = Utils.url.getQuery("continue");
                            if(continue_url.length > 0){
                                //todo FUCK twice DECODE ???
                                location.href = decodeURIComponent(decodeURIComponent(continue_url));
                            }else{
                                location.href = "/";
                            }
                        }
                    });
                    //this.context.router.push("/");
                }
            }
        });
    },
    onFocus(){
        this.setState({
            display: 'none',
            paddingTop:'1rem'
        });

    },
    onBlur(){
        this.setState({
            display: 'none',
            paddingTop:'1rem'
        }

        );
    },

    setFormValue(key,event){
        var formData = this.state.formData;
        formData[key] = event.target.value;
        this.setState({formData:formData})
    },
    componentDidMount (){

    },
    render(){
        const login_logo = require("loginLogo");
        let rightBtn = {
            linkTo:"/reg",
            title:"注册"
        };
        let formData = this.state.formData;
        const ToastLoading = Utils.UI.Wechat.Toast.ToastLoading;
        const Alert = Utils.UI.Wechat.Dialog.Alert;
        let { padding } = this.state;
        return (
            <div style={{height:"100%"}}>

                <Alert parent={this} show={this.state.alert_show} msg={this.state.alert_msg} alert_func={this.state.alert_func} />
                <ToastLoading msg={this.state.loading_msg} show={this.state.loading}/>
                <Header title="登录" rightBtn={rightBtn}/>
                <section className="bgclass">
                    <div className="banner"  style={{display:this.state.display}}><img src={login_logo}/></div>
                    <form className="" method="post" className="form-container reg-form"  style={{'paddingTop':this.state.paddingTop}}   >
                        <div className="lab-text"></div>
                        <div className="bianju">
                            <div className="gaodu fl"><i className="shouji" /></div>
                            <div className="tel fl">
                                <input placeholder="手机或者用户名" ref='mobile'
                                       value={formData.username}
                                       onChange={this.setFormValue.bind(this,"username")}
                                       onFocus={this.onFocus}
                                       onBlur={this.onBlur}
                                />
                            </div>
                        </div>
                        <div className="lab-text"></div>
                        <div className="bianju">
                            <div className="gaodu fl"><i className="pwd"/></div>
                            <div className="tel fl">
                                <input type="password" placeholder="密码"
                                       value={formData.password} ref="password"
                                       onChange={this.setFormValue.bind(this,"password")}
                                       onFocus={this.onFocus}
                                       onBlur={this.onBlur}
                                /></div>
                        </div>
                        <div className="lost_pwd"><span><Link to="/reset_pwd">忘记密码？</Link></span></div>
                        <div className="button">
                            <button type="button" onClick={this.handleSubmit}>登录</button>
                        </div>
                    </form>
                </section>
            </div>

        )
    }
});
export default Login;