import React , { Component } from 'react';
import Header from '../../../components/frontend/common/Header.jsx';
import reqwest from 'reqwest';
import { Modal, Button } from 'antd';

const ResetPwd = React.createClass({
    getInitialState() {
        return {
            formData: {
                username: '',
                password: '',
                captcha: ''
            },
            captcha_btn_disabled:true,
            loading: false,
            loading_msg:"提交中",
            show_toast:false,
            toast_msg:"成功",
            alert_show:false,
            alert_msg:"",
            alert_func:false,
            get_captcha_tip:"..."
        };
    },
    contextTypes: {
        router: React.PropTypes.object.isRequired
    },
    alert(msg,func){
        if(func == undefined) func = fasle;
        this.setState({
            alert_show:true,
            alert_msg:msg,
            alert_func:func
        });
    },
    handleSubmit(e){
        e.preventDefault();
        //debugger;
        var self = this;
        if (!Utils.checker.is_mobile(this.state.formData.username)) {
            return this.alert("手机号不合法",function(){
                self.refs.mobile.focus()
            });
        }

        if (this.state.formData.captcha.length != 6) {
            return this.alert("验证码不合法",function(){
                self.refs.captcha.focus()
            });
        }
        if (this.state.formData.password.length < 6) {
            return this.alert("密码不能少于6位",function(){
                self.refs.password.focus()
            });
        }
        this.setState({loading: true});
        var data = {};
        data.username = this.state.formData.username;
        data.password = this.state.formData.password;
        data.captcha = this.state.formData.captcha;
        data.action = "reset_pwd";
        data.controller = "auth";
        data.access_token = get_access_token();
        //console.log(data);
        reqwest({
            url: API_URL,
            method: 'post',
            data: data,
            type: 'json',
            success: (response) => {
                //debugger;
                set_access_token(response);
                if (response.error > 0) {
                    this.setState({
                        loading: false,
                        alert_show:true,
                        alert_msg:response.result,
                        alert_func:null
                    });
                } else {
                    window.localStorage.logined = true;
                    this.setState({
                        loading: false,
                        alert_show:true,
                        alert_msg:"修改密码成功",
                        alert_func:()=>{
                            this.context.router.push("/login");
                        }
                    });
                }
            }
        });

    },
    setFormValue(key,event){
        var formData = this.state.formData;
        formData[key] = event.target.value;
        this.setState({formData:formData})
    },
    get_mobile_captcha(e){
        var time = this.get_left_time();
        if(time > 0) return false;
        e.preventDefault();
        //debugger;
        var self = this;
        if (!Utils.checker.is_mobile(this.state.formData.username)) {
            return this.alert("手机号不合法",function(){
                self.refs.mobile.focus()
            });
        }
        var data = {};
        data.mobile = this.state.formData.username;
        data.action = "reset_pwd";
        data.controller = "captcha";
        data.access_token = get_access_token();
        //console.log(data);
        reqwest({
            url: API_URL,
            method: 'post',
            data: data,
            type: 'json',
            success: (response) => {
                //debugger;
                set_access_token(response);
                var formData = this.state.formData;
                formData.captcha = "";
                if (response.error > 0) {
                    this.setState({
                        loading: false,
                        alert_show:true,
                        alert_msg:response.result,
                        alert_func:null,
                        formData:formData,
                        captcha_btn_disabled:false
                    });
                } else {
                    var second = response.result.second;
                    this.set_left_time(second);
                    this.setState({
                        loading: false,
                        formData:formData,
                        captcha_btn_disabled:true
                    });
                }
            }
        });
        //alert(1);
        this.setState({loading:true,loading_msg:"提交中..."});
    },
    set_left_time(num){
        this.reset_pwd_captcha_left_time = num;
    },
    get_left_time(){
        var time = this.reset_pwd_captcha_left_time;
        return time != undefined ? parseInt(time): 0;
    },
    componentWillUnmount (){
        clearInterval(window.t1_interval);
    },
    componentDidMount (){
        this.reset_pwd_captcha_left_time = 0;
        //this.set_left_time(50);
        var self = this;
        window.t1_interval = setInterval(()=>{
            var time = this.get_left_time();
            console.log(time,this.state.captcha_btn_disabled);
            if(time > 0){
                this.set_left_time(time - 1);
                this.setState({
                    get_captcha_tip:"重发 ( "+(time - 1)+" 秒)",
                    captcha_btn_disabled:true
                });
            }else{
                if(this.state.captcha_btn_disabled){
                    this.setState({
                        get_captcha_tip:"获取验证码",
                        captcha_btn_disabled:false
                    });
                }
            }
        },1000);


        var data = {};
        data.action = "reset_pwd_status";
        data.controller = "captcha";
        data.access_token = get_access_token();
        //console.log(data);
        reqwest({
            url: API_URL,
            method: 'post',
            data: data,
            type: 'json',
            success: (response) => {
                //debugger;
                set_access_token(response);
                if (response.error > 0) {

                } else {
                    console.log(response);
                    if(parseInt(response.result) > 0 &&
                        parseInt(response.result) < 50){
                        this.set_left_time(50 - parseInt(response.result) - 1);
                        this.setState({
                            get_captcha_tip:"重发 ( "+(50 - response.result - 1)+" 秒)",
                            captcha_btn_disabled:true
                        });
                    }else{
                        //console.log("获取验证码");
                        this.setState({
                            get_captcha_tip:"获取验证码",
                            captcha_btn_disabled:false
                        });
                    }
                }
            }
        });


    },
    render(){
        let rightBtn = {
            linkTo:"/login",
            title:"登录"
        };
        const ToastLoading = Utils.UI.Wechat.Toast.ToastLoading;
        const Alert = Utils.UI.Wechat.Dialog.Alert;

        const login_logo = require("loginLogo");
        return (
            <div style={{height:"100%"}}>
                <Alert parent={this} show={this.state.alert_show} msg={this.state.alert_msg} alert_func={this.state.alert_func} />
                <ToastLoading msg={this.state.loading_msg} show={this.state.loading}/>
                <Header title="忘记密码" rightBtn={rightBtn}/>
                <section className="bgclass">
                    <div className="banner"  style={{paddingBottom:0,border:"none",height:100}}><img style={{margin:"10px 0 0 0"}} src={login_logo} /></div>
                    <div className="reg_form" style={{height:"auto"}}>
                        <div className="boder">
                            <i className="reg_shouji" />
                            <input type="tel" placeholder="请输入手机号"
                                   value={this.state.formData.username} ref="mobile"
                                   onChange={this.setFormValue.bind(this,"username")}
                            />
                        </div>
                        <div className="boder">
                            <i className="reg_yanzhengma" />
                            <input id="input_button"
                                   placeholder="验证码"
                                   value={this.state.formData.captcha} ref="captcha"
                                   onChange={this.setFormValue.bind(this,"captcha")}
                            />
                            <button id="regbtn" type="button"
                                    disabled={this.state.captcha_btn_disabled}
                                    onClick={this.get_mobile_captcha}>{this.state.get_captcha_tip}</button>
                        </div>

                    </div>
                    <div style={{backgroundColor:"#F3F3F3",
                                padding:"10px 0 10px 15px",
                                borderTop:"1px solid #eee",
                                borderBottom:"1px solid #eee"}}>
                        <span style={{color:"#666"}}>设置新密码</span>
                    </div>
                    <div className="reg_form" style={{height:"auto"}}>
                        <div className="boder" style={{marginTop:2}}>
                            <i className="reg_pwd" />
                            <input type="password" placeholder="请输入新密码"
                                   value={this.state.formData.password} ref="password"
                                   onChange={this.setFormValue.bind(this,"password")}
                            />
                        </div>
                        <button type="button" style={{marginTop:26,background:"#559d39"}} onClick={this.handleSubmit} className="submit">提交</button>
                    </div>
                </section>
            </div>
        )
    }
})

export default ResetPwd;