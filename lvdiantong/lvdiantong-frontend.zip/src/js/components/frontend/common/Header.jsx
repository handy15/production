import React , { Component } from 'react';
const ReactRouter = require('react-router');
let { Link } = ReactRouter;

export default class Header extends Component{
    go_back(){
        history.go(-1);
    }
    render() {
        return (
            <header id="content" className="header">
                <a className="go-back fl" onClick={this.go_back}>
                    <icon className="icon-back" />
                </a>
                {this.props.title}
                <Link to={this.props.rightBtn.linkTo} className="user-link fr">{this.props.rightBtn.title}</Link>
            </header>
        )
    }
}