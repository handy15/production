import React from 'react';
import { Breadcrumb ,QueueAnim} from 'antd';
import Sider from "./Sider.jsx";
import reqwest from 'reqwest';

const Manage = React.createClass({
    getInitialState(){
        return {
            show:false
        }
    },
	contextTypes: {
		router: React.PropTypes.object.isRequired
	},
	go_login(){
		console.log("go_login");
		this.context.router.push("/login");
		clearInterval(window.access_checking_time_id);
	},
	componentDidMount(){
		if (!window.localStorage.safe_logined) {
			return this.go_login();
		}
		this.synchronize();
	},
	componentWillUnmount(){
		//console.log("componentWillUnmount");
		clearInterval(window.access_checking_time_id);
	},
	synchronize() {
		//this.setState({ loading: true });
		reqwest({
			url: API_URL,
			method: 'get',
			data: {
				controller:"admin/synchronize",
				action: "data",
				access_token: get_access_token()
			},
			type: 'json',
			success: (response) => {
				//debugger;
				set_access_token(response);
				if (response.error == 8001) {
					//alert(response.result);
					window.localStorage.safe_logined = false;
					this.go_login();
				} else if (response.error > 0){
                    this.setState({
                        show:false
                    });
					alert(response.result);
				}else{
                    if(!this.state.show){
                        this.setState({
                            show:true
                        });
                    }
                    setTimeout(this.synchronize,5000);
				}
			}
		});
	},
	render() {
        const key = this.props.location.pathname;
        if(!this.state.show){
            return <div></div>
        }
		return (
			<div className="ant-layout-aside">
				<Sider location={this.props.location} />
				<div className="ant-layout-main">
					<div className="ant-layout-header"></div>
					<div className="ant-layout-breadcrumb hide">

					</div>
					<div className="ant-layout-container">
						<div className="ant-layout-content">
                            <QueueAnim type={['right', 'left']} className="pt-router-wrap" duration={100}>
                                {React.cloneElement(this.props.children || <div />, {key: key})}
							</QueueAnim>
						</div>
					</div>
					<div className="ant-layout-footer">
						版权所有 © 2015
					</div>
				</div>
			</div>
		)
	}
});

export default Manage;
