import React from 'react';
import { DatePicker, message } from 'antd';
import { Table ,Button ,Icon} from 'antd';
import { Menu, Switch,Breadcrumb } from 'antd';
const SubMenu = Menu.SubMenu;
const ReactRouter = require('react-router');
let { Link } = ReactRouter;
const Sider = React.createClass({
	contextTypes: {
		router: React.PropTypes.object.isRequired
	},
	menuSelect(item, key, selectedKeys){
        console.log(item)
		this.context.router.push("/"+item.key);
	},
	render() {
        //debugger;
		const key = this.props.location.pathname;
		console.log(key);
		const keys = key.replace('/', '') ? [ key.replace('/', '') ] : [ 'manage/user' ];
        const keys_open = [ 'user' ];
		return (
			<aside className="ant-layout-sider">
				<div className="ant-layout-logo">绿电通</div>
				<Menu mode="inline" theme="dark" onSelect={this.menuSelect}
					  defaultSelectedKeys={keys}
					  defaultOpenKeys={keys_open}>
					<SubMenu key="user"
							 title={<span><Icon type="user" />用户</span>}>
						<Menu.Item key="manage/user">用户管理</Menu.Item>
					</SubMenu>
					<SubMenu key="task"
							 title={<span><Icon type="laptop" />任务</span>}>
						<Menu.Item key="task/ticket">领券同步</Menu.Item>
					</SubMenu>
					<SubMenu key="system"
							 title={<span><Icon type="laptop" />系统</span>}>
						<Menu.Item key="system/setting">设置</Menu.Item>
                        <Menu.Item key="system/log">操作日志</Menu.Item>
					</SubMenu>
					{/**
                     <Menu.Item key="mail">
                     <Link to="/manage/user"><Icon type="user" />用户管理</Link>
                     </Menu.Item>
					<SubMenu key="sub_package" title={<span><Icon type="laptop" />套餐</span>}>
						<Menu.Item key="/manage/package">套餐</Menu.Item>
						<Menu.Item key="/manage/package/order">订单</Menu.Item>
					</SubMenu>
					<SubMenu key="sub_task" title={<span><Icon type="laptop" />任务</span>}>
						<Menu.Item key="/task/user">同步用户</Menu.Item>
						<Menu.Item key="/task/sms">发送短信</Menu.Item>
						<Menu.Item key="/task/ticket">领券同步</Menu.Item>
						<Menu.Item key="/task/package">套餐订单缴费</Menu.Item>
					</SubMenu>

					 <SubMenu key="sub_system" title={<span><Icon type="laptop" />系统</span>}>
					 <Menu.Item key="/manage/user">设置</Menu.Item>
					 <Menu.Item key="/manage/user">操作日志</Menu.Item>
					 </SubMenu>
					 */}
				</Menu>
			</aside>
		);
	}
});

export default Sider;
