import React from 'react';
import Sentry from 'react-sentry';
import Tappable from 'react-tappable';

var EventEmitter = require('events').EventEmitter;
var emitter = new EventEmitter();

import { Table , Form , Row , Col , Input , Button, Modal, Spin} from 'antd';
const FormItem = Form.Item;

import reqwest from 'reqwest';
var _ = require('lodash');
Date.prototype.format = function(format) {
    var o = {
        "M+": this.getMonth() + 1,
        // month
        "d+": this.getDate(),
        // day
        "h+": this.getHours(),
        // hour
        "m+": this.getMinutes(),
        // minute
        "s+": this.getSeconds(),
        // second
        "q+": Math.floor((this.getMonth() + 3) / 3),
        // quarter
        "S": this.getMilliseconds()
        // millisecond
    };
    if (/(y+)/.test(format) || /(Y+)/.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
        }
    }
    return format;
};
const columns = [
	{
		title: 'UID',
        key:"user_id",
		dataIndex: 'user_id'
	},
	{
		title: '用户名',
        key:"username",
		dataIndex: 'username'
	},
	{
		title: '手机号',
        key:"mobile",
		dataIndex: 'mobile',
		sorter: true
	},
	{
		title: '是否锁定',
        key:"locked",
		dataIndex: 'locked'
	},
	{
		title: '注册时间',
        key:"addtime",
		dataIndex: 'addtime',
		render: function(text,row,index) {
            //console.log(e,e1)
            var date = (new Date(parseFloat(text)*1000)).format("yyyy-MM-dd hh:mm:ss");
            return <span>{date}</span>;
		}
	},
    {title: '操作', dataIndex: '', key: 'x', render: function(text,row,index){
        return (
            <div>
                <Tappable onTap={emitter.emit.bind(emitter, 'onLockAction',row.key)}>
                    <Button size="small">锁定</Button>
                </Tappable>
            </div>
        );
    }}
];
function expandedRowRender(row) {
    return <p>余额: {row.balance} 元</p>;
}

const User = React.createClass({
    mixins: [Sentry],
	getInitialState() {
		return {
			data: [],
			pagination: {},
			loading: false,
            rowSelection:{},
            selectedRowKeys:[],
            visible: false,
            ModalText: '对话框的内容',
            Spin_loading:false,
		};
	},
	handleTableChange(pagination, filters, sorter) {
		const pager = this.state.pagination;
		pager.current = pagination.current;
		this.setState({
			pagination: pager
		});
		const params = {
			pageSize: pagination.pageSize,
			currentPage: pagination.current,
			sortField: sorter.field,
			sortOrder: sorter.order
		};
		for (let key in filters) {
			params[key] = filters[key];
		}
		this.fetch_user_list(params);
	},
	fetch_user_list() {
		this.setState({ loading: true });
		if (window.localStorage.access_token == undefined) {
			window.localStorage.access_token = "";
		}
		reqwest({
			url: API_URL,
			method: 'post',
			data: {
				action: "list",
				controller:"admin/user",
				access_token: get_access_token()
			},
			type: 'json',
			success: (response) => {
				//debugger;
				set_access_token(response);
				if(response.error){
					return alert(response.result)
				}
                const rowSelection = this.state.rowSelection;
                rowSelection.onChange = this.onChange;
				const pagination = this.state.pagination;
				pagination.total = response.result.total;
				pagination.pageSize = response.result.limit;
				this.setState({
					loading: false,
					data: response.result.rows,
					pagination
				});
			}
		});
	},
    handleOk() {
        this.setState({
            confirmLoading: true,
            Spin_loading:true
        });
        setTimeout(() => {
            this.setState({
                visible: false,
                confirmLoading: false
            });
        }, 2000);
    },
    handleCancel() {
        console.log('点击了取消');
        this.setState({
            visible: false
        });
    },
	componentDidMount() {
		var self = this;
		setTimeout(function () {
			self.fetch_user_list();
		}, 0);
        var self = this;
        this.watch(emitter, 'onModifyAction', function (row_key) {
            console.log(row_key)
            self.setState({
                visible: true,
                ModalText:(
                    <Spin spining={self.state.Spin_loading}>
                        <Form >
                            <FormItem id="userName" label="账户：">
                                <Input placeholder="请输入账户名" id="userName" name="userName" />
                            </FormItem>
                        </Form>
                    </Spin>
                )
            });
        });
        this.watch(emitter, 'onLockAction', function (row_key) {
            console.log("onlock",row_key)

        });
	},
    onSelectRow(record, selected, selectedRows) {
        const selectedRowKeys = [];
        selectedRows.map(function(row){
            selectedRowKeys.push(row.key);
        });
        console.log(record, selected, selectedRows);
        this.setState({ selectedRowKeys });
    },
    onSelectAllRow(record, selected, selectedRows) {
        console.log(record, selected, selectedRows);
        const selectedRowKeys = [];
        selected.map(function(row){
            selectedRowKeys.push(row.key);
        });
        this.setState({ selectedRowKeys });
    },
	render() {
        var self = this;
        var rows = _.map(this.state.data,function(row){
            row.key = row.user_id;
            return row;
        });
		return (
			<div className="table_demo">
                <Modal title="对话框标题"
                       visible={this.state.visible}
                       onOk={this.handleOk}
                       confirmLoading={this.state.confirmLoading}
                       onCancel={this.handleCancel}>
                    <div>{this.state.ModalText}</div>
                </Modal>
				<Form horizontal className="advanced-search-form">
					<Row>
						<Col span="8">
							<FormItem
								label="搜索名称："
								labelCol={{span: 10}}
								wrapperCol={{span: 14}}>
								<Input placeholder="请输入搜索名称"/>
							</FormItem>
						</Col>
					</Row>
					<Row>
						<Col span="8" offset="16" style={{textAlign: 'right'}}>
							<Button type="primary" htmlType="submit">搜索</Button>
							<Button type="ghost">清除条件</Button>
						</Col>
					</Row>
				</Form>
				<br style={{height:100}}/>
                {rows.length > 0 ? <Table columns={columns}
                                         dataSource={rows}
                                         rowSelection={this.state.rowSelection}
                                         expandedRowRender={expandedRowRender}
                                         pagination={this.state.pagination}
                                         loading={this.state.loading}
                                         onChange={this.handleTableChange}/> : null

                }

			</div>
		);
	}
});

export default User;