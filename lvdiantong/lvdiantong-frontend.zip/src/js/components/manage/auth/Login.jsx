import React,{ PropTypes } from 'react';
import {Form, Input, Button, Checkbox, Radio, Row, Col, message} from 'antd';
const FormItem = Form.Item;

import reqwest from 'reqwest';

const FormView = React.createClass({
	mixins: [Form.ValueMixin],
	contextTypes: {
        router: React.PropTypes.object.isRequired
	},
	handleSubmit(e){
		e.preventDefault();
		if (!this.state.formData.username) {
			return alert("用户名不能为空");
		}
		if (!this.state.formData.password) {
			return alert("密码不能为空");
		}
		//debugger;
		var encryptData = this.state.encryptData;
		if (!encryptData) return alert("encryptData is null");
		//console.log("submit", this.state.formData);
		this.setState({loading: true});
		var encrypt = new JSEncrypt();
		encrypt.setPublicKey(encryptData.public_key);

		var data = {};
		data.username = this.state.formData.username;
		data.password = this.state.formData.password;
		data[encryptData.field_name] = encryptData.field_value;

		data.username = encrypt.encrypt(data.username);
		data.password = encrypt.encrypt(data.password);
		data.action = "login";
		data.controller = "admin/auth";
		data.access_token = get_access_token();
		//console.log(data);
		reqwest({
			url: API_URL,
			method: 'post',
			data: data,
			type: 'json',
			success: (response) => {
				//debugger;
				set_access_token(response);
				alert(response.result);
				if (response.error > 0) {
					this.setState({loading: false});
				} else {
					window.localStorage.safe_logined = true;
					this.context.router.push("/manage");
				}
			}
		});

	},
	encrypt_data() {
		this.setState({loading: true});
		reqwest({
			url: API_URL,
			method: 'get',
			data: {
				controller:"admin/auth",
				action: "encrypt_data",
				access_token: get_access_token()
			},
			type: 'json',
			success: (response) => {
				//debugger;
				set_access_token(response);
				if (this.isMounted()) {
					this.setState({
						loading: false,
						encryptData: response.result.encryptData
					});
				}
			}
		});
	},
	getInitialState() {
		return {
			formData: {
				username: '',
				password: undefined
			},
			loading: false,
			encryptData: null
		};
	},
	componentDidMount(){
		this.encrypt_data();
	},
	render() {
		const formData = this.state.formData;
		return (
			<div className="login">
				<Form horizontal onSubmit={this.handleSubmit} className="login_form">
					<FormItem
						id="username"
						label="用户名："
						labelCol={{span: 6}}
						wrapperCol={{span: 14}}
						required>
						<Input type="text" id="username" name="username" placeholder="请输入用户名" value={formData.username}
							   onChange={this.setValue.bind(this, 'username')}/>
					</FormItem>
					<FormItem
						id="password"
						label="密码："
						labelCol={{span: 6}}
						wrapperCol={{span: 14}}
						required>
						<Input type="password" id="password" name="password" placeholder="请输入密码"
							   value={formData.password} onChange={this.setValue.bind(this, 'password')}/>
					</FormItem>
					<Row>
						<Col span="16" offset="6">
							<Button loading={this.state.loading} type="primary" htmlType="submit">确定</Button>
						</Col>
					</Row>
				</Form>
			</div>
		);
	}
});

export default FormView;
