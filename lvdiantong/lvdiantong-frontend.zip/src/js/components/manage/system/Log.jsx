import React from 'react';
import Tappable from 'react-tappable';

import { Table , Form , Row , Col , Input , Button, Modal, Spin,DatePicker} from 'antd';
const RangePicker = DatePicker.RangePicker;

const FormItem = Form.Item;

import reqwest from 'reqwest';
var _ = require('lodash');

const columns = [
    {
        title: 'ID',
        key:"id",
        dataIndex: 'id',
        sorter: true
    },
	{
		title: 'UID',
        key:"user_id",
		dataIndex: 'user_id'
	},
	{
		title: 'Model',
        key:"model",
		dataIndex: 'model',
		sorter: true
	},
	{
		title: 'IP',
        key:"action_ip",
		dataIndex: 'action_ip'
	},
    {
        title: 'Remark',
        key:"remark",
        dataIndex: 'remark'
    },
	{
		title: '添加时间',
        key:"create_time",
		dataIndex: 'create_time',
        sorter: true
	}
];

export default React.createClass({
	getInitialState() {
		return {
			rows: [],
			pagination: {},
			loading: false,
            search:{
                ip:"",
                method:"",
                user_id:"",
                remark:"",
                start_time:"",
                end_time:"",
            }
		};
	},
    fetch_list(params) {
		this.setState({ loading: true });
        if(params == undefined){
            params = {};
        }
        let pagination = this.state.pagination;
        params.limit = pagination.pageSize;
        params.page = pagination.current;
        params.search = JSON.stringify(this.state.search);
        params.action = "list";
        params.controller = "admin/log";
        params.access_token = get_access_token();
		reqwest({
			url: API_URL,
			method: 'get',
			data: params,
			type: 'json',
			success: (response) => {
				//debugger;
				set_access_token(response);
				if(response.error){
					return alert(response.result)
				}else{
                    let { pagination } = this.state;
                    let {rows,total,limit} = response.result;
                    //console.log(rows,total,limit)
                    pagination.total = total;
                    pagination.pageSize = limit;
                    pagination.showSizeChanger = true;
                    pagination.onShowSizeChange = this.onShowSizeChange;
                    if(this.isMounted()){
                        this.setState({
                            loading: false,
                            rows: rows,
                            pagination
                        });
                    }
                }
			}
		});
	},
    formatDate(date){
        if(date) return date.getFullYear()+"-"+date.getMonth()+"-"+date.getDay();
        else return "";
    },
    onRangePickerChange(value){
        let { search } = this.state;
        search['start_time'] = this.formatDate(value[0]);
        search['end_time'] = this.formatDate(value[1]);
        this.setState({search});
        //console.log(this.state)
    },
    onSearchInputChange(key,e){
        let { search } = this.state;
        search[key] = e.target.value;
        this.setState({search});
    },
    clearSearchCondition(){
        //debugger;
        let { search } = this.state;
        for(let key in search){
            search[key] = "";
        }
        this.refs.RangePickerRef.setState({value:['','']});
        this.setState({search});
        this.fetch_list();
    },
    doSearch(){
        let pagination = this.state.pagination;
        pagination.current = 1;
        this.fetch_list();
    },
    onShowSizeChange: function (current, pageSize) {
        let pagination = this.state.pagination;
        pagination.pageSize = pageSize;
        this.setState({
            pagination,
            loading:true
        });
        this.fetch_list();
    },
    handleTableChange(pagination, filters, sorter) {
        //console.log(pagination)
        let pager = this.state.pagination;
        pager.current = pagination.current;
        const params = {
            sort_field: sorter.field,
            sort_type:  sorter.order
        };
        for (let key in filters) {
            params[key] = filters[key];
        }
        //console.log(params);
        this.fetch_list(params);
    },
    componentDidMount() {
        //console.log("componentDidMount");
        this.fetch_list();
    },
	render() {
		return (
			<div className="table_demo">
				<Form horizontal className="advanced-search-form">

					<Row>
						<Col span="8">
							<FormItem
								label="IP："
								labelCol={{ span: 10 }}
								wrapperCol={{ span: 14 }}>
								<Input placeholder=""
                                       value={this.state.search.ip}
                                       onChange={this.onSearchInputChange.bind(this,"ip")} />
							</FormItem>
						</Col>
						<Col span="8">
							<FormItem
								label="Model："
								labelCol={{ span: 10 }}
								wrapperCol={{ span: 14 }}>
								<Input placeholder=""
                                       value={this.state.search.method}
                                       onChange={this.onSearchInputChange.bind(this,"method")}/>
							</FormItem>
						</Col>
						<Col span="8">
							<FormItem
								label="UID："
								labelCol={{ span: 10 }}
								wrapperCol={{ span: 14 }}>
								<Input placeholder=""
                                       value={this.state.search.user_id}
                                       onChange={this.onSearchInputChange.bind(this,"user_id")}/>
							</FormItem>
						</Col>
					</Row>
                    <Row>
                        <Col span="8">
                            <FormItem
                                label="Remark："
                                labelCol={{ span: 10 }}
                                wrapperCol={{ span: 14 }}>
                                <Input placeholder=""
                                       value={this.state.search.remark}
                                       onChange={this.onSearchInputChange.bind(this,"remark")}/>
                            </FormItem>
                        </Col>
                        <Col span="16">
                            <FormItem
                                label="时间："
                                labelCol={{ span: 5 }}
                                wrapperCol={{ span: 14 }}>
                                <RangePicker style={{ width: 184 }} ref="RangePickerRef"
                                             onChange={this.onRangePickerChange} />
                            </FormItem>
                        </Col>
                    </Row>
					<Row>
						<Col span="8" offset="16" style={{textAlign: 'right'}}>
							<Button type="primary" onClick={this.doSearch} htmlType="button">搜索</Button>
							<Button type="ghost" onClick={this.clearSearchCondition}>重置</Button>
						</Col>
					</Row>
				</Form>
				<br style={{height:100}}/>
                {this.state.rows.length > 0 ?
                    <Table columns={columns}
                           ref="TableRef"
                         dataSource={this.state.rows}
                         pagination={this.state.pagination}
                         loading={this.state.loading}
                         onChange={this.handleTableChange}/>
                    : null
                }
			</div>
		);
	}
});