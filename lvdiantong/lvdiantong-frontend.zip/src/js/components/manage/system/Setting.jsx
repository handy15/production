import React from 'react';
import Sentry from 'react-sentry';
import Tappable from 'react-tappable';

var EventEmitter = require('events').EventEmitter;
var emitter = new EventEmitter();

import { Table , Form , Row , Col , Input , Button, Modal, Spin} from 'antd';
import { Tabs } from 'antd';
const TabPane = Tabs.TabPane;

const FormItem = Form.Item;

import reqwest from 'reqwest';
var _ = require('lodash');

const SettingView = React.createClass({
    mixins: [Sentry],
	getInitialState() {
		return {
            setting:{
                min_month_free:""
            },
            items:[],
		};
	},
	componentDidMount() {
        var data = {};
        data.action = "items";
        data.controller = "admin/setting";
        data.access_token = get_access_token();
        //console.log(data);
        reqwest({
            url: API_URL,
            method: 'post',
            data: data,
            type: 'json',
            success: (response) => {
                //debugger;
                set_access_token(response);
                if (response.error > 0) {
                    alert(response.result);
                } else {
                    let setting = { setting };
                    response.result.map(function(item){
                        setting[item.key] = item.value;
                    });
                    this.setState({
                        items:response.result,
                        setting:setting
                    });
                }
            }
        });
	},
    tabCallback(key){

    },
    handleInputChange(key,e){
        console.log(e.target.value)
        let { setting } = this.state;
        setting[key] = e.target.value;
        this.setState({setting:setting});
    },
    handleBlur(key,e){
        //if (e.target.value == e.target.defaultValue) return;
        var data = {};
        data.key = key;
        data.value = e.target.value;
        data.action = "set";
        data.controller = "admin/setting";
        data.access_token = get_access_token();
        //console.log(data);
        reqwest({
            url: API_URL,
            method: 'post',
            data: data,
            type: 'json',
            success: (response) => {
                //debugger;
                set_access_token(response);
                if (response.error > 0) {
                    alert(response.result);
                } else {

                }
            }
        });
    },
	render() {
        const { getFieldProps } = this.props.form;
		return (
			<div>
                <Tabs onChange={this.tabCallback} type="card">
                    <TabPane tab="设置" key="1">
                        <Form horizontal>
                            {
                                this.state.items.map((item,i)=>{
                                    //console.log(item,i);
                                    return (
                                        <FormItem key={i+"input"}
                                            label={item.key+"："}
                                            labelCol={{ span: 6 }}
                                            wrapperCol={{ span: 14 }}
                                            help={item.title}>
                                            <Input {...this.props}
                                                    value={this.state.setting[item.key]}
                                                   onChange={this.handleInputChange.bind(this,item.key)}
                                                   onBlur={this.handleBlur.bind(this,item.key)}
                                                   placeholder=""
                                            />
                                        </FormItem>
                                    )
                                })
                            }

                        </Form>
                    </TabPane>
                </Tabs>
			</div>
		);
	}
});

const Setting = Form.create()(SettingView);

export default Setting;