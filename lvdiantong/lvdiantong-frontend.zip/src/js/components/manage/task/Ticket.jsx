import React from 'react';
import { Row, Col } from 'antd';
import { Badge , Table } from 'antd';
import { Progress, Button, Icon, Form,Input } from 'antd';
const ProgressCircle = Progress.Circle;
const FormItem = Form.Item;

import reqwest from 'reqwest';

const StatusPanel = React.createClass({
	getInitialState() {
		return {
			percent: 0,
			task:{
				queue_length:0,
				handled_nums:0,
				pop_length:0,
				interval:0
			}
		};
	},
	componentDidMount(){
		var self = this;
		window.get_event_task_info_time_id = setInterval(function () {
			self.get_event_task_info();
		}, 1000);
	},
	componentWillUnmount(){
		clearInterval(window.get_event_task_info_time_id);
	},
	get_event_task_info() {
        reqwest({
			url: API_URL,
			method: 'post',
			data: {
				action: "task_info",
				controller:"admin/event",
				access_token: get_access_token()
			},
			type: 'json',
			success: (response) => {
				//debugger;
				set_access_token(response);
				if(this.isMounted()){
					this.setState({
						task: response.result
					});
					var percent = 100;
					if(response.result.queue_length > 0){
						percent = response.result.handled_nums * 100 / (response.result.queue_length + response.result.handled_nums);
						percent = percent.toFixed(1);
					}

					this.setState({ percent: percent});
				}
			}
		});
	},
	render(){
		return (
			<div>
				<Row>
					<Col span="6">
						<ProgressCircle percent={this.state.percent} />
					</Col>
					<Col span="12">
						<table className="status_pannel_table">
							<tbody>
								<tr>
									<td>队列总数量</td>
									<td>
										<div>{this.state.task.queue_length}</div>
									</td>
								</tr>
								<tr>
									<td>已完成</td>
									<td>
										<div>{this.state.task.handled_nums}</div>
									</td>
								</tr>
								<tr>
									<td>每次从队列抽取数</td>
									<td>
										<div>{this.state.task.pop_length}</div>
									</td>
								</tr>
								<tr>
									<td>循环间隔</td>
									<td>
										<div>{this.state.task.interval}</div>
									</td>
								</tr>
							</tbody>
						</table>
					</Col>
				</Row>
			</div>

		)
	}
});

export default React.createClass({
	mixins: [Form.ValueMixin],
	getInitialState() {
		return {
			formData: {
				interval: 1,
				pop_nums: 1000
			}
		};
	},

	handleSubmit(e) {
		e.preventDefault();

		reqwest({
			url: API_URL,
			method: 'post',
			data: {
				action: "set_task_control",
				controller:"admin/event",
				interval:this.state.formData.interval,
				pop_nums:this.state.formData.pop_nums,
				access_token: get_access_token()
			},
			type: 'json',
			success: (response) => {
				//debugger;
				set_access_token(response)
				if(this.isMounted()){
					console.log(response.result);
				}
			}
		});
	},
	render() {
		const formData = this.state.formData;
		return (
			<div className="">
				<Row>
					<Col span="24">
						<Form inline onSubmit={this.handleSubmit}>
							<FormItem
								id="userName"
								label="循环间隔 (秒)：">
								<Input id="interval" name="interval" onChange={this.setValue.bind(this, 'interval')} value={formData.interval} />
							</FormItem>
							<FormItem
								id="userName"
								label="每次从队列抽取数 (条)：">
								<Input id="pop_nums" name="pop_nums" onChange={this.setValue.bind(this, 'pop_nums')} value={formData.pop_nums} />
							</FormItem>
							<Button type="primary" htmlType="submit">设置</Button>
						</Form>
					</Col>
				</Row>
				<StatusPanel />
			</div>
		);
	}
});
