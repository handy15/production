import React                    from 'react'
import ReactDOM                 from 'react-dom'
import createHashHistory        from 'history/lib/createHashHistory'

import {
    Router,
    useRouterHistory
}                               from 'react-router';

import AppRoutes             from './routes/demo.jsx'
const history = useRouterHistory(createHashHistory)({ queryKey: false })

ReactDOM.render(
    <Router children={AppRoutes} history={history}/>,
    document.getElementById('root')
);