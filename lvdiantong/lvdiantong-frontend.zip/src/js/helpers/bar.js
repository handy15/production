console.log('module `helpers/bar`');
