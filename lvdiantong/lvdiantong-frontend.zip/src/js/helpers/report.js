'use strict';

console.info('require report module.');

function report(id) {
    console.log('report id:%s', id);
    // todo
}

module.exports = report;
