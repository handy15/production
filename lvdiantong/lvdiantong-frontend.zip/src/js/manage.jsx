import React                    from 'react'
import ReactDOM                 from 'react-dom'
import createHashHistory        from 'history/lib/createHashHistory'

import {
    Router,
    useRouterHistory
}                               from 'react-router';

import ManageRoutes             from './routes/manage.jsx'
import './common/manage.jsx';
const history = useRouterHistory(createHashHistory)({ queryKey: false })

ReactDOM.render(
    <Router children={ManageRoutes} history={history}/>,
    document.getElementById('root')
);