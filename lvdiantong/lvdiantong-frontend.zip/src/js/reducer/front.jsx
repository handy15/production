// Reducer
function reducer(state = {count: 0}, action) {
    let count = state.count
    switch (action.type) {
        case 'increase':
            return {count: count + 1}
        case 'submit':
            return {count: count - 1}
        case 'valuechange':
            //debugger;
            return {count: count}
        default:
            return state
    }
}
export default reducer;
