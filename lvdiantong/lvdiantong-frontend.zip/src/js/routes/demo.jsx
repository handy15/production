import React from 'react';
const ReactRouter = require('react-router');
let { Router, Route, } = ReactRouter;

import {App,Home,Page1,Page2} from '../components/demo/App.jsx';

const AppRoutes = (
    <Router >
        <Route path="/" component={App} ignoreScrollBehavior>
            <Route path="page1" component={Page1} />
            <Route path="page2" component={Page2} />
        </Route>
    </Router>
);

module.exports = AppRoutes;