import React from 'react';
import { Router, Route ,Redirect} from 'react-router'
import { IndexRoute } from 'react-router'

import Login from '../components/frontend/auth/Login.jsx';
import Reg from '../components/frontend/auth/Reg.jsx';
import ResetPwd from '../components/frontend/auth/ResetPwd.jsx';
import Auth from '../components/frontend/Auth.jsx';
const FrontRoutes = (
    <Router >
        <IndexRoute component={Auth}/>
        <Redirect from="/" to="/login" />
        <Route path="/" component={Auth}>
            <Route path="reg" component={Reg}/>
            <Route path="login" component={Login}/>
            <Route path="reset_pwd" component={ResetPwd}/>
        </Route>
    </Router>
);

module.exports = FrontRoutes;