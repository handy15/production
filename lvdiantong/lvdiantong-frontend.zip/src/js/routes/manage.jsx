import React from 'react';
import { Router , Route , Redirect } from 'react-router'
import { IndexRoute } from 'react-router'
import Manage from '../components/manage/Manage.jsx'
import Login from '../components/manage/auth/Login.jsx'
import User from '../components/manage/User.jsx'
import SystemSetting from '../components/manage/system/Setting.jsx'
import SystemLog from '../components/manage/system/Log.jsx'
import Ticket from '../components/manage/task/Ticket.jsx'

window.API_URL = "http://local.dian.solarbao.com/service/api.php";

window.get_access_token = function(){
    return window.localStorage.access_token ? window.localStorage.access_token:"";
}
window.set_access_token = function(response){
    if (response.access_token && window.localStorage.access_token != response.access_token) {
        window.localStorage.access_token = response.access_token;
    }
}

const ManageRoutes = (
    <Router ignoreScrollBehavior>
        <IndexRoute component={Manage}/>
        <Route path="/login" component={Login}/>
        <Redirect from="/" to="/manage/user" />
        <Redirect from="/manage" to="/manage/user" />
        <Route path="/manage" component={Manage} >
            <Route path="user" component={User}/>
            <Route path="/task/ticket" component={Ticket}/>
            <Route path="/system/setting" component={SystemSetting}/>
            <Route path="/system/log" component={SystemLog}/>
        </Route>
    </Router>
);

module.exports = ManageRoutes;