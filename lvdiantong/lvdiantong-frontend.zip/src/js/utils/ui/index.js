'use strict';

Object.defineProperty(exports, '__esModule', {
    value: true
});
var React = require('react');
exports.Wechat = require("./wechat");