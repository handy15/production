'use strict';

Object.defineProperty(exports, '__esModule', {
    value: true
});

var React = require('react');

var ActionSheetDemo = React.createClass({
    hideActionSheet: function (weuiActionsheet, mask) {
        weuiActionsheet.removeClass('weui_actionsheet_toggle');
        mask.removeClass('weui_fade_toggle');
        weuiActionsheet.on('transitionend', function () {
            mask.hide();
        }).on('webkitTransitionEnd', function () {
            mask.hide();
        })
    },
    showActionSheet: function (e) {
        var mask = $('#mask');
        var weuiActionsheet = $('#weui_actionsheet');
        weuiActionsheet.addClass('weui_actionsheet_toggle');
        mask.show().addClass('weui_fade_toggle').click(function () {
            this.hideActionSheet(weuiActionsheet, mask);
        });
        $('#actionsheet_cancel').click(function () {
            this.hideActionSheet(weuiActionsheet, mask);
        });
        weuiActionsheet.unbind('transitionend').unbind('webkitTransitionEnd');
    },
    render(){
        return (
            <div className="page" style={{overflow:"hidden"}}>
                <div className="hd">
                    <h1 className="page_title">ActionSheet</h1>
                </div>
                <div className="bd spacing">
                    <button className="weui_btn weui_btn_primary" onClick={this.showActionSheet} id="showActionSheet">
                        点击上拉ActionSheet
                    </button>
                </div>
            </div>
        )
    }
});
exports.Demo = ActionSheetDemo;
