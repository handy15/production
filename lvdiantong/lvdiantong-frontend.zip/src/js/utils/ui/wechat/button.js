'use strict';

Object.defineProperty(exports, '__esModule', {
    value: true
});

var React = require('react');

var ButtonDemo = React.createClass({
    render () {
        return (
            <div className="page">
                <div className="hd">
                    <h1 className="page_title">Button</h1>
                </div>
                <div className="bd spacing">
                    <button className="weui_btn weui_btn_primary">按钮</button>
                    <button className="weui_btn weui_btn_disabled weui_btn_primary">按钮</button>
                    <button className="weui_btn weui_btn_warn">确认</button>
                    <button className="weui_btn weui_btn_disabled weui_btn_warn">确认</button>
                    <button className="weui_btn weui_btn_default">按钮</button>
                    <button className="weui_btn weui_btn_disabled weui_btn_default">按钮</button>
                    <div className="button_sp_area">
                        <button className="weui_btn weui_btn_plain_default">按钮</button>
                        <button className="weui_btn weui_btn_plain_primary">按钮</button>

                        <button className="weui_btn weui_btn_mini weui_btn_primary">按钮</button>
                        <button className="weui_btn weui_btn_mini weui_btn_default">按钮</button>
                    </div>
                </div>
            </div>
        );
    }
});
exports.Demo = ButtonDemo;