'use strict';

Object.defineProperty(exports, '__esModule', {
    value: true
});

var React = require('react');

var DialogDemo = React.createClass({

    showDialog1: function (e) {
        $("#dialog_confirm").show();
    },
    showDialog2: function (e) {
        $("#dialog_alert").show();
    },
    render () {
        return (
            <div className="page">
                <div className="hd">
                    <h1 className="page_title">Dialog</h1>
                </div>
                <div className="bd spacing">
                    <button onClick={this.showDialog1} className="weui_btn weui_btn_primary" id="showDialog1">
                        点击弹出Dialog样式一
                    </button>
                    <button onClick={this.showDialog2} className="weui_btn weui_btn_primary" id="showDialog2">
                        点击弹出Dialog样式二
                    </button>
                </div>
            </div>
        );
    }
});
const Confirm = React.createClass({
    render(){
        return (
            <div className="weui_dialog_confirm" id="dialog_confirm" style={{display:"block"}}>
                <div className="weui_mask"></div>
                <div className="weui_dialog">
                    <div className="weui_dialog_hd"><strong className="weui_dialog_title" /></div>
                    <div className="weui_dialog_bd"><br />...</div>
                    <div className="weui_dialog_ft">
                        <a className="weui_btn_dialog default" onclick="$('#dialog_confirm').hide()">取消</a>
                        <a className="weui_btn_dialog primary" onclick="$('#dialog_confirm').hide()">确定</a>
                    </div>
                </div>
            </div>
        )
    }

});
const Alert = React.createClass({
    getInitialState() {
        return {
            show:false
        };
    },
    sure(){
        this.setState({
            show:false
        });  
        if(this.props.parent){
            this.props.parent.setState({
                alert_show:false
            });
        }
        
        if(this.state.alert_func) this.state.alert_func();
    },
    componentWillReceiveProps(nextProps){
        this.setState({
            show:nextProps.show,
            msg:nextProps.msg,
            alert_func:nextProps.alert_func
        });
    },
    render(){
        const display = this.state.show ? "block" : "None";
        return (
            <div className="weui_dialog_alert" id="dialog_alert" style={{display:display}}>
                <div className="weui_mask" onClick={this.sure}></div>
                <div className="weui_dialog">
                    <div className="weui_dialog_hd"><strong className="weui_dialog_title" />提示</div>
                    <div className="weui_dialog_bd">{this.state.msg}</div>
                    <div className="weui_dialog_ft">
                        <a className="weui_btn_dialog primary" onClick={this.sure}>确定</a>
                    </div>
                </div>
            </div>
        )
    }
});
exports.Demo = DialogDemo;
exports.Alert = Alert;
exports.Confirm = Confirm;