'use strict';

Object.defineProperty(exports, '__esModule', {
    value: true
});
var fs = require('fs');
var React = require('react');

var IconDemo = React.createClass({
    render(){
        var data = fs.readFileSync('/Users/joseph/Desktop/data/sites/ptphp.com/ptphp_www/src/css/ionicons/_ionicons-variables.less');

        var icons_content = data.toString();
        var t = icons_content.split("\n");
        var icons = [];
        for (var i in t) {
            var line = t[i];
            if (!line) continue;
            var tmp = line.split(": \"\\");
            if (tmp.length > 1 && tmp[0].substr(0, 4) == "@ion") {
                var v = tmp[0].substr(4);
                var con = tmp[1].replace("\";", "");
                //console.log(con);
                icons.push({name: v, content: con});
            }
        }
        return (
            <div className="page">
                <div className="icon_rows">
                    {icons.map((icon, i)=> {
                        return (
                            <div className="cell">
                                <i className={"pt_ico_"+icon.name}></i>

                                <div>{icon.content}</div>
                            </div>
                        )
                    })}
                </div>
                <div className="hd">
                    <h1 className="page_title">Icons</h1>
                </div>
                <div className="bd spacing">
                    <i className="weui_icon_msg weui_icon_success"></i>
                    <i className="weui_icon_msg weui_icon_info"></i>
                    <i className="weui_icon_msg weui_icon_warn"></i>
                    <i className="weui_icon_msg weui_icon_waiting"></i>
                    <i className="weui_icon_safe weui_icon_safe_success"></i>
                    <i className="weui_icon_safe weui_icon_safe_warn"></i>

                    <div className="icon_sp_area">
                        <i className="weui_icon_success"></i>
                        <i className="weui_icon_success_circle"></i>
                        <i className="weui_icon_success_no_circle"></i>
                        <i className="weui_icon_info"></i>
                        <i className="weui_icon_waiting"></i>
                        <i className="weui_icon_waiting_circle"></i>
                        <i className="weui_icon_circle"></i>
                        <i className="weui_icon_warn"></i>
                        <i className="weui_icon_download"></i>
                        <i className="weui_icon_info_circle"></i>
                        <i className="weui_icon_cancel"></i>
                    </div>

                </div>
            </div>
        );
    }
});
exports.Demo = IconDemo;