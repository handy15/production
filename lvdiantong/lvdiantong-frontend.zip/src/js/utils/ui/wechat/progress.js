'use strict';

Object.defineProperty(exports, '__esModule', {
    value: true
});

var React = require('react');

var ProgressDemo = React.createClass({
    render () {
        return (
            <div className="page">
                <div className="hd">
                    <h1 className="page_title">Progress</h1>
                </div>
                <div className="bd spacing">
                    <div className="weui_progress">
                        <div className="weui_progress_bar">
                            <div className="weui_progress_inner_bar" style={{width:"0%"}}></div>
                        </div>
                        <a className="weui_progress_opr">
                            <i className="weui_icon_cancel"></i>
                        </a>
                    </div>

                    <div className="weui_progress">
                        <div className="weui_progress_bar">
                            <div className="weui_progress_inner_bar" style={{width:"50%"}}></div>
                        </div>
                        <a className="weui_progress_opr">
                            <i className="weui_icon_cancel"></i>
                        </a>
                    </div>
                    <br />

                    <div className="weui_progress">
                        <div className="weui_progress_bar">
                            <div className="weui_progress_inner_bar" style={{width:"50%"}}></div>
                        </div>
                        <a className="weui_progress_opr">
                            <i className="weui_icon_cancel"></i>
                        </a>
                    </div>
                </div>
            </div>
        );
    }
});
exports.Demo = ProgressDemo;