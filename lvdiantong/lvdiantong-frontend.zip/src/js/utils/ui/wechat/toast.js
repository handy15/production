'use strict';

Object.defineProperty(exports, '__esModule', {
    value: true
});

var React = require('react');

var ToastDemo = React.createClass({

    showToast: function (e) {
        //debugger;
        console.log("showToast", e.target)
        $("#toast").show();
        setTimeout(function () {
            //console.log(2);
            $("#toast").hide();
        }, 2000);
    },
    showLoadingToast: function (e) {
        $("#loadingToast").show();
        setTimeout(function () {
            //console.log(2);
            $("#loadingToast").hide();
        }, 2000);
    },
    render () {
        return (
            <div className="page">
                <div className="hd">
                    <h1 className="page_title">Toast</h1>
                </div>
                <div className="bd spacing">
                    <button onClick={this.showToast} className="weui_btn weui_btn_primary" id="showToast">点击弹出Toast
                    </button>
                    <button onClick={this.showLoadingToast} className="weui_btn weui_btn_primary" id="showLoadingToast">
                        点击弹出Loading Toast
                    </button>
                </div>
                <div id="toast" style={{display:"none"}}>
                    <div className="weui_mask_transparent"></div>
                    <div className="weui_toast">
                        <i className="weui_icon_toast"></i>

                        <p className="weui_toast_content">已完成</p>
                    </div>
                </div>

                <div id="loadingToast" className="weui_loading_toast" style={{display:"none"}}>
                    <div className="weui_mask_transparent"></div>
                    <div className="weui_toast">
                        <div className="weui_loading">
                            <div className="weui_loading_leaf weui_loading_leaf_0"></div>
                            <div className="weui_loading_leaf weui_loading_leaf_1"></div>
                            <div className="weui_loading_leaf weui_loading_leaf_2"></div>
                            <div className="weui_loading_leaf weui_loading_leaf_3"></div>
                            <div className="weui_loading_leaf weui_loading_leaf_4"></div>
                            <div className="weui_loading_leaf weui_loading_leaf_5"></div>
                            <div className="weui_loading_leaf weui_loading_leaf_6"></div>
                            <div className="weui_loading_leaf weui_loading_leaf_7"></div>
                            <div className="weui_loading_leaf weui_loading_leaf_8"></div>
                            <div className="weui_loading_leaf weui_loading_leaf_9"></div>
                            <div className="weui_loading_leaf weui_loading_leaf_10"></div>
                            <div className="weui_loading_leaf weui_loading_leaf_11"></div>
                        </div>
                        <p className="weui_toast_content">数据加载中</p>
                    </div>
                </div>
            </div>
        );
    }
});

const Toast = React.createClass({
    getInitialState(){
        const show = this.props.show ? true : false;
        return{
            show:show
        }
    },
    componentWillReceiveProps(nextProps){
        console.log("componentWillReceiveProps");
        this.setState({
            show:nextProps.show
        });
        var self = this;
        setTimeout(function(){
            self.setState({
                show:false
            });
        },1500);
    },
    render(){
        const display = this.state.show ? "block":"none";
        const msg     = this.props.msg  ? this.props.msg : "已完成";
        console.log("render",display);
        return (
            <div id="toast" style={{display:display}}>
                <div className="weui_mask_transparent"></div>
                <div className="weui_toast">
                    <i className="weui_icon_toast" />
                    <p className="weui_toast_content">{msg}</p>
                </div>
            </div>
        );
    }
});
const ToastLoading = React.createClass({
    render(){
        const display = this.props.show ? "block":"none";
        const msg     = this.props.msg  ? this.props.msg : "数据加载中";
        return (
            <div id="loadingToast" className="weui_loading_toast" style={{display:display}}>
                <div className="weui_mask_transparent"></div>
                <div className="weui_toast">
                    <div className="weui_loading">
                        <div className="weui_loading_leaf weui_loading_leaf_0"></div>
                        <div className="weui_loading_leaf weui_loading_leaf_1"></div>
                        <div className="weui_loading_leaf weui_loading_leaf_2"></div>
                        <div className="weui_loading_leaf weui_loading_leaf_3"></div>
                        <div className="weui_loading_leaf weui_loading_leaf_4"></div>
                        <div className="weui_loading_leaf weui_loading_leaf_5"></div>
                        <div className="weui_loading_leaf weui_loading_leaf_6"></div>
                        <div className="weui_loading_leaf weui_loading_leaf_7"></div>
                        <div className="weui_loading_leaf weui_loading_leaf_8"></div>
                        <div className="weui_loading_leaf weui_loading_leaf_9"></div>
                        <div className="weui_loading_leaf weui_loading_leaf_10"></div>
                        <div className="weui_loading_leaf weui_loading_leaf_11"></div>
                    </div>
                    <p className="weui_toast_content">{msg}</p>
                </div>
            </div>
        );
    }
});

exports.Demo = ToastDemo;
exports.Toast = Toast;
exports.ToastLoading = ToastLoading;