'use strict';
var genConf = require('./make-webpack.config');
module.exports = genConf({debug: false});