/**
 * add by CUIGC
 * add time: 2016-03-22
 * desc: 此文件必须放到jquery的引入后面
 */
$(function() {
	var solarplatCntH = initParams.clientHeight - $(".solarplat-common-head").height() - $(".solarplat-top-menu").height()-6;
	//兼容背景图不重叠
	if(solarplatCntH < 680){
		solarplatCntH = 680;
	}
	$(".solarplat-content").css("min-height", solarplatCntH+"px");
	
	// ------------------------顶部的菜单点击事件------------------------
	$("body").on("click", ".solarplat-top-menu .top-menu-item", function() {
		$(this).siblings().removeClass("selected");
		$(this).addClass("selected");
	});

	// ------------------------密码修改显示隐藏------------------------
	$('.common-username').hover(function(){
		var $this = $(this);
		$this.find('.modify-pwd').show(500);
	},function(){
		var $this = $(this);
		$this.find('.modify-pwd').hide(500);
	});
	
	// ------------------------左侧的菜单点击事件------------------------
	// 顶层父级菜单的点击事件
	$("body").on("click", ".left-menu .parent-item>li", function() {
		var $lis = $(this).siblings();
		$lis.removeClass("selected");
		$.each( $lis, function(i, li) {
			$(li).find("ul.child-item").addClass("uhide");
			$(li).find("ul.child-item>li").removeClass("selected");
			var $imgIcon = $(li).find("img");
			if( $imgIcon ) {
				var src = $imgIcon.attr("src");
				if( src.lastIndexOf("-selected")>-1 ) {
    				var noSelectedSrc = src.substr(0, src.lastIndexOf("-selected")) + ".png";
    				$imgIcon.attr("src", noSelectedSrc);
				}
			}
		});
		
		$(this).addClass("selected");
		var $imgIcon = $(this).find("img");
		if( $imgIcon ) {
			var src = $imgIcon.attr("src");
			if( src.lastIndexOf("-selected")==-1 ) {
				var selectedSrc = src.substr(0, src.lastIndexOf(".")) + "-selected.png";
				$imgIcon.attr("src", selectedSrc);
			}
		}
		var $child = $(this).find("ul.child-item");
		if( $child ) {
			$child.removeClass("uhide");
		}
	});
	// 子菜单的点击事件
	$("body").on("click", ".left-menu .parent-item .child-item>li", function() {
		var $lis = $(this).siblings();
		$lis.removeClass("selected");
		$.each( $lis, function(i, li) {
			$(li).find("ul.child-item").addClass("uhide");
		});
		
		$(this).addClass("selected");
		var $child = $(this).find("ul.child-item");
		if( $child ) {
			$child.removeClass("uhide");
		}
	});
	
	// ------------------------查询条件tab点击事件------------------------
	$("body").on("click", ".search-condition .lsearch>span", function() {
		$(this).siblings().removeClass("selected");
		$(this).addClass("selected");
	});
	
});
var utility = utility || {};
$.extend(utility,{
	tools: {
		//判断对象类型
		typeOf: function (obj) {
			return Object.prototype.toString.call(obj).match(/\s(\w+)/)[1].toLowerCase();
		}
	},
	/**
	 * 倒计时
	 * @param time  number 倒计时的秒数
	 * @param repeat boolean  倒计时后重复执行
	 * @param callback function  倒计时完成后的回调函数
     */
	backTime: function(time,repeat,callback){
		var that = this;
		var thisTime = 'number' == that.tools.typeOf(time) ? time : 0;
		var thisRepeat = repeat || false;

		(function(){
			var arg = arguments;
			var minutes = Math.floor(thisTime/60);
			var seconds = thisTime - 60*minutes;
			//设置分
			$('#min1').text(Math.floor(minutes/10));
			$('#min2').text(minutes%10);
			//设置秒
			$('#sec1').text(Math.floor(seconds/10));
			$('#sec2').text(seconds%10);
			if(thisTime>0){
				setTimeout(function(){
					thisTime -= 1;
					arg.callee();
				},1000);
			}else{
				if('function' == that.tools.typeOf(callback)){
					callback();
				}
				if(repeat){
					that.backTime(time,thisRepeat,callback);
				}
			}
		})();
	}
});