$(function () {
    $('#next-btn-submit').on('submit', function (e) {
        alert('fdasf');
        return false;
    });
});