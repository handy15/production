/**
 * Created by jianlongli on 3/15/16.
 */
var _t;
/**
 * 获取当前页面的参数
 * @param String name 请求中参数的key值
 */
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}
/**
 * 设置url中某个参数的值
 * @param String url 请求的地址
 * @param String ref 请求中参数的key值
 * @param String value 请求中参数key对应的value值
 */
function setQueryUrlStr(url, ref, value) {
    var str = "";
    if (url.indexOf('?') != -1) {
    	str = url.substr(url.indexOf('?') + 1);
    } else {
    	return url + "?" + ref + "=" + value;
    }
    var returnurl = "";
    var setparam = "";
    var arr;
    var modify = "0";

    if (str.indexOf('&') != -1) {
        arr = str.split('&');

        for (i in arr) {
            if (arr[i].split('=')[0] == ref) {
                setparam = value;
                modify = "1";
            } else {
                setparam = arr[i].split('=')[1];
            }
            returnurl = returnurl + arr[i].split('=')[0] + "=" + setparam + "&";
        }

        returnurl = returnurl.substr(0, returnurl.length - 1);

        if (modify == "0") {
            if (returnurl == str) {
                returnurl = returnurl + "&" + ref + "=" + value;
            }
        }
    } else {
        if (str.indexOf('=') != -1) {
            arr = str.split('=');
            if (arr[0] == ref) {
                setparam = value;
                modify = "1";
            } else {
                setparam = arr[1];
            }
            returnurl = arr[0] + "=" + setparam;
            if (modify == "0") {
                if (returnurl == str) {
                    returnurl = returnurl + "&" + ref + "=" + value;
                }
            }
        } else {
        	returnurl = ref + "=" + value;
        }
    }
    return url.substr(0, url.indexOf('?')) + "?" + returnurl;
}
/**
 * 删除地址栏中的参数键值对
 * @param String url 请求的地址
 * @param String ref 请求中多个参数的key数组
 */
function removeQueryStr(url, refArr) {
	if( !refArr ) return;
	
	var refs = refArr.join(",");
	refs = ","+refs+",";
	
    var str = "";
    if (url.indexOf('?') != -1) {
        str = url.substr(url.indexOf('?') + 1);
    } else {
        return url;
    }
    var arr = "";
    var returnurl = "";
    var setparam = "";
    if (str.indexOf('&') != -1) {
        arr = str.split('&');
        for (i in arr) {
        	var ref = arr[i].split('=')[0];
        	if( refs.indexOf(","+ref+",")==-1 ) {
            //if (arr[i].split('=')[0] != ref) {
                returnurl = returnurl + arr[i].split('=')[0] + "=" + arr[i].split('=')[1] + "&";
            }
        }
        return url.substr(0, url.indexOf('?')) + "?" + returnurl.substr(0, returnurl.length - 1);
    } else {
        arr = str.split('=');
        //if (arr[0] == ref) {
        if( refs.indexOf(","+arr[0]+",")!=-1 ) {
            return url.substr(0, url.indexOf('?'));
        } else {
            return url;
        }
    }
}
// 通用配置
var config = {
	"serverUrl": "http://api.app.solarbao.com:21888", // 21888端口历史接口的正式环境
    "apiServerUrl": "http://api.app.solarbao.com", //api后台接口的正式环境
    "appServerUrl": "http://we.app.solarbao.com", // h5页面的正式环境
    "mpServerUrl": "http://mp.app.solarbao.com", //微信、IM聊天、二维码接口的正式环境
    "mpWxId": "gh_fe122e410ab5",  // 微信标识。正式环境
    "rongYunKey": "x4vkb1qpvotrk",  // 融云连接key。正式环境
	"xwServerUrl": "http://mp.app.solarbao.com", // 新维需求：后台接口的正式环境

    //"serverUrl": "http://101.200.144.60:21888", // 21888端口历史接口的测试环境
    //"apiServerUrl": "http://101.200.144.60:81", //api后台接口测试环境
    //"appServerUrl": "http://test.we.app.solarbao.com", // h5页面的测试环境
    //"mpServerUrl": "http://101.200.144.60:80", //微信、IM聊天、二维码接口的测试环境
    //"mpWxId": "gh_b33d2efd8322",  // 微信标识。测试环境
    //"rongYunKey": "x18ywvqf80ehc",  // 融云连接key。测试环境
    //"xwServerUrl": "http://101.200.144.60:80", // 新维需求：后台接口的测试环境

    //"apiServerUrl": "http://101.200.78.100:81",  // api后台接口的开发环境
    //"mpServerUrl": "http://mp.lebaojjr.com", // 微信、IM聊天、二维码接口的开发环境
    //"mpWxId": "gh_b33d2efd8322",  // 微信标识。测试环境
	//"appServerUrl": "http://dev.we.app.solarbao.com", // h5页面的开发环境
    //"xwServerUrl": "http://182.254.130.89:81", // 新维需求：后台接口的开发环境
    
    "imgServerUrl": "http://img2.solarbao.com", // 图片服务器
    
    "interfaceVersion": "0.0.0", // 后台接口版本的控制，每个请求都必须要有这个参数：version=config.interfaceVersion
    
    "place": false  // 防止上面配置时，缺少','分隔，此为占位配置，无具体使用含义
};
//HTML页面：初始化参数
var initParams = {
    // 手机分辨率：宽度
    "phoneWidth": window.screen.width,
    // 手机分辨率：高度
    "phoneHeight": window.screen.height,
    // 浏览器窗口的宽度
    "clientWidth": document.documentElement.clientWidth,
    // 浏览器窗口的高度
    "clientHeight": document.documentElement.clientHeight,
    // 手机操作系统
    "phoneAllSys": ["android", "ios"],
    // 当前手机操作系统
    "currentPhoneSys": "" 
};
//判断手机类型
var browser = {
    versions: function() {
        var u = navigator.userAgent, app = navigator.appVersion;
        return {//移动终端浏览器版本信息 
            trident: u.indexOf('Trident') > -1, //IE内核
            presto: u.indexOf('Presto') > -1, //opera内核
            webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
            gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
            mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/), //是否为移动终端
            ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
            android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或者uc浏览器
            iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, //是否为iPhone或者QQHD浏览器
            iPad: u.indexOf('iPad') > -1, //是否iPad
            webApp: u.indexOf('Safari') == -1 //是否web应该程序，没有头部与底部
        };
    }(),
}
function judgePhoneSysType() {
    if (browser.versions.ios || browser.versions.iPhone || browser.versions.iPad) {
        return "ios";
    }
    else if (browser.versions.android) {
        return "android";
    } else {
        return "";
    }
// document.writeln(" 是否为移动终端: " + browser.versions.mobile);
// document.writeln(" ios终端: " + browser.versions.ios);
// document.writeln(" android终端: " + browser.versions.android);
// document.writeln(" 是否为iPhone: " + browser.versions.iPhone);
// document.writeln(" 是否iPad: " + browser.versions.iPad);
// document.writeln(navigator.userAgent);
}
// 初始化定义手机类型
initParams.currentPhoneSys = judgePhoneSysType();

/**
 * GET请求+JSONP格式的异步AJAX请求
 * @param {Object} reqrUrl 请求的url，注此参数不能为空！！！
 * @param {Object} params 请求的参数，格式为key1=val1&key2=val2或{key1: val1, key2: val2}
 * @param {Object} successCallback 请求成功回调函数，参数为请求返回的参数function(data)
 * @param {Object} errorCallback 请求出错回调函数，参数为function(a, b, c)
 * @param {Object} timeoutCallback 请求出错回调函数，参数为function(jqAjaxReqr, status)。jqAjaxReqr请求的标识；status请求的状态：timeout、success、error
 * 例：
 * jqueryAjaxGetJsonp(
 * 		"http://www.baidu.com", //不能为空
 * 		"key=value", //可空，或不传此参
 * 		function(data) {alert("success");}, //可空，或不传此参
 * 		function(a,b,c) {alert("error");}, //可空，或不传此参
 * 		function(jqAjaxReqr, status) {jqAjaxReqr.abort();} //可空，或不传此参
 *  );
 */
function jqueryAjaxGetJsonp(reqrUrl, params, successCallback, errorCallback, timeoutCallback) {
	if(!params) params="";
	if( reqrUrl.indexOf("jsonp")==-1&&params.indexOf("jsonp")==-1) {params += "&jsonp=1";}
	var jqAjaxReqr = $.ajax({
		// timeout : 5000, //超时时间设置，单位毫秒
		type: "GET",
		url: reqrUrl,
		data: params,
		dataType: "jsonp",
		success: function(data) {
			if( successCallback && typeof successCallback=="function" ) {
				successCallback(data, jqAjaxReqr);
			}
		},
		complete: function(XMLHttpRequest, status) {
			if( timeoutCallback && typeof timeoutCallback=="function" ) {
				timeoutCallback(jqAjaxReqr, status);
			} else {
				if(status=='timeout'){//超时,status还有success,error等值的情况
					jqAjaxReqr.abort();
					// alert("请求访问超时");
				}
			}
		},
		error: function(a, b, c) {
			if( errorCallback && typeof errorCallback=="function" ) {
				errorCallback(a, b, c);
			}
		}
	});
}

jQuery.common = {
    /**
     * 锁按钮
     */
    _lockButton : function ( _buttonId, _msg ) {
        _buttonId = _buttonId ? _buttonId.trim() : '';
        if (_buttonId) {
            $('#' + _buttonId).attr('data-lock','1');
            _msg = _msg ? _msg.trim() : '';
            if (_msg) {
                $('#' + _buttonId).html(_msg);
            }
        }
        return true;
    },

    /**
     * 解锁按钮
     */
    _unlockButton : function( _buttonId, _msg){
        _buttonId = _buttonId ? _buttonId.trim() : '';
        if (_buttonId) {
            $('#' + _buttonId).removeAttr('data-lock');
            _msg = _msg ? _msg.trim() : '';
            if (_msg) {
                $('#' + _buttonId).html(_msg);
            }
        }
        return true;
    },

    /**
     * 提示
     */
    _warnning : function( _Id, _msg){
        _Id = _Id ? _Id.trim() : '';
        _msg = _msg ? _msg.trim() : '';
        if (_Id && _msg) {
            clearTimeout (_t);
            $('#' + _Id).html(_msg).addClass('alert alert-warning');
            _t = setTimeout (function(){
                $('#' + _Id).html('').removeClass('alert alert-warning');
            }, 3000);
        }
    },

    /**
     * 获取验证码
     */
    _getVerifycode : function ( _imgId ) {
        _imgId = _imgId ? _imgId.trim() : '';
        if (_imgId) {
            $('#' + _imgId).attr('src', '/assets/images/big_load.gif');
            var _img = new Image();
            _img.src = '/platform/User/Getcode?code=code&tm=' + Math.random();
            _img.onload = function(){
                $('#' + _imgId).attr('src', _img.src);
            };
        }
    },

    /**
     * 检测验证码是否正确
     */
    _checkVerifyCode : function ( _key, _val) {
        var _flagCode = false;
        _key = _key ? _key.trim() : '';
        _val = _val ? _val.trim() : '';
        if (_key && _val) {
            $.ajax({
                url:'/platform/User/CheckVerifyCode/',
                data:'key=' + _key + '&val=' + _val,
                type:'post',
                async:false,
                success:function(data){
                    if(data == 'ok')
                        _flagCode = true;
                },
            });
        }
        return _flagCode;
    }
    
};
