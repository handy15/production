/*
 * 和原生框架交互的方法、事件
 * 注：
 * 1. 此文件需要放在js/common.js和js/WebViewJavascriptBridge.js后面；“当前页面”使用的js文件前面
 *    例：js/common.js、outside_func.js
 */

/**
 * 此方法已经被忽略，以后不再使用。为了兼容历史功能，所以暂时保留！！！
 * 2016-04-06
 */
function setAppTitle( title, rightIcon ) {
	if( !rightIcon ) {
		rightIcon = "";
	}
	if( initParams.phoneAllSys[0]==initParams.currentPhoneSys ) {
		JavaScriptInterface.setAppTitle( title, rightIcon );
    } else if( initParams.phoneAllSys[1]==initParams.currentPhoneSys ) {
    	var iosFilterParams = "{'event':'setAppTitle', 'title': '"+title+"', 'rightIcon': '"+rightIcon+"'}";
    	iosFilter(iosFilterParams);
    } else {
    	//location.href = config.appServerUrl+"activity/activity_detail.html?id="+id+"&userId="+userid;
    }
}

/**
 * author: CUIGUOCHAO
 * add time: 2016-03-02
 * 
 * APP头部右上角显示一个图标的方法。以/js/outside_func.js文件保持一致！！！
 * 目前icon图标出现如下几种：
 * share：分享功能
 * qrCode：跳转到APP的用户二维码页面
 * cityname：地区选择功能。参数格式：cityname#全国#地区选择的url(http://we.solarbao.com/maker/tools/regionSelect.html?paramKey=paramValue)
 * collect：收藏功能。参数格式：collect#收藏状态(1收藏；0未收藏)#页面数据ID#页面数据类型(n新品中心 c活期理财 p光伏政策 l光照资源参数)
 * jumpurl: 跳转到指定页面。参数格式：jumpurl#iconUrl#跳转页面的url地址(http://we.solarbao.com/index.html?paramKey=paramValue)
 * 
 * @param title APP头部显示的标题
 * @param rightIcon APP头部右侧图标中左侧的icon
 * @param leftGoback APP头部左侧图标中左侧的icon点击响应事件
 * 		closeWebview 关闭H5的webview
 */
function setAppTitleAndDetail( title, rightIcon, leftGoback ) {
	rightIcon = rightIcon?rightIcon:"";
	leftGoback = leftGoback?leftGoback:"";
	
	if( initParams.phoneAllSys[0]==initParams.currentPhoneSys ) {
		JavaScriptInterface.setAppTitleAndDetail( title, rightIcon );
    } else if( initParams.phoneAllSys[1]==initParams.currentPhoneSys ) {
    	var iosFilterParams = "{'event':'setAppTitleAndDetail', 'title': '"+title+"', 'rightIcon': '"+rightIcon+"', 'leftGoback':'"+leftGoback+"'";
    	if( "share"==rightIcon ) {
    		// 标题
    	    var shareTitle = shareInfo.title;
    	    // 分享内容
    	    var content = shareInfo.content;
    	    // 图片地址
    	    var photo = shareInfo.photo;
    	    // 分享内容页面地址
    	    var siteUrl = shareInfo.siteUrl;
    		iosFilterParams += ",'shareTitle':'"+shareTitle+"','content':'"+content+"','photo':'"+photo+"','siteUrl':'"+siteUrl+"'";
    	}
    	iosFilterParams += "}";
    	iosFilter(iosFilterParams);
    } else {
    	//location.href = config.appServerUrl+"activity/activity_detail.html?id="+id+"&userId="+userid;
    }
}

//服务加载内容页：分享时的参数功能
function shareService() {
    // 标题
    var title = shareInfo.title;
    // 分享内容
    var content = shareInfo.content;
    // 图片地址
    var photo = shareInfo.photo;
    // 分享内容页面地址
    var siteUrl = shareInfo.siteUrl;
    //alert(title+"\n"+content+"\n"+photo+"\n"+siteUrl);
    // 调新闻详情的分享
    if( initParams.phoneAllSys[0]==initParams.currentPhoneSys ) {
    	JavaScriptInterface.shareService(title, content, photo, siteUrl);
    } else if( initParams.phoneAllSys[1]==initParams.currentPhoneSys ) {
    	var iosFilterParams = "{'event':'shareService','title':'"+title+"','content':'"+content+"','photo':'"+photo+"','siteUrl':'"+siteUrl+"'}";
    	iosFilter(iosFilterParams);
    } else {
    	// 非手机集成，暂无新闻分享功能
    }
}

/**
 * 关闭APP里面的webview容器
 */
function closeH5() {
    if( initParams.phoneAllSys[0]==initParams.currentPhoneSys ) {
    	JavaScriptInterface.closeH5();
    } else if( initParams.phoneAllSys[1]==initParams.currentPhoneSys ) {
    	var iosFilterParams = "{'event':'closeH5'}";
    	iosFilter(iosFilterParams);
    } else {
    	window.location.close();
    }
}

/**
* oper 左上角返回图标的操作事件
* closeWebview 关闭H5的webview
*/
function leftGoback( oper ) {
	if( initParams.phoneAllSys[0]==initParams.currentPhoneSys ) {
    	JavaScriptInterface.leftGoback(oper);
    } else if( initParams.phoneAllSys[1]==initParams.currentPhoneSys ) {
    	var iosFilterParams = "{'event':'leftGoback', 'oper':'"+oper+"'}";
    	iosFilter(iosFilterParams);
    } else {
    	window.location.close();
    }
}

// 提供IOS系统拦截url使用
function iosFilter(iosFilterParamsStr) {
	location.href = config.appServerUrl+"/"+iosFilterParamsStr;
}