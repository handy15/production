if( fr=="spick" ) {
	$("body").append("<script type='text/javascript' src='../../static/js/WebViewJavascriptBridge.js'></script>");
	$("body").append("<script type='text/javascript' src='../../static/js/jsBridgeApp.js'></script>");
	var titleObj = {
		"title": document.title, 
		"leftIcon":"goBack", 
		"rightIcon":[]
	};
	callSetAppTitle( titleObj );
}
//头部左上角的返回图标
function goLastPage() {
	location.href = "my-station.html?userId="+userId+"&fr="+fr+"&status="+statusType;
}
//查看数据详情页
function gotoDetail() {
	location.href = "detail.html?userId="+userId+"&id="+id+"&fr="+fr+"&status="+statusType+"&lastPage=process";
}

// 弹框对象，页面元素加载完成后，进行赋值！
var $popup;
// 关闭当前的弹框
function closePopup( obj ) {
	$("body").removeClass("body100per");
	$(obj).closest(".cd-popup").removeClass("is-visible");
}
// 打开弹框，展示内容
function openDetailDesc( obj ) {
	if( !$popup ) {
    	$popup = $(".cd-popup");
	}
	$popup.find(".cd-buttons").addClass("uhide");
	if( $(obj).closest("li").hasClass("current-step") ) {
		$("#twoBtns").removeClass("uhide");
	} else {
		$("#oneBtn").removeClass("uhide");
	}
	var desc = $(obj).find("input[type='hidden']").val();
	if( !desc ) {
		desc = "暂无内容描述！";
	}
	var $container = $popup.find(".cd-popup-container");
	if( $container.width()>345 ) {
		$container.width(350);
	}
	var $ctnDetail = $popup.find("#contentDetail");
	var $ctn = $ctnDetail.find("span");
	$ctn.html( desc );
	$popup.addClass("is-visible");
	if( $ctnDetail.height()<95 ) {
		$ctnDetail.height(100);
	}
	var $controlCtn = $ctnDetail.find(".control-ctn");
	if( $controlCtn.height()>150) { // max-height样式无效，所以js处理
		$controlCtn.height(155);
		$("body").addClass("body100per");
	} else {
		$("body").removeClass("body100per");
	}
	
}

// 与后台接口说明一致！
var dataConfig = {
	stepsImg: { "3": "../../static/images/station/process-reject.png", "5": "../../static/images/station/process-stop.png" }
}
// 异步加载页面详细数据
function loadPageData() {
	var url = config.gfServerUrl+"/proinfo/schedule";
	var paramsStr = "id="+id;
	paramsStr += "&"+getCheckParams( userId, "paramsStr" );
	jqueryAjaxGetJsonp(url, paramsStr, function(result) {
		if( result.code==2000 ) {
			var datas = result.data;
			
			$("#time").html( "提交时间 : "+datas["create_time"] );
			var status = datas["status"];
			var statusIcon = getStationTextWithValue( status, "statusIcon");
			var statusText = getStationTextWithValue( status, "status");
			var statusTextStyle = getStationTextWithValue( status, "statusTextStyle");
			var statusBlockStr = '<img src="'+statusIcon+'" /><em>状态 : </em><span class="'+statusTextStyle+'">'+statusText+'</span>';
			$("#statusBlock").html( statusBlockStr );
			
			$("#number").html( datas["project_number"] );
			$("#name").html( datas["project_name"] );
			
			var provinceName = datas["project_province_name"];
			var cityName = datas["project_city_name"];
			var addrStr = provinceName;
			if( provinceName!==cityName ) { // 判断是否为直辖市
				addrStr += cityName;
			}
			addrStr += datas["project_county_name"]+datas["project_address"];
			$("#address").html( addrStr );
			var stageText = getStationTextWithValue(datas["project_stage"], "projectStage");
			$("#stage").html( stageText );
			
			// 流程步骤
			var steps = datas["project_schedule"];
			//var rejectCnt = "图片不合规，请重新上传清晰图片不合规图片不合规，请重新上传清晰图片不合规图片不合规，请重新上传清晰图片不合规，请重新上传清晰图片不合规，请重新上传清晰图片不合规，请重新上传清晰图片不合规，请重新上传清晰图片不合规，请重新上传清晰";
			//steps = [{ "lifecycle_title": "项目已被驳回", "lifecycle_content": rejectCnt, "create_time": "2016-03-30 11:58:54", "status": "3" },{ "lifecycle_title": "项目已被驳回", "lifecycle_content": '"'+rejectCnt+'"', "create_time": "2016-03-30 11:58:54", "status": "4" }];
			var stepLiStr, stepStatus, stepImg;
			for(var i=0; i<steps.length; i++) {
			//for(var i=steps.length-1; i>=0; i--) {
				stepLiStr = "";
				stepStatus = steps[i]["status"];
				
    			if( i==0 ) {
    				stepImg = "../../static/images/station/process-cur.png";
    				stepLiStr += '<li class="current-step">';
    			} else {
    				stepImg = dataConfig.stepsImg[stepStatus];
    				stepLiStr += '<li>';
    			}
    			if( !stepImg ) {
    				// 如果统一配置里面没有配置，则默认使用OK的图片
    				stepImg = "../../static/images/station/process-ok.png";
    			}
    			stepLiStr += '<img src="'+stepImg+'">';
    			stepLiStr += '<label>'+steps[i]["lifecycle_title"]+'</label>';
    			// 被驳回时的步骤展示
    			if( stepStatus==3 ) {
    				stepLiStr += '<span class="reject-desc" onclick="openDetailDesc(this)">驳回原因？';
    				stepLiStr += '<input type="hidden" value="'+steps[i]["lifecycle_content"]+'" /></span>';
    			}
    			stepLiStr += '<div>'+steps[i]["create_time"]+'</div>';
    			stepLiStr += '</li>';
				
    			$(".steps-info").append( stepLiStr );
			}
			
			judgeKFPosition();
		}
	});
}
//根据接口返回的value值，在配置文件中查询对应的text中文内容
function getStationTextWithValue( value, configKey ) {
	var rtnText="", text;
	if( value ) {
		var valuesArr = value.split(",");
		for(var i=0; i<valuesArr.length; i++) {
			var text = stationDatasConfig.pageConfig[configKey][ valuesArr[i] ];
			if( !text ) { text = stationDatasConfig.pageConfig[configKey]["default"]; }
			rtnText += rtnText?","+text:text;
		}
	}
	return rtnText;
}
function judgeKFPosition() {
	var clientH = initParams.clientHeight;
    var htmlH = $("html").height();
    if( htmlH<clientH ) {
		$(".kf").addClass("page-bottom");
    }
}

$(function() {
	$popup = $(".cd-popup");
	
	loadPageData();
});
