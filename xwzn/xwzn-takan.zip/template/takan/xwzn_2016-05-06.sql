# ************************************************************
# Sequel Pro SQL dump
# Version 3408
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 101.200.78.100 (MySQL 5.6.10)
# Database: xwzn
# Generation Time: 2016-05-06 10:50:38 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table xw_exploration_report
# ------------------------------------------------------------

DROP TABLE IF EXISTS `xw_exploration_report`;

CREATE TABLE `xw_exploration_report` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '报告ID',
  `project_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '项目ID',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '报告名称',
  `province` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '省',
  `city` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '市',
  `area` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '区县',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '详细地址',
  `roof_type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '屋顶类型：1工业屋顶、2商业屋顶、3个人屋顶',
  `satellitp_picture` varchar(255) NOT NULL DEFAULT '' COMMENT '屋顶卫星图',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '踏勘人员ID',
  `username` char(20) NOT NULL DEFAULT '' COMMENT '踏勘人员',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '踏勘人员电话',
  `status` tinyint(4) NOT NULL DEFAULT '3' COMMENT '状态：0已删除、1已生成，2未生成，3未完成',
  `gtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '报告生成时间',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `username` (`username`),
  KEY `mobile` (`mobile`),
  KEY `uid` (`uid`),
  KEY `roof_type` (`roof_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='报告基本信息';



# Dump of table xw_exploration_report_detail
# ------------------------------------------------------------

DROP TABLE IF EXISTS `xw_exploration_report_detail`;

CREATE TABLE `xw_exploration_report_detail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '报告ID',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '屋顶名称',
  `know_architect` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '是否清楚屋顶的设计单位：0否，1是',
  `architect` varchar(50) NOT NULL DEFAULT '' COMMENT '设计单位',
  `buildtime` date DEFAULT NULL COMMENT '建成时间（yyy-mm-dd）',
  `area` float unsigned NOT NULL DEFAULT '0' COMMENT '面积（平方米）',
  `orientation` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '屋顶朝向：1正南、2东南、3西南、4北、5西北、6东北',
  `roof_picture` text COMMENT '屋顶现场实景照片（6张）JSON：1整体效果、2东向拍摄、3西向拍摄、4南向拍摄、5北向拍摄、6局部效果',
  `roof_material` tinyint(4) NOT NULL DEFAULT '1' COMMENT '屋顶材质：1现浇混凝土、2预制混凝土、3彩钢瓦、4瓦屋面、5其他',
  `barrier` varchar(255) NOT NULL DEFAULT '' COMMENT '障碍物（逗号分隔）：1女儿墙，2电梯间或楼梯间，3采光带，4通风设备，5屋面管道，6其他',
  `am_work_start` char(20) NOT NULL DEFAULT '' COMMENT '上午工作开始时间',
  `am_work_end` char(20) NOT NULL DEFAULT '' COMMENT '上午工作结束时间',
  `pm_work_start` char(20) NOT NULL DEFAULT '' COMMENT '下午工作开始时间',
  `pm_work_end` char(20) NOT NULL DEFAULT '' COMMENT '下午工作结束时间',
  `annual_holiday` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '全年放假天数',
  `operating_conditions` tinyint(4) NOT NULL DEFAULT '1' COMMENT '企业经营状况：1良好、2一般、3较差',
  `plan_way_online` tinyint(4) NOT NULL DEFAULT '1' COMMENT '计划上网方式：1自发自用 余电上网、2全额上网',
  `building_use` tinyint(4) NOT NULL DEFAULT '1' COMMENT '建筑物使用方式：1自用、2出租',
  `main_electrical_description` text COMMENT '主要用电设备描述',
  `lease_period` float NOT NULL DEFAULT '0' COMMENT '租用年限',
  `agree_installation` tinyint(4) NOT NULL DEFAULT '1' COMMENT '租赁方是否同意安装：0否、1是',
  `pollution` tinyint(4) NOT NULL DEFAULT '0' COMMENT '屋顶是否污染：0否、1是',
  `pollution_level` tinyint(4) NOT NULL DEFAULT '1' COMMENT '染程度：1轻度、2中度、3重度',
  `rust` tinyint(4) NOT NULL DEFAULT '0' COMMENT '屋顶是否锈蚀：0否、1是',
  `rust_level` tinyint(4) NOT NULL DEFAULT '1' COMMENT '锈蚀程度：1轻度、2中度、3重度',
  `pollution_rust_reason` text COMMENT '污染或锈蚀原因',
  `roof_length` float unsigned NOT NULL DEFAULT '0' COMMENT '屋顶长度',
  `roof_width` float unsigned NOT NULL DEFAULT '0' COMMENT '屋顶宽度',
  `roof_height` float unsigned NOT NULL DEFAULT '0' COMMENT '屋顶距地面高度',
  `waterproof_type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '防水类型：1刚性防水、2柔性防水',
  `is_leaking` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否漏水：0否、1是',
  `waterproof_use` float NOT NULL DEFAULT '0' COMMENT '屋顶防水已使用年限',
  `gradient` varchar(50) NOT NULL DEFAULT '' COMMENT '屋面坡度：范围值：3°、 5 ° 、8 ° 、10°、12° 、15°  、15°以上',
  `higher_window` tinyint(4) NOT NULL DEFAULT '1' COMMENT '是否有高出层面的采光窗：0否、1是',
  `window_height` float NOT NULL DEFAULT '0' COMMENT '采光窗高度',
  `plate_type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '彩钢板类型: 1直立锁边型、2角驰型、3梯形、4铝镁锰合金、5其他',
  `peak_spacing` float NOT NULL DEFAULT '0' COMMENT '彩钢瓦波峰间距(厘米）',
  `plate_rust` tinyint(4) NOT NULL DEFAULT '0' COMMENT '彩钢板有无明显锈蚀：0无、1有',
  `plate_points` tinyint(4) NOT NULL DEFAULT '0' COMMENT '彩钢板有无明显坏点：0无、1有',
  `plate_leaking` tinyint(4) NOT NULL DEFAULT '0' COMMENT '彩钢板有无漏水：0无、1有',
  `interior_picture` text COMMENT '屋顶内部现场实景照片（6张）：1整体效果1、2整体效果2、3局部效果1、4局部效果2、5其他、6其他',
  `roof_hang` tinyint(4) NOT NULL DEFAULT '0' COMMENT '屋面梁或板有无吊挂荷载：0无、1有',
  `fan_hole` tinyint(4) NOT NULL DEFAULT '0' COMMENT '屋面板有无风机开孔：0无、1有',
  `cable_pipe` text COMMENT '电缆井/管道位置描述',
  `structure_accordance` tinyint(4) NOT NULL DEFAULT '1' COMMENT '屋内结构或构件尺寸是否与图纸一致：0否、1是',
  `modify` tinyint(4) NOT NULL DEFAULT '0' COMMENT '屋面建成后有无改动后加设备：0否、1有',
  `upright_steel` char(50) NOT NULL DEFAULT '' COMMENT '立柱用钢材质：Q235、Q345、Q370',
  `girder_steel` char(50) NOT NULL DEFAULT '' COMMENT '钢梁用钢材质：Q235、Q345、Q370',
  `purline_steel` char(50) NOT NULL DEFAULT '' COMMENT '檩条用钢材质：Q235、Q345、Q370',
  `purline_specification` tinyint(4) NOT NULL DEFAULT '1' COMMENT '檩条用钢规格：1Z型钢、2C型钢、3高频焊工字钢、4复合型',
  `purline_model` varchar(50) NOT NULL DEFAULT '' COMMENT '檩条型号',
  `purline_span` varchar(50) NOT NULL DEFAULT '' COMMENT '檩条跨度',
  `is_ceiling` tinyint(4) NOT NULL DEFAULT '0' COMMENT '屋面板有无吊顶：0无、1有',
  `purline_deformed` tinyint(4) NOT NULL DEFAULT '0' COMMENT '檩条有无变形情况：0无、1有',
  `purline_rust` tinyint(4) NOT NULL DEFAULT '0' COMMENT '檩条有无腐蚀情况：0无、1有',
  `purline_brace` tinyint(4) NOT NULL DEFAULT '0' COMMENT '檩条间拉条情况：0无、1一道、2二道、3三道',
  `purline_hang` tinyint(4) NOT NULL DEFAULT '0' COMMENT '内部是否有掉挂：0否、1是',
  `purline_hang_condition` varchar(255) NOT NULL DEFAULT '' COMMENT '吊挂物情况（可多选）：1消防管道、2照明灯具、3群暖器、4其他',
  `purline_cable` text COMMENT '电缆桥架位置描述',
  `step` char(20) NOT NULL DEFAULT '' COMMENT '步：格式1-0，1-1',
  `status` tinyint(4) NOT NULL DEFAULT '2' COMMENT '状态：0已删除，1已完成，2未完成',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='屋顶360°详细信息';



# Dump of table xw_exploration_report_drawing
# ------------------------------------------------------------

DROP TABLE IF EXISTS `xw_exploration_report_drawing`;

CREATE TABLE `xw_exploration_report_drawing` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '报告ID',
  `factory_plane` tinyint(4) NOT NULL DEFAULT '0' COMMENT '厂区总平图：0否、1是',
  `building_design` tinyint(4) NOT NULL DEFAULT '0' COMMENT '建筑设计总说明图：0否、1是',
  `building_construction` tinyint(4) NOT NULL DEFAULT '0' COMMENT '建筑施工图整册：0否、1是',
  `structure_design` tinyint(4) NOT NULL DEFAULT '0' COMMENT '结构设计总说明：0否、1是',
  `structural_construction` tinyint(4) NOT NULL DEFAULT '0' COMMENT '结构施工图整册：0否、1是',
  `electric_plane` tinyint(4) NOT NULL DEFAULT '0' COMMENT '电气总平面图：0否、1是',
  `electric_design` tinyint(4) NOT NULL DEFAULT '0' COMMENT '电气设计总说明：0否、1是',
  `high_low_pressure` tinyint(4) NOT NULL DEFAULT '0' COMMENT '高低压一次系统图：0否、1是',
  `lightning_protection` tinyint(4) NOT NULL DEFAULT '0' COMMENT '防雷接地图：0否、1是',
  `troughing` tinyint(4) NOT NULL DEFAULT '0' COMMENT '电缆走线图：0否、1是',
  `switching_plane` tinyint(4) NOT NULL DEFAULT '0' COMMENT '配电室平面布置图：0否、1是',
  `roof_hvac` tinyint(4) NOT NULL DEFAULT '0' COMMENT '屋顶暖通管线布置图：0否、1是',
  `roof_fire` tinyint(4) NOT NULL DEFAULT '0' COMMENT '屋顶消防管线布置图：0否、1是',
  `step` char(20) NOT NULL DEFAULT '' COMMENT '步：格式1-0，1-1',
  `status` tinyint(4) NOT NULL DEFAULT '2' COMMENT '状态：0已删除，1已完成，2未完成',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='图纸收集信息';



# Dump of table xw_exploration_report_electric
# ------------------------------------------------------------

DROP TABLE IF EXISTS `xw_exploration_report_electric`;

CREATE TABLE `xw_exploration_report_electric` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '报告ID',
  `primary_voltage` float NOT NULL DEFAULT '0' COMMENT '变电进线电压',
  `measure_points_voltage` float NOT NULL DEFAULT '0' COMMENT '计量点电压',
  `transformer_num` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '变压器台数',
  `high_pressure` float NOT NULL DEFAULT '0' COMMENT '电压器高压',
  `low_pressure` float NOT NULL DEFAULT '0' COMMENT '变压器低压',
  `transformer_capacity` float unsigned NOT NULL DEFAULT '0' COMMENT '变压器容量',
  `step` char(20) NOT NULL DEFAULT '' COMMENT '步：格式1-0，1-1',
  `status` tinyint(4) NOT NULL DEFAULT '2' COMMENT '状态：0已删除，1已完成，2未完成',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='配电电气相关信息';



# Dump of table xw_exploration_report_electric_switching
# ------------------------------------------------------------

DROP TABLE IF EXISTS `xw_exploration_report_electric_switching`;

CREATE TABLE `xw_exploration_report_electric_switching` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '报告ID',
  `electric_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '配电室ID',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '配电室名称',
  `type` int(4) NOT NULL DEFAULT '1' COMMENT '配电室类型：1配电室、2总配电室、3高配电室',
  `property` varchar(50) NOT NULL DEFAULT '' COMMENT '产权',
  `picture` text COMMENT '配电室现场实景照片（6张）JSON：1全局图、2设备图、3间隔/空间图、4接线/模拟图、5布局草图、6其他',
  `status` tinyint(4) NOT NULL DEFAULT '2' COMMENT '状态：0已删除，1已完成，2未完成',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`),
  KEY `electric_id` (`electric_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='配电电气相关信息 配电室信息';



# Dump of table xw_exploration_report_owner
# ------------------------------------------------------------

DROP TABLE IF EXISTS `xw_exploration_report_owner`;

CREATE TABLE `xw_exploration_report_owner` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '报告ID',
  `equity_clear` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '产权是否清晰：0否、1是',
  `equity_owner` char(20) NOT NULL DEFAULT '' COMMENT '产权所有者',
  `contact` char(20) NOT NULL DEFAULT '' COMMENT '现场联系人',
  `phone` char(15) NOT NULL DEFAULT '' COMMENT '联系人电话',
  `investment_intent` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '用户投资意向：1自己投资、2找人投资、3部分投资',
  `electricity_fee_payment` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '用户电费缴纳情况：1正常、2趸售用电',
  `measure_type` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '商业照明是否与工业用电分开计量：0否、1是',
  `tou` tinyint(4) unsigned NOT NULL DEFAULT '1' COMMENT '是否执行峰谷平电价：0否、1是',
  `tip` text COMMENT '尖峰JSON',
  `tip_electrovalence` float unsigned NOT NULL DEFAULT '0' COMMENT '尖峰电价',
  `peak` text COMMENT '峰JSON',
  `peak_electrovalence` float unsigned NOT NULL DEFAULT '0' COMMENT '峰电价',
  `flat` text COMMENT '平JSON',
  `flat_electrovalence` float unsigned NOT NULL DEFAULT '0' COMMENT '平电价',
  `cereal` text COMMENT '谷JSON',
  `cerael_electrovalence` float unsigned NOT NULL DEFAULT '0' COMMENT '谷电价',
  `electrovalence` float unsigned NOT NULL DEFAULT '0' COMMENT '电价',
  `month_electricity` float unsigned NOT NULL DEFAULT '0' COMMENT '月用电量',
  `step` char(20) NOT NULL DEFAULT '' COMMENT '步：格式1-0，1-1',
  `status` tinyint(4) NOT NULL DEFAULT '2' COMMENT '状态：0已删除，1已完成，2未完成',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='与屋顶主沟通的信息';



# Dump of table xw_exploration_report_summary
# ------------------------------------------------------------

DROP TABLE IF EXISTS `xw_exploration_report_summary`;

CREATE TABLE `xw_exploration_report_summary` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `report_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '报告ID',
  `conclusion` text COMMENT '总结概述及对各分项评价',
  `question` text COMMENT '问题描述及风险提示',
  `step` char(20) NOT NULL DEFAULT '' COMMENT '步：格式1-0，1-1',
  `status` tinyint(4) NOT NULL DEFAULT '2' COMMENT '状态：0已删除，1已完成，2未完成',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `utime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `report_id` (`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='我的踏勘总结';




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
