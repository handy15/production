/*
 * 和原生框架交互的方法、事件
 * 注：
 * 1. 此文件需要放在js/common.js和js/WebViewJavascriptBridge.js后面；“当前页面”使用的js文件前面
 *    例：js/common.js、outside_func.js
 */

function setAppTitle( title, rightIcon ) {
	if( !rightIcon ) {
		rightIcon = "";
	}
	if( initParams.phoneAllSys[0]==initParams.currentPhoneSys ) {
		JavaScriptInterface.setAppTitle( title, rightIcon );
    } else if( initParams.phoneAllSys[1]==initParams.currentPhoneSys ) {
    	var iosFilterParams = "{'event':'setAppTitle', 'title': '"+title+"', 'rightIcon': '"+rightIcon+"'}";
    	iosFilter(iosFilterParams);
    } else {
    	//location.href = config.appServerUrl+"activity/activity_detail.html?id="+id+"&userId="+userid;
    }
}


// 提供IOS系统拦截url使用
function iosFilter(iosFilterParamsStr) {
	location.href = config.appServerUrl+"/"+iosFilterParamsStr;
}