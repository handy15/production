/**
 * Created by wangyaru on 2016/1/19.
 */
$(function(){
    $("#chooseAddr").click(function(){
        openAreaSel();
    });
})

function openAreaSel() {
    // 如果当前页面有滚动条，则处理这行
    $("body").css("overflow-y", "hidden");
    $("form").hide();
    //定位数据
    var provice = $('#province').val();
    var city = $('#city').val();
    var area = $("#area").val();
    if(provice || city || area){
        var str = 'regionSelect.html?provice=' + provice + '&city=' + city + '&area=' + area;
        $("#regionSel").attr("src",str).removeClass("uhide");
    }else{
        $("#regionSel").attr("src",'regionSelect.html').removeClass("uhide");
    }
}
function returnAreaVal(val) {
    $("#regionSel").addClass("uhide");
    // 如果当前页面有滚动条，则处理这行
    $("body").css("overflow-y", "auto");
    $("form").show();
    var regionSelResult = eval("("+val+")");
    //regionSelResult = { "province": {"id":"", "name":""}, "city": {"id":"", "name":""}, "area": {"id":"", "name":""} }

    // TODO 用户自己的业务逻辑处理... ...
    var selCnt;
    if( regionSelResult["province"].name ) selCnt = ' ' + regionSelResult["province"].name;
    if( regionSelResult["city"].name ) selCnt += ' ' + regionSelResult["city"].name;
    if( regionSelResult["area"].name ) selCnt += ' ' + regionSelResult["area"].name;

    if( selCnt ) { selCnt = selCnt; } else { selCnt = "您没有做任何选择"; }
    $("#address-h").html(selCnt);
    $("#ipt-address-h").val(selCnt);
    $('#province').val(regionSelResult["province"].id);
    $('#city').val(regionSelResult["city"].id);
    $('#area').val(regionSelResult["area"].id);
}

//高德地图
function openMap() {
    var $mapSel = $("#mapSel");
    if(!$mapSel.attr('src')){
        $mapSel.attr('src','map.html');
    }
    $mapSel.removeClass("uhide");
    // 如果当前页面有滚动条，则处理这行
    $("body").css("overflow-y", "hidden");
    $("form").hide();
}
function receiveMessage(e) {
    var data = e.data;
    if(data=="returnMapVal") {
        returnMapVal() ;
    }
}
if (typeof window.addEventListener != 'undefined') {//使用html5 的postMessage必须处理的
    window.addEventListener('message', receiveMessage, false);
} else if (typeof window.attachEvent != 'undefined') {
    window.attachEvent('onmessage', receiveMessage);
}
function returnMapVal(val) {
    $("#mapSel").addClass("uhide");
    // 如果当前页面有滚动条，则处理这行
    $("body").css("overflow-y", "auto");
    $("form").show();
    var mapSelResult = eval("("+val+")");
    //mapSelResult = { "province": "省份", "city": "城市", "area": "地区", "detail": "具体街道", "fulladdress": "","areaCode":"区的code"}
    var selCnt = mapSelResult["province"]+ ' ' + mapSelResult["city"]+ ' '+mapSelResult["area"];
    var $provice = $('#province');
    var $city = $('#city');
    var $area = $("#area");
    var reset = 0;
    //匹配code
    if(mapSelResult["province"] && mapSelResult["city"] && mapSelResult["area"]){
        jqueryAjaxGetJsonp(config.xwServerUrl + '/index.php', 'r=api/Region/GetRegionByName&province=' + mapSelResult["province"] + '&city=' + mapSelResult["city"] +'&area=' + mapSelResult["area"] + '&version=' + config.interfaceVersion, function (result) {
            if (result.code == 2000) {
                var datas = result.data;
                if(datas.areaId && datas.cityId && datas.provinceId){
                    $provice.val(datas.provinceId);
                    $city.val(datas.cityId);
                    $area.val(datas.areaId);
                    var selCnt = datas.provinceName + ' ' + datas.cityName + ' ' + datas.areaName;
                    $("#address-h").html(selCnt);
                    $("#ipt-address-h").val(selCnt);
                }else{
                    //cod值置空
                    $provice.val("");
                    $city.val("");
                    $area.val("");
                    $("#address-h").html('请您手动选择');
                    $("#ipt-address-h").val('请您手动选择');
                }
            } else {
                //cod值置空
                $provice.val("");
                $city.val("");
                $area.val("");
                $("#address-h").html('请您手动选择');
                $("#ipt-address-h").val('请您手动选择');
            }
        },function(){
            //cod值置空
            $provice.val("");
            $city.val("");
            $area.val("");
            $("#address-h").html('请您手动选择');
            $("#ipt-address-h").val('请您手动选择');
        });
    }else{
        if(!$.trim(selCnt)){
            $("#address-h").html('您没有做任何选择');
            $("#ipt-address-h").val('您没有做任何选择');
            //cod值置空
            $provice.val("");
            $city.val("");
            $area.val("");
        }else{
            $("#address-h").html('请您手动选择');
            $("#ipt-address-h").val('请您手动选择');
            //cod值置空
            $provice.val("");
            $city.val("");
            $area.val("");
        }
    }
    //$("#area").val(mapSelResult.areaCode);
    $("input[name='project[address]']").val(mapSelResult["detail"]);
    //$("#lnglat").html( mapSelResult["positionJson"]["lng"]+", "+mapSelResult["positionJson"]["lat"] );
}