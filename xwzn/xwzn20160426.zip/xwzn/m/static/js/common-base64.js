/**
 * 获取当前页面的参数
 * @param String name 请求中参数的key值
 */
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}
// HTML页面：通用信息配置
var config = {
		"serverUrl": "http://api.app.solarbao.com:21888", // 21888端口历史接口的正式环境
	    //"serverUrl": "http://101.200.144.60:21888", // 21888端口历史接口的测试环境
	    
	    "apiServerUrl": "http://api.app.solarbao.com", //api后台接口的正式环境
	    //"apiServerUrl": "http://101.200.144.60:81", //api后台接口测试环境
	    //"apiServerUrl": "http://api.maibaoxian.me",  // api后台接口的开发环境
	    
	    "mpServerUrl": "http://mp.app.solarbao.com", //微信、IM聊天、二维码接口的正式环境
	    "mpWxId": "gh_fe122e410ab5",
	    
	    "appServerUrl": "http://we.app.solarbao.com", // h5页面的正式环境
	    //"appServerUrl": "http://101.200.144.60:82", // h5页面的测试环境
	    //"appServerUrl": "http://app.lebaojjr.com", // h5页面的开发环境
	    
	    "xwServerUrl": "http://101.200.78.100:91", // 新维需求：后台接口的开发环境
	    
	    "interfaceVersion": "0.0.0", // 后台接口版本的控制，每个请求都必须要有这个参数：version=config.interfaceVersion

	    "place": false  // 防止上面配置时，缺少','分隔，此为占位配置，无具体使用含义
};
//HTML页面：初始化参数
var initParams = {
    // 手机分辨率：宽度
    "phoneWidth": window.screen.width,
    // 手机分辨率：高度
    "phoneHeight": window.screen.height,
    // 浏览器窗口的宽度
    "clientWidth": document.documentElement.clientWidth,
    // 浏览器窗口的高度
    "clientHeight": document.documentElement.clientHeight,
    // 手机操作系统
    "phoneAllSys": ["android", "ios"],
    // 当前手机操作系统
    "currentPhoneSys": "" 
};
//判断手机类型
var browser = {
    versions: function() {
        var u = navigator.userAgent, app = navigator.appVersion;
        return {//移动终端浏览器版本信息 
            trident: u.indexOf('Trident') > -1, //IE内核
            presto: u.indexOf('Presto') > -1, //opera内核
            webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
            gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
            mobile: !!u.match(/AppleWebKit.*Mobile.*/) || !!u.match(/AppleWebKit/), //是否为移动终端
            ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
            android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或者uc浏览器
            iPhone: u.indexOf('iPhone') > -1 || u.indexOf('Mac') > -1, //是否为iPhone或者QQHD浏览器
            iPad: u.indexOf('iPad') > -1, //是否iPad
            webApp: u.indexOf('Safari') == -1 //是否web应该程序，没有头部与底部
        };
    }(),
}
function judgePhoneSysType() {
    if (browser.versions.ios || browser.versions.iPhone || browser.versions.iPad) {
        return "ios";
    }
    else if (browser.versions.android) {
        return "android";
    } else {
        return "";
    }
// document.writeln(" 是否为移动终端: " + browser.versions.mobile);
// document.writeln(" ios终端: " + browser.versions.ios);
// document.writeln(" android终端: " + browser.versions.android);
// document.writeln(" 是否为iPhone: " + browser.versions.iPhone);
// document.writeln(" 是否iPad: " + browser.versions.iPad);
// document.writeln(navigator.userAgent);
}
// 初始化定义手机类型
initParams.currentPhoneSys = judgePhoneSysType();

/**
 * GET请求+JSONP格式的异步AJAX请求
 * @param {Object} reqrUrl 请求的url，注此参数不能为空！！！
 * @param {Object} params 请求的参数，格式为key1=val1&key2=val2或{key1: val1, key2: val2}
 * @param {Object} successCallback 请求成功回调函数，参数为请求返回的参数function(data)
 * @param {Object} errorCallback 请求出错回调函数，参数为function(a, b, c)
 * @param {Object} timeoutCallback 请求出错回调函数，参数为function(jqAjaxReqr, status)。jqAjaxReqr请求的标识；status请求的状态：timeout、success、error
 * 例：
 * jqueryAjaxGetJsonp(
 * 		"http://www.baidu.com", //不能为空
 * 		"key=value", //可空，或不传此参
 * 		function(data) {alert("success");}, //可空，或不传此参
 * 		function(a,b,c) {alert("error");}, //可空，或不传此参
 * 		function(jqAjaxReqr, status) {jqAjaxReqr.abort();} //可空，或不传此参
 *  );
 */
function jqueryAjaxGetJsonp(reqrUrl, params, successCallback, errorCallback, timeoutCallback) {
	if(!params) params="";
	if( reqrUrl.indexOf("jsonp")==-1&&params.indexOf("jsonp")==-1) {params += "&jsonp=1";}
	var jqAjaxReqr = $.ajax({
		// timeout : 5000, //超时时间设置，单位毫秒
		type: "GET",
		url: reqrUrl,
		data: params,
		dataType: "jsonp",
		success: function(data) {
			if( successCallback && typeof successCallback=="function" ) {
				successCallback(data);
			}
		},
		complete: function(XMLHttpRequest, status) {
			if( timeoutCallback && typeof timeoutCallback=="function" ) {
				timeoutCallback(jqAjaxReqr, status);
			} else {
				if(status=='timeout'){//超时,status还有success,error等值的情况
					jqAjaxReqr.abort();
					// alert("请求访问超时");
				}
			}
		},
		error: function(a, b, c) {
			if( errorCallback && typeof errorCallback=="function" ) {
				errorCallback(a, b, c);
			}
		}
	});
}

//新维智能的公共组件
var xwznUtility = xwznUtility || {};
$.extend(xwznUtility,{
	//获取url中的openId或user_id
	getOpenOrUserId: function(){
		//接口参数
		var returnStr = '';
		var openId = getQueryString("openId");
		var user_id = getQueryString("user_id");
		if(openId){
			returnStr = 'openId=' + openId;
		}else if(user_id){
			returnStr = 'user_id=' + user_id;
		}
		return returnStr;
	},
	/**
	 * 读取文件
	 * @param {event} evt 目标事件对象
	 * @param {Integer} maxSize 压缩文件的最大值
	 * @param {Integer} imgAccount 上传文件的个数限制
	 * @return 无返回值
	 */
	handleFileSelect: function (evt,maxSize,imgAccount,callbackFunction) {
		var that = this;
		// var filebtn = document.getElementById(id);
		// console.log(filebtn);
		// var files = filebtn.target.files;
		// console.log(filebtn.target);
		 console.log(maxSize);
		var files = evt.target.files;
		imgAccount = imgAccount || files.length;
		for (var i = 0, f; f = files[i],i<imgAccount; i++) {
			// Only process image files.
			if (!f.type.match('image.*')) {
				continue;
			}

			var reader = new FileReader();

			// Closure to capture the file information.
			reader.onload = (function(theFile) {
				return function(e) {
					// Render thumbnail.
					// console.log(evt.target.files[0]);
					// console.log(e.target);
					var result = e.target.result;
					//小于maxSize就直接上传，不压缩
					if(maxSize >= theFile.size){
						callbackFunction(result);
						return;
					}

					var img = new Image();
					img.src = result;
					var jicImg = null;
					//图片加载完毕之后进行压缩，然后上传
					if(img.complete){
	//                                console.log('complete');
						callback();
					}else{
	//                                console.log('onload');
						img.onload = callback;
					}
					function callback(){
						console.log('h=' + img.height);
						var quality = maxSize/theFile.size || 0.5;
						jicImg = that.compress(img,quality);
						callbackFunction(jicImg ? jicImg.src : "data:,");
						img = null;
					}
				};
			})(f);

			// Read in the image file as a data URL.
			reader.readAsDataURL(f);
		}
	},
	/**
	 * 压缩图片
	 * Receives an Image Object (can be JPG OR PNG OR JIF) and returns a new Image Object compressed
	 * @param {Image} source_img_obj The source Image Object
	 * @param {Integer} quality The output quality of Image Object
	 * @return {Image} result_image_obj The compressed Image Object
	 */
	compress: function(source_img_obj, quality){
		var imgType = source_img_obj.src.match(/\/(jpeg|png|gif)/i);
		//设置像素界限值
		var maxPX = 4000000,midPX = 1000000;
		//mime_type可为：image/png，image/jpeg,image/svg+xml等 MIME类型中选择
		var mime_type = "image/jpeg";
		if(imgType){
			mime_type = "image/" + imgType[1];
			maxPX = 1000000;
			midPX = 100000;
		}else{
			return null;
		}
		console.log(mime_type);
		//图片的宽高
		var width = source_img_obj.naturalWidth;
		var height = source_img_obj.naturalHeight;
		//如果图片大于四百万像素，计算压缩比并将大小压至400万以下
		var ratio;
		if ((ratio = width * height / 4000000)>1) {
			ratio = Math.sqrt(ratio);
			width /= ratio;
			height /= ratio;
		}else {
			ratio = 1;
		}
		quality *= ratio;
		console.log(quality);

		var cvs = document.createElement('canvas');
		//naturalWidth真实图片的宽度
		cvs.width = width;
		cvs.height = height;
		var ctx = cvs.getContext("2d");
		//如果图片像素大于100万则使用瓦片绘制
		var count;
		if ((count = width * height / 1000000) > 1) {
			count = ~~(Math.sqrt(count)+1); //计算要分成多少块瓦片
			//计算每块瓦片的宽和高
			var nw = ~~(width / count);
			var nh = ~~(height / count);
			//瓦片canvas
			var tcvs = document.createElement('canvas');
			var tctx = tcvs.getContext('2d');
			tcvs.width = nw;
			tcvs.height = nh;
			for (var i = 0; i < count; i++) {
				for (var j = 0; j < count; j++) {
					tctx.drawImage(source_img_obj, i * nw * ratio, j * nh * ratio, nw * ratio, nh * ratio, 0, 0, nw, nh);
					ctx.drawImage(tcvs, i * nw, j * nh, nw, nh);
				}
			}
		} else {
			ctx.drawImage(source_img_obj, 0, 0, width, height);
		}

		//显示canvas
		//document.getElementById("canvas").appendChild(cvs);
		var newImageData = cvs.toDataURL(mime_type, quality);
		var result_image_obj = new Image();
		result_image_obj.src = newImageData;
		return result_image_obj;
	},
	/**
	 * @description upload image to serve
	 * @param {string} basestr  The base64 code of image
	 * @param {function} callback  after image is uploaded,excute the function of callback
	 */
	upload: function(basestr,callback){
		if(callback){
			callback(basestr);
		}
	}
});