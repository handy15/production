if( fr=="spick" ) {
	$("body").append("<script type='text/javascript' src='../../static/js/WebViewJavascriptBridge.js'></script>");
	$("body").append("<script type='text/javascript' src='../../static/js/jsBridgeApp.js'></script>");
	var titleObj = {
		"title": document.title, 
		"leftIcon":"goMyStation", 
		"rightIcon":[]
	};
	callSetAppTitle( titleObj );
}

// 关闭APP软件，关闭webview
function goBackApp() {
	if( fr=="spick" ) {
		closeH5();
	}
}
function goMyStation() {
	location.href = "my-apply.html?userId="+userId+"&fr="+fr;
}

function loadPageData() {
	var url = config.gfServerUrl+"/project/count";
	var paramsStr = getCheckParams( userId, "paramsStr" );
	jqueryAjaxGetJsonp(url, paramsStr, function(result) {
		if( result.code==2000 ) {
			$("#count").html( result.data.count );
		}
	});
}

$(function() {
	loadPageData();
});
