/**
 * Created by wangyaru on 2016/4/5.
 * 电站申请
 */
var timer = null;
var $loading = $(".loading");
var $mask = $(".mask");
var applyStation = {
    //申请项目初始化
    init:function(){
        var that = this;
        //设置title
        that.setAppHeader();
        //初始化数据
        that.loadPageInitDatas();
        //手动选择省市区
        $("#chooseAddr").click(function(){
            that.openAreaSel();
        });
        //地图
        $("#chooseMap").click(function(){
            that.openMap();
        });
        //项目阶段初始化选中
        $(".project-steps .per-step:first").trigger('click');
        //上传图片
        that.uploadImg();
        //下一步
        that.stepEvent();

        // 屋顶材质选择初始化选中
        $(".roof-material div:first").trigger('click');
        //是、否事件
        that.yesOrNo();
        //设置按钮在最底层
        that.judgePageHeight();
        //使用html5 的postMessage必须处理的
        that.postMessage();
    },
    //修改项目初始化
    initModify: function(){
        var that = this;
        //设置title
        that.setAppHeader();
        //数据初始化
        that.loadPageInitDatas();
        //备案信息
        that.yesOrNo();
        //获取电站信息
        that.getProjectInfo(function(result){
            //手动选择省市区
            $("#chooseAddr").click(function(){
                that.openAreaSel();
            });
            //地图
            $("#chooseMap").click(function(){
                that.openMap();
            });
            var info = result.data;
            //第几步
            var step = $('#step').val();
            if('1' == step){//电站基本信息
                that.deleteInputText();
                $('#proId').text(info.project_number);
                $("input[name='pro[project_name]']").val(info.project_name);
                $("input[name='pro[project_address]']").val(info.project_address);
                $("input[name='pro[project_province_id]']").val(info.project_province_id);
                $("input[name='pro[project_city_id]']").val(info.project_city_id);
                $("input[name='pro[project_county_id]']").val(info.project_county_id);
                var address = info.project_province_name + '—' + info.project_city_name + '—'  + info.project_county_name;
                if('——' != address){
                    $('#address-h').text(address).addClass('dark-color');
                }
                //照片
                var $imgs = $('.upload-imgs .per-upload');
                var images = info.project_img;
                for(var i= 0,len=images.length;i<len;i++){
                    if(i<3){
                        var $container = $imgs.eq(i);
                        $container.find('img').attr('src',images[i][1]);
                        //处理不规则图片
                        that.dealImg(images[i][1],$container);
                        //删除按钮
                        $container.append('<div class="btn-del" onclick="">&times;</div>');
                        $('#img'+i).val(images[i][0]);
                    }else{//多余3张图片
                        $('#step1').append('<input type="hidden" id="img2" name="img[]" value="'+ images[i][0] + '" />');
                    }
                }
                //上传图片事件
                that.uploadImg();
                //项目阶段
                $('.project-steps .per-step[value=' + info.project_stage +']').trigger('click');
            }else if('2' == step){//电站详细信息
                //资源类型
                that.setSelectedValue('projectType',info.project_type);
                that.setSelectedPosition($('#projectType .fixed-option-c'));
                //面积
                $("input[name='pro[project_proportion]']").val(info.project_proportion);
                if('-1' != $.inArray(info.project_type,['4','5'])){
                    //土地性质
                    that.setSelectedValue('landNature',info.project_land_nature);
                    //that.setSelectedPosition($('#landNature .fixed-option-c'));
                    // 屋顶材质选择初始化选中
                    $(".roof-material div:first").trigger('click');
                }else{
                    //屋顶材质
                    $('.roof-material div[value=' + info.project_material +']').trigger('click');
                    //建成时间
                    that.setSelectedValue('createTime',/^\d+/.exec(info.project_built_date)[0]);
                    //that.setSelectedPosition($('#createTime .fixed-option-c'));
                }
                //面积
                $("input[name='pro[project_proportion]']").val(/^(0|\d+)(.\d*)?/.exec(info.project_proportion)[0]);
                //所发电力自发自用比例
                that.setSelectedValue('powerUse',info.project_area_proportion);
                //that.setSelectedPosition($('#powerUse .fixed-option-c'));
                //项目备案
                var $records = $("input[name='pro[project_is_record]']").prev('.yes-no-bar').children('div');
                if(0 == info.project_is_record){
                    $records.eq(1).trigger('touchend');
                }else{
                    $records.eq(0).trigger('touchend');
                    //公司名称
                    $("input[name='pro[project_record_name]']").val(info.project_record_name);
                }
                //电力接入
                var $access = $("input[name='pro[project_is_access]']").prev('.yes-no-bar').children('div');
                if(0 == info.project_is_access){
                    $access.eq(1).trigger('touchend');
                }else{
                    $access.eq(0).trigger('touchend');
                }
                //租用协议
                var $rent = $("input[name='pro[project_is_rent]']").prev('.yes-no-bar').children('div');
                if(0 == info.project_is_rent){
                    $rent.eq(1).trigger('touchend');
                }else{
                    $rent.eq(0).trigger('touchend');
                }
            }else if('3' == step){//编辑需求说明
                //需求类型
                var needType = info.project_category.split(',');
                $('#reqrType li').each(function(index,element){
                    if('-1' != $.inArray($(element).attr('value'),needType)){
                        $(element).trigger('click');
                    }
                });
                //需求描述
                $("[name='pro[project_desc]']").val(info.project_desc);
            }
            //保存
            $('#save').click(function(){
                var $this = $(this);
                //‘保存’按钮锁定
                var isDisabled = $this.attr('locked');
                if(!(isDisabled && '1' == isDisabled)) {
                    //表单验证
                    $this.attr('locked', '1');
                    var isPass = true;
                    //表单验证
                    if ('1' == step) {//电站基本信息
                        isPass = that.validForm().step1();
                    } else if ('2' == step) {//电站详细信息
                        isPass = that.validForm().step2();
                    } else if ('3' == step) {//编辑需求说明
                        isPass = that.validForm().step3();
                    }
                    if (isPass) {
                        var proId = getQueryString('id');
                        var userId = getQueryString('userId');
                        if (userId && (0 < proId)) {
                            jqueryAjaxGetJsonp(config.gfServerUrl + '/project/add', getCheckParams(userId, 'paramsStr') + '&pro[project_id]=' + proId + '&pro[status]=2&' + $('#applyForm').serialize() + '&version=' + config.interfaceVersion, function (result) {
                                if (result.code == 2000) {
                                    window.location.href = 'detail.html?userId=' + userId + '&id=' + proId + '&fr=' + getQueryString("fr");
                                } else {
                                    that.hideTip(result.msg);
                                    $this.attr('locked', '0');
                                }
                            }, function () {
                                that.hideTip('网络问题，请稍后再试！');
                                $this.attr('locked', '0');
                            });
                        } else {
                            that.hideTip('参数错误！');
                            $this.attr('locked', '0');
                        }
                    }else{
                        $this.attr('locked', '0');
                    }
                }
            });
            //设置按钮在最底层
            that.judgePageHeight();
        });
    },
    //设置title
    setAppHeader: function(){
        var fr = getQueryString("fr");
        if('spick' == fr){
            $("body").append('<script type="text/javascript" src="../../static/js/outside_func.js"></script>');
            setAppTitleAndDetail($("title").text());
        }
    },
    //手动选择省市区
    openAreaSel: function () {
        var userId = getQueryString('userId');
        // 如果当前页面有滚动条，则处理这行
        $("body").css("overflow-y", "hidden");
        $("form").hide();
        //定位数据
        var provice = $('#province').val();
        var city = $('#city').val();
        var area = $("#area").val();
        if(provice || city || area){
            var str = '../tools/region-select.html?provice=' + provice + '&city=' + city + '&area=' + area + '&userId=' + userId;
            $("#regionSel").attr("src",str).removeClass("uhide");
        }else{
            $("#regionSel").attr("src",'../tools/region-select.html?userId=' + userId).removeClass("uhide");
        }
    },
    // 地图
    openMap: function () {
        var $mapSel = $("#mapSel");
        if(!$mapSel.attr('src')){
            $mapSel.attr('src','map.html');
        }
        $mapSel.removeClass("uhide");
        // 如果当前页面有滚动条，则处理这行
        $("body").css("overflow-y", "hidden");
        $("form").hide();
    },
    // 加载页面内容需要初始化的数据
    loadPageInitDatas: function() {
        var that = this;
        // 加载项目阶段数据
        var $projectStep = $(".project-steps");
        if($projectStep.length){
            var projectStep = stationDatasConfig["projectStep"];
            var arrayStr = [];
            for(var i=0; i<projectStep.length; i++) {
                arrayStr.push('<div class="per-step" value="'+projectStep[i]["id"]+'">'+projectStep[i]["name"]+'</div>');
            }
            $projectStep.append(arrayStr.join(''));
            //项目阶段事件
            $projectStep.find(".per-step").on('click',function(){
                that.chooseStep(this);
            });
        }

        // 加载屋顶材质数据
        var $roofMaterial = $(".roof-material");
        if($roofMaterial.length){
            var roofMaterial = stationDatasConfig["roofMaterial"];
            arrayStr = [];
            for(var i=0; i<roofMaterial.length; i++) {
                arrayStr.push('<div value="'+roofMaterial[i]["id"]+'">'+roofMaterial[i]["name"]+'</div>');
            }
            $roofMaterial.append(arrayStr.join(''));
            // 屋顶材质选择的点击事件
            $roofMaterial.find("div").on('click',function(){
                that.chooseRoofMaterial(this);
            });
        }

        //加载资源类型
        var $projectType = $('#projectType');
        if($projectType.length){
            var projectType = stationDatasConfig["projectType"];
            var len = projectType.length;
            arrayStr = [];
            for(var i=0; i<len; i++) {
                arrayStr.push('<li value="'+projectType[i]["id"]+'">'+projectType[i]["name"]+'</li>');
            }
            $projectType.find("ul").append(arrayStr.join(''));
            that.mySelectHeight( $projectType.find("fixed-option-c"), len );
        }

        //生成建成时间
        var $createTime = $('#createTime');
        if($createTime.length){
            var starYear = 1980;
            var endYear = parseInt(new Date().getFullYear());
            arrayStr = [];
            for(var i=starYear;i<=endYear;i++){
                arrayStr.push('<li value="' + i +'">' + i +'年</li>')
            }
            $createTime.find('ul').append(arrayStr.join(''));
            that.mySelectHeight( $createTime.find("fixed-option-c"), endYear-starYear );
        }

        //加载所发电力自发自用比例
        var $powerUse = $('#powerUse');
        if($powerUse.length){
            var powerUse = stationDatasConfig["powerUse"];
            var len = powerUse.length;
            arrayStr = [];
            for(var i=0; i<len; i++) {
                arrayStr.push('<li value="'+powerUse[i]["id"]+'">'+powerUse[i]["name"]+'</li>');
            }
            $powerUse.find('ul').append(arrayStr.join(''));
            that.mySelectHeight( $powerUse.find("fixed-option-c"), len );
        }

        //加载土地类型
        var $landNature = $('#landNature');
        if($landNature.length){
            var landNature = stationDatasConfig["landNature"];
            var len = landNature.length;
            arrayStr = [];
            for(var i=0; i<len; i++) {
                arrayStr.push('<li value="'+landNature[i]["id"]+'">'+landNature[i]["name"]+'</li>');
            }
            $landNature.find('ul').append(arrayStr.join(''));
            that.mySelectHeight( $landNature.find("fixed-option-c"), len );
        }

        //下拉事件：资源类型、建成时间、所发电力自发自用比例
        var $mask = $('.mask');
        var $select = $('.step-2 li[for]');
        if($select.length){
            $select.click(function(){
                var $this = $(this);
                var forId = $this.attr('for');
                $mask.show();
                //隐藏其他下拉框
                //that.hideSelectOption(forId);
                //显示对应下拉框
                $('#'+forId).css("display", "block").animate({
                    "bottom": 0 + "px"
                }, "slow",function(){
                    document.addEventListener('touchmove', function (e) { e.preventDefault(); });
                    var $content = $('#'+forId).find('.fixed-option-c');

                    if(!$content.attr('iscroll')){
                        var iscroll = new iScroll($content[0]);
                        $content.attr('iscroll',iscroll);
                        var $selected = $content.find('li.selected');
                        if($selected.length){
                            var singleHeight = $selected.outerHeight();
                            var top = $selected.offset().top - $content.offset().top;
                            var pt = parseInt($content.css('padding-top').match(/^\d+(.\d+)?/)[0]);
                            //$content.scrollTop();
                            iscroll.scrollTo(0,top-singleHeight-pt,0,true);
                        }

                    }
                    //that.setSelectedPosition($('#'+forId).find('.fixed-option-c'));
                });
                //$this.closest('form').css({'overflow':'hidden'}).height($(window).height());

            });
            //下拉选择
            $('.fixed-option-ul li').click(function(){
                var $this = $(this);
                $this.addClass('selected').siblings().removeClass('selected');
            });
            //完成
            $('.fixed-option-ok').click(function(){
                var $this = $(this);
                $mask.hide();
                var $parent = $this.parents('.fixed-option');
                //设置隐藏域
                var selectedValue = $parent.find('ul li.selected').attr('value');
                $parent.css({'display':'none','bottom':-$parent.height()+'px'});
                if(selectedValue){
                    var $input = $parent.find('input[name]');
                    $input.val(selectedValue);
                    $('.step-2 li[for='+ $parent.attr('id') +'] span.right-cnt').text($parent.find('ul li.selected').text()).addClass('dark-color');
                    //资源类型
                    if('pro[project_type]' == $input.attr('name')){
                        var unit = '平方米';
                        var $roofs = $('ul.step-2 li[flag=roof]');
                        var $land = $('ul.step-2 li[for=landNature]');
                        if('-1' != $.inArray(selectedValue,['4','5'])){
                            unit = '亩';
                            $roofs.hide();
                            $land.show();
                        }else{
                            $roofs.show();
                            $land.hide();
                        }
                        $('#unitArea').html(unit);
                    }
                }
                //$this.closest('form').css({'overflow':'auto','height':'auto'});
                document.removeEventListener('touchmove');
                document.addEventListener('touchmove', function (e) { });
            });
            //取消
            $('.fixed-option-cancel').click(function(){
                var $this = $(this);
                $mask.hide();
                var $parent = $this.parents('.fixed-option');
                $parent.css({'display':'none','bottom':-$parent.height()+'px'});
                //重置选项
                var $input = $parent.find('input[name]');
                if('' != $input.val()){
                    $parent.find('.fixed-option-ul li[value=' + $input.val() + ']').trigger('click');
                }else{
                    $parent.find('.fixed-option-ul li').removeClass('selected');
                }
                //$this.closest('form').css({'overflow':'auto','height':'auto'});
                document.removeEventListener('touchmove');
                document.addEventListener('touchmove', function (e) { });
            });
            //第二步：电站信息 文本框获得焦点时，隐藏下拉框
            //$('#step2').find(' input[type=number],input[type=text]').focus(function(){
            //    that.hideSelectOption();
            //});
            //点击黑色蒙版，下拉框消失
            $('.mask').click(function(){
                that.hideSelectOption();
            });
        }

        //需求类型
        var reqrType = stationDatasConfig["reqrType"];
        var $reqrType =  $("#reqrType");
        if($reqrType.length){
            arrayStr = [];
            for(var i=0; i<reqrType.length; i++) {
                arrayStr.push('<li value="'+reqrType[i]["id"]+'"><span>'+reqrType[i]["name"]+'</span><i></i></li>');
            }
            $reqrType.append(arrayStr.join(''));
            $reqrType.on("click", "li", function() {
                var $this = $(this);
                var thisValue = $this.attr('value');
                var $input = $("input[name='pro[project_category]']");
                var inputValue = $input.val();
                if( $this.hasClass("selected") ) {
                    $this.removeClass("selected");
                    var reg = new RegExp(thisValue+',|,'+thisValue+'$'+'|'+thisValue,'g');
                    inputValue = inputValue.replace(reg,'');
                } else {
                    $this.addClass("selected");
                    if('' != inputValue){
                        inputValue += ',';
                    }
                    inputValue += thisValue;
                }
                $input.val(inputValue);
            });
        }
    },
    // 底部弹框的内容高度处理
    mySelectHeight: function( $obj, objChildLen ) {
    	// ul>li的行高是30px
    	if( objChildLen>=5 ) {
    		$obj.height(200);
        } else if( objChildLen>=4 ) {
        	$obj.height(160);
        } else if( objChildLen>=3 ) {
        	$obj.height(120);
        }
    },
    // 项目阶段选择事件
    chooseStep: function (obj) {
        var $obj = $(obj);
        $obj.siblings().removeClass("selected");
        $obj.addClass("selected");
        $("#projectStep").val( $obj.attr("value") );
    },
    // 屋顶材质选择事件
    chooseRoofMaterial: function (obj) {
        var $obj = $(obj);
        $obj.siblings().removeClass("selected");
        $obj.addClass("selected");
        $("#roofMaterial").val( $obj.attr("value") );
    },
    //是、否事件
    yesOrNo: function(){
        var that = this;
        $("body").on("touchend", ".yes-no-bar > div", function() {
            var $this = $(this);
            $this.siblings().removeClass("selected");
            $this.addClass("selected");
            //设置input的value值
            var thisValue = $.trim($this.text()) == '是' ? 1 : 0;
            var $input = $this.parents('li').find('input[name]');
            $input.val(thisValue);
            //是否取得项目备案
            if('pro[project_is_record]' == $input.attr('name')){
                var $company = $this.parents('li').next('li');
                if(0 == thisValue){
                    $company.hide().find('input[name]').val('');
                }else if(1 == thisValue){
                    $company.show();
                }
                //设置按钮在最底层
                $('.steps:visible .btn-block').removeClass('page-bottom');
                that.judgePageHeight();
            }
        });
    },
    // 判断底部的按钮是否处于页面的底部
    judgePageHeight: function () {
        var clientH = initParams.clientHeight;
        var htmlH = $("html").height();//alert(clientH + ',' + htmlH);
        if( htmlH<clientH ) {
            $.each( $(".steps"), function(i, step) {
                var $step = $(step);
                var $btnBlock = $step.find(".btn-block");
                if( !$step.hasClass("uhide") && !$btnBlock.hasClass("page-bottom") ) {
                    $btnBlock.addClass("page-bottom");
                }
            });
        }
    },
    stepEvent: function(){
        var that = this;
        //第1步 下一步
        $('#step1Next').click(function(){
            //表单验证
            if(that.validForm().step1()){
                //跳转到下一步
                that.showStep(2);
            }
        });
        //第2步 上一步
        $('#step2Previous').click(function(){
            that.showStep(1);
        });
        //第2步 下一步
        $('#step2Next').click(function(){
            //表单验证
            if(that.validForm().step2()){
                that.showStep(3);
            }
        });
        //第3步 上一步
        $('#step3Previous').click(function(){
            that.showStep(2);
        });
        //第3步 完成
        $('#step3next').click(function(){
            var $this = $(this);
            //‘完成’按钮锁定
            var isDisabled = $this.attr('locked');
            if(!(isDisabled && '1' == isDisabled)){
                //表单验证
                $this.attr('locked','1');
                if(that.validForm().step3()) {
                    var userId = getQueryString('userId');
                    if(userId){
                        jqueryAjaxGetJsonp(config.gfServerUrl + '/project/add',getCheckParams(userId,'paramsStr') + '&' + $('#applyForm').serialize() + '&version=' + config.interfaceVersion,function(result){
                            if(result.code == 2000){
                                window.location.href = 'apply-ok.html?userId=' + userId + '&fr=' + getQueryString("fr");
                            }else{
                                that.hideTip(result.msg);
                                $this.attr('locked','0');
                            }
                        },function(){
                            that.hideTip('网络问题，请稍后再试！');
                            $this.attr('locked','0');
                        });
                    }else{
                        that.hideTip('参数错误！');
                        $this.attr('locked','0');
                    }
                }else{
                    $this.attr('locked','0');
                }
            }
        });
    },
    // 总共有多少步
    totalStep: 3,
    // 页面按钮点击时，显示第n步的内容
    showStep: function ( n ) {
        var that = this;
        if( n<1 || n>that.totalStep ) return false;
        $(".steps").addClass("uhide");
        $( "#step"+n ).removeClass("uhide");
        that.judgePageHeight();
    },
    //表单验证
    validForm: function(){
        var that = this;
        return {
            step1: function(){
                var province = $('#province').val(),
                    city = $('#city').val(),
                    area = $('#area').val();
                //地址验证
                if(!province && !city && !area){
                    that.hideTip('请填写资源地址哦');
                    return false;
                }
                if(!(province && city && $("input[name='pro[project_address]']").val())){
                    that.hideTip('请填写完整的地址信息哦');
                    return false;
                }
                //上传图片验证
                if(!($('#img0').val() && $('#img1').val() && $('#img2').val())){
                    that.hideTip('请上传3张土地/屋顶现场实景照片');
                    return false;
                }
                return true;
            },
            step2: function(){
                //项目名称  兼容电站修改
                var $proName = $("#step2 input[name='pro[project_name]']");
                if($proName.length && '' == $.trim($proName.val())){
                    that.hideTip('别忘了给您的项目起个名字哦');
                    return false;
                }
                //资源类型
                if('' == $.trim($("input[name='pro[project_type]']").val())){
                    that.hideTip('请选择您资源的类型');
                    return false;
                }
                //资源类型值
                var unitValue = $("input[name='pro[project_type]']").val();
                var arrLand = ['4','5'];
                //面积
                var $area = $("input[name='pro[project_proportion]']");
                var area = $.trim($("input[name='pro[project_proportion]']")[0].value);
                if('' == area && !$area[0].validity.badInput){
                    that.hideTip('请告诉我们您资源的面积');
                    return false;
                }else{
                    if(xwznUtility.regExp.float.test(area)){
                        var area = parseInt(area);
                        //屋顶
                        if('-1' == $.inArray(unitValue,arrLand)){
                            if(300000 < area || 0 > area){
                                that.hideTip('面积为0~300000平方米');
                                return false;
                            }
                        }else{//土地
                            if(30000 < area || 0 > area){
                                that.hideTip('面积为0~30000亩');
                                return false;
                            }
                        }
                    }else{
                        that.hideTip('请输入有效的面积');
                        return false;
                    }
                }
                //屋顶类型
                if('-1' == $.inArray(unitValue,arrLand)){
                    //建成时间
                    if('' == $.trim($("input[name='pro[project_built_date]']").val())){
                        that.hideTip('请选择资源的建成时间');
                        return false;
                    }
                }else{//地面类型
                    //土地性质
                    if('' == $.trim($("input[name='pro[project_land_nature]']").val())){
                        that.hideTip('请选择土地性质');
                        return false;
                    }
                }
                //所发电力自发自用比例
                if('' == $.trim($("input[name='pro[project_area_proportion]']").val())){
                    that.hideTip('请选择所发电力自发自用比例');
                    return false;
                }
                //备案公司
                if('1' == $("input[name='pro[project_is_record]']").val() && '' == $.trim($("input[name='pro[project_record_name]']").val())){
                    that.hideTip('请输入备案公司名称');
                    return false;
                }
                return true;
            },
            step3:function(){
                //项目名称  兼容电站修改
                var $proName = $("input[name='pro[project_name]']");
                if($proName.length && '' == $.trim($proName.val())){
                    that.hideTip('别忘了给您的项目起个名字哦');
                    return false;
                }
                //项目名称
                if('' == $.trim($("input[name='pro[project_category]']").val())){
                    that.hideTip('请选择需求类型');
                    return false;
                }
                return true;
            }
        }
    },
    //点击图片上传
    uploadImg: function(){
        var that = this;
        $('body').on('click', '.per-upload img', function(){
            var $this = $(this);
            var $parent = $this.parent();
            //如果未上传图片
            if($this.attr('src') == $this.attr('oldsrc') && !$this.attr('src').match(/^http/i)){
                var index = $parent.index();
                $('.upload').attr('forIndex',index);
                $("#Filedata").trigger('click');
            }
        });
        //删除图片
        $('.per-upload').on('click','.btn-del',function(){
            var $this = $(this);
            var $popup = $(".cd-popup");
            if($popup.length){
                $popup.addClass("is-visible");
                var $ctn = $popup.find(".content-detail");
            	$popup.addClass("is-visible");
            	if( $ctn.height()<100 ) {
            		$ctn.height(100);
            	}
                //取消
                $popup.off('click','.J_cancel').on('click','.J_cancel',function(){
                    var $btn = $(this);
                    $btn.closest(".cd-popup").removeClass("is-visible");
                });
                //确认
                $popup.off('click','.J_confirm').on('click','.J_confirm',function(){
                    var $img = $this.siblings('img');
                    $img.attr('src',$img.attr('oldsrc'));
                    //隐藏域置空
                    $('#img'+$this.parent().index()).val('');
                    $this.remove();
                    var $btn = $(this);
                    $btn.closest(".cd-popup").removeClass("is-visible");
                });
            }
        });
        // 图片上传时的点击事件
        $("body").on("change", "input[type='file']", function () {
            fileSize = this.files[0].size/1000;
            if(fileSize > 1024*10){
                that.hideTip('图片不得超过10M');
            }else{
                that.hideTip('上传中...',1);
            }
            if('undefind' != $('.upload').attr('forIndex')) {
                $(".upload").trigger('touchend');
            }
        });
        $(".upload").upload({
            uploadUrl: config.apiServerUrl + "/image/upload.json",
            uploadData: '',
            successFn: "success",
            deleteData: {
                id: function () {
                    return "asdfasdf"
                }
            }
        });
    },
    //弹出层 data:显示的文字；showImg:是否显示等待符
    hideTip: function(data,showImg){
        if(timer){
            clearTimeout(timer);
        }
        $loading.css("display","block");
        if(showImg){
            $mask.css('position','fixed').show();
            $loading.children('img').show();
        }else{
            $mask.hide();
            $loading.children('img').hide();
        }
        $loading.children("span").text(data);
        if(!showImg) {
            timer = setTimeout(function(){
                $loading.css("display","none");
            },2000);
        }
    },
    //删除文本框内容
    deleteInputText: function(){
        var $inputs = $('.btn-del01').prev();
        $inputs.each(function(index,element){
            var $this = $(element);
            var timer = null;
            var $thisDel = $this.next('.btn-del01');
            $this.focus(function(){
                if('' == $.trim($this.val())){
                    if(timer){
                        clearTimeout(timer);
                    }
                    $thisDel.hide();
                }else{
                    if(timer){
                        clearTimeout(timer);
                    }
                    $thisDel.show();
                }
            }).blur(function(){
                timer = setTimeout(function(){
                    $thisDel.hide();
                    timer = null;
                },3000);
            });
            //监控变化
            $this[0].oninput = function(){
                if('' == $.trim($this.val())){
                    $thisDel.hide();
                }else{
                    $thisDel.show();
                }
            };
        });
        //清除text中的文字
        $('.btn-del01').click(function(){
            var $this = $(this);
            var $input = $this.prev();
            $input.val('').focus();
        });
    },
    //获取当前项目信息
    getProjectInfo: function(callback){
        var that = this;
        var proId = getQueryString('id');
        var userId = getQueryString('userId');
        if(userId && proId && (0 < proId)){
            jqueryAjaxGetJsonp(config.gfServerUrl + '/proinfo/info',getCheckParams(userId,'paramsStr') + '&id=' + proId + '&version=' + config.interfaceVersion,function(result){
                if(result.code == 2000){
                    if(callback && 'function' == typeof callback){
                        callback(result);
                    }
                }else{
                    that.hideTip(result.msg);
                }
            },function(){
                that.hideTip('网络问题，请稍后再试！');
            });
        }else{
            that.hideTip('参数错误！');
        }
    },
    //处理不规则图片，显示一致
    dealImg: function(imgUrl,$container){
        var img = new Image();
        img.src = imgUrl;
        img.onload = function(){
            var imgWidth = img.naturalWidth;
            var imgHeight = img.naturalHeight;
            if(imgWidth > imgHeight){
                $container.find("img").css({
                    "width":"auto",
                    "height":$('.upload-imgs').width()*0.3 + 'px'
                });
            }else{
                $container.css({
                    "height":$('.upload-imgs').width()*0.3 + 'px',
                    "overflow":"hidden"
                });
            }
        };
    },
    //编辑电站：下拉数据初始化：资源类型、建成时间、所发电力自发自用比例
    setSelectedValue: function(domId,value){
        var $dom = $('#'+domId);
        $dom.find('ul.fixed-option-ul li[value=' + value +']').trigger('click');
        $dom.find('.fixed-option-ok').trigger('click');
    },
    //编辑电站，设置select选初始定位
    setSelectedPosition: function($selector){
        $selector.parent('[id]').show();
        var $selected = $selector.find('li.selected');
        //var singleHeight = $selected.outerHeight();
        //var top = $selected.offset().top - $selector.offset().top;
        //var pt = parseInt($selector.css('padding-top').match(/^\d+(.\d+)?/)[0]);
        //$selector.scrollTop(top-singleHeight-pt);
        //var iscroll = $selector['iscroll'];console.log(iscroll);
        //if(iscroll){
        //    //iscroll.refresh();
        //    console.log($selected);
        //    iscroll.scrollToElement($selected[0],100);
        //}

    },
    //隐藏下拉框
    hideSelectOption: function(showId){
        $('.fixed-option:visible').each(function(index,element){
            if(!(showId && showId == $(element).attr('id'))){
                $(element).find('.fixed-option-cancel').trigger('click');
            }
        });
    },
    //H5 postMessage
    receiveMessage: function (e) {
        var data = e.data;
        if(data=="returnMapVal") {
            returnMapVal() ;
        }
    },
    postMessage: function(){
        var that = this;
        //使用html5 的postMessage必须处理的
        if (typeof window.addEventListener != 'undefined') {
            window.addEventListener('message', that.receiveMessage, false);
        } else if (typeof window.attachEvent != 'undefined') {
            window.attachEvent('onmessage', that.receiveMessage);
        }
    }
}
//手动选择省市区--返回值
function returnAreaVal (val) {
    $("#regionSel").addClass("uhide");
    // 如果当前页面有滚动条，则处理这行
    $("body").css("overflow-y", "auto");
    $("form#applyForm").show();
    var regionSelResult = eval("("+val+")");
    //regionSelResult = { "province": {"id":"", "name":""}, "city": {"id":"", "name":""}, "area": {"id":"", "name":""} }

    // TODO 用户自己的业务逻辑处理... ...
    var selCnt;
    if( regionSelResult["province"].name ) selCnt = '—' + regionSelResult["province"].name;
    if( regionSelResult["city"].name ) selCnt += '—' + regionSelResult["city"].name;
    if( regionSelResult["area"].name ) selCnt += '—' + regionSelResult["area"].name;

    var addClassName = 'dark-color';
    var $address = $("#address-h");
    if( selCnt ) {
        selCnt = selCnt;
        $address.addClass(addClassName);
    } else {
        selCnt = "您没有做任何选择";
        $address.removeClass(addClassName);
    }
    $address.html(selCnt.substring(1,selCnt.length));
    $('#province').val(regionSelResult["province"].id);
    $('#city').val(regionSelResult["city"].id);
    $('#area').val(regionSelResult["area"].id);
}
//地图返回值
function returnMapVal(val) {
    $("#mapSel").addClass("uhide");
    // 如果当前页面有滚动条，则处理这行
    $("body").css("overflow-y", "auto");
    $("form#applyForm").show();
    var mapSelResult = eval("("+val+")");
    //mapSelResult = { "province": "省份", "city": "城市", "area": "地区", "detail": "具体街道", "fulladdress": "","areaCode":"区的code"}
    var selCnt = mapSelResult["province"]+ ' ' + mapSelResult["city"]+ ' '+mapSelResult["area"];
    var $provice = $('#province');
    var $city = $('#city');
    var $area = $("#area");
    var reset = 0;
    //匹配code
    if(mapSelResult["province"] && mapSelResult["city"] && mapSelResult["area"]){
        var addClassName = 'dark-color';
        var $address = $("#address-h");
        var region = mapSelResult["province"] + ',' + mapSelResult["city"] + ',' + mapSelResult["area"];
        jqueryAjaxGetJsonp(config.gfServerUrl + '/proinfo/region',getCheckParams(getQueryString('userId'),'paramsStr') + '&region=' + region + '&version=' + config.interfaceVersion, function (result) {
            if (result.code == 2000) {
                var datas = result.data;
                if(datas && datas.length > 0){
                    var selCnt = '';
                    $.each(datas,function(index,element){
                        if(0 == index){
                            $provice.val(element.region_id);
                        }else if(1 == index){
                            $city.val(element.region_id);
                        }else if(2 == index){
                            $area.val(element.region_id);
                        }
                        selCnt += element.region_name + '—';
                    });
                    $address.html(selCnt.substring(0,selCnt.length-1)).addClass(addClassName);
                }else{
                    //cod值置空
                    $provice.val("");
                    $city.val("");
                    $area.val("");
                    $address.html('请您手动选择').removeClass(addClassName);
                }
            } else {
                //cod值置空
                $provice.val("");
                $city.val("");
                $area.val("");
                $address.html('请您手动选择').removeClass(addClassName);
            }
        },function(){
            //cod值置空
            $provice.val("");
            $city.val("");
            $area.val("");
            $address.html('请您手动选择').removeClass(addClassName);
        });
    }else{
        if(!$.trim(selCnt)){
            $address.html('您没有做任何选择').removeClass(addClassName);
            //cod值置空
            $provice.val("");
            $city.val("");
            $area.val("");
        }else{
            $address.html('请您手动选择').removeClass(addClassName);
            //cod值置空
            $provice.val("");
            $city.val("");
            $area.val("");
        }
    }
    $("input[name='pro[project_address]']").val(mapSelResult["detail"]);
}
//上传成功
function success(response, statusText, xhr, $this) {
    var that = applyStation;
    that.hideTip('上传成功');
    if( statusText=='success' ) {
        var index = $('.upload').attr('forIndex');
        //操作对应的图片容器
        var $container = $('.per-upload').eq(index);
        $container.find('img').attr("src", response.data.url);
        $container.append('<div class="btn-del" onclick="">&times;</div>');
        //隐藏域赋值
        $('#img'+index).val(response.data.path);
        $('.upload').removeAttr('forIndex');
        //处理不规则图片，显示一致
        that.dealImg(response.data.url,$container);
    }
}
//上传失败
function error(response, statusText, xhr, $this){
    applyStation.hideTip('上传失败');
}
//页面加载完成，执行初始化方法
$(function(){
    var that = applyStation;
    //setTimeout(function(){
    //    $('.fixed-option-c').each(function(index,element){
    //        $(element).attr('data-iscroll',new iScroll(element));
    //    });
    //}, 200)
    //项目id
    var id = getQueryString('id');
    if(id && 0 < parseInt(id)){
        that.initModify();
    }else{
        that.init();
    }
    $('.steps input[type=text],.steps input[type=number]').focus(function(){
        //设置按钮在最底层
        $('.steps:visible .btn-block').removeClass('page-bottom');
    }).blur(function(){
        that.judgePageHeight();
    });
    //$('html').bind("touchmove",function(e){
    //    e.preventDefault();
    //});
    //$('html').bind("touchmove",function(e){
    //    e.stopPropagation();
    //});
    document.addEventListener('touchmove', function (e) { e.preventDefault(); });
    document.removeEventListener('touchmove',true);
    document.addEventListener('touchmove', function (e) { });
});