if( fr=="spick" ) {
	$("body").append("<script type='text/javascript' src='../../static/js/WebViewJavascriptBridge.js'></script>");
	$("body").append("<script type='text/javascript' src='../../static/js/jsBridgeApp.js'></script>");
	var titleObj = {
		"title": document.title, 
		"leftIcon":"goBack", 
		"rightIcon":[]
	};
	callSetAppTitle( titleObj );
}
// 头部左上角的返回图标
function goLastPage() {
	var jumpPage = "my-station";
	if( lastPage ) {
		jumpPage = lastPage;
	}
	location.href = jumpPage+".html?userId="+userId+"&fr="+fr+"&status="+statusType;
}
//驳回状态下，点击编辑，跳转到的页面
function jumpTo( step ) {
	location.href = "modify-step"+step+".html?userId="+userId+"&id="+id+"&fr="+fr;
}
// 项目被驳回时，编辑之后的点击提交事件
function submitProject() {
	var url = config.gfServerUrl+"/project/add";
	var paramsStr = "id="+id+"&pro[status]=2&pro[project_id]="+id;
	paramsStr += "&"+getCheckParams( userId, "paramsStr" );
	jqueryAjaxGetJsonp(url, paramsStr, function(result) {
		if( result.code==2000 ) {
			removeStorageData("xwznProjectEdit-"+id);
			//window.location.reload();
			location.href = "my-station.html?userId="+userId+"&fr="+fr+"&status="+statusType;
		}
	});
}
// 异步加载页面详细数据
function loadPageData() {
	var url = config.gfServerUrl+"/proinfo/info";
	var paramsStr = "id="+id;
	paramsStr += "&"+getCheckParams( userId, "paramsStr" );
	jqueryAjaxGetJsonp(url, paramsStr, function(result) {
		if( result.code==2000 ) {
			var datas = result.data;
			
			$("#time").html( "提交时间 : "+datas["create_time"] );
			var status = datas["status"];
			var statusIcon = getStationTextWithValue(status, "statusIcon");
			var statusText = getStationTextWithValue(status, "status");
			var statusTextStyle = getStationTextWithValue(status, "statusTextStyle");
			var statusBlockStr = '<img src="'+statusIcon+'" /><em>状态 : </em><span class="'+statusTextStyle+'">'+statusText+'</span>';
			$("#statusBlock").html( statusBlockStr );
			
			$("#number").html( datas["project_number"] );
			$("#name").html( datas["project_name"] );
			
			var provinceName = datas["project_province_name"];
			var cityName = datas["project_city_name"];
			var addrStr = provinceName;
			if( provinceName!==cityName ) { // 判断是否为直辖市
				addrStr += cityName;
			}
			addrStr += datas["project_county_name"]+datas["project_address"];
			$("#address").html( addrStr );
			
			var stage = datas["project_stage"];
			var stageText = getStationTextWithValue(stage, "projectStage");
			$("#stage").html( stageText );
			
			var imgArr = datas["project_img"];
			var imgsLen = imgArr.length;
			//imgsLen = imgsLen>6?6:imgsLen; // 最多取6张图片展示
			imgsLen = imgsLen>3?3:imgsLen;
			var lineImgNum = 3;//imgsLen==4?2:3;// 默认每行展示图片数量。如果图片是4张，那么每行展示2张，否则每行展示3张
			var imgsStr = "";
			for(var i=0; i<imgsLen; i++) {
				imgsStr += i%lineImgNum==0?'<div>':'';
				imgsStr += '<img src="'+imgArr[i][1]+'">';
				//imgsStr += '<img src="../../static/images/apply/pic_02.jpg">';
				imgsStr += i%lineImgNum==2?'</div>':'';
			}
			$(".project-img").html( imgsStr );
			
			var projectType = datas["project_type"];
			if( projectType==4 || projectType==5 ) {
				$(".type2-data").removeClass("uhide");
				//“屋顶面积”改为“资源面积”
				$('#projectProportion').siblings('label').text('资源面积');
			} else {
				$(".type1-data").removeClass("uhide");
			}
			$("#projectType").html( getStationTextWithValue( projectType, "projectType") );
			$("#projectProportion").html( datas["project_proportion"] );
			$("#projectMaterial").html( getStationTextWithValue( datas["project_material"], "projectMaterial") );
			$("#projectBuildDate").html( datas["project_built_date"] );
			$("#projectLandNature").html( getStationTextWithValue( datas["project_land_nature"], "projectLandNature") );
			
			$("#projectAreaProportion").html( getStationTextWithValue( datas["project_area_proportion"], "projectAreaProportion") );
			$("#projectRecord").html( getStationTextWithValue( datas["project_is_record"], "yesOrNo") );
			if( datas["project_is_record"]==1 ) { // 已经备案，则展示备案名称
    			$("#projectRecordName").html( datas["project_record_name"] );
    			$("#recordName").removeClass("uhide");
			}
			$("#projectAccess").html( getStationTextWithValue( datas["project_is_access"], "yesOrNo") );
			$("#projectRent").html( getStationTextWithValue( datas["project_is_rent"], "yesOrNo") );
			$("#projectPublic").html( getStationTextWithValue( datas["project_is_public"], "yesOrNo") );
			
			$("#projectCategory").html( getStationTextWithValue( datas["project_category"], "projectCategory") );
			$("#projectDesc").html( datas["project_desc"] );
			
			if( status==3 ) { // 被拒绝状态
				var rejectResion = datas["reject_resion"]?datas["reject_resion"]:"";
				$(".cause-overr").find("p").html( rejectResion );
				$(".overrule-cont, .overruel-img, .btn-block").removeClass("uhide");
				$(".kf").addClass("uhide");
				// 底部提交按钮的状态控制
				var editFlag = loadStorageData("xwznProjectEdit-"+id);
				if( "save"==editFlag ) {
					$("#submitBtn").removeClass("no-oper").addClass("btn-l-bg");
					$("body").on("click", "#submitBtn", function() { submitProject(); });
				} else {
					$("#submitBtn").removeClass("btn-l-bg").addClass("no-oper");
				}
			}
		}
	});
}
// 根据接口返回的value值，在配置文件中查询对应的text中文内容
function getStationTextWithValue( value, configKey ) {
	var rtnText="", text;
	if(value) {
		var valuesArr = value.split(",");
		for(var i=0; i<valuesArr.length; i++) {
			var text = stationDatasConfig.pageConfig[configKey][ valuesArr[i] ];
			if( !text ) { text = stationDatasConfig.pageConfig[configKey]["default"]; }
			rtnText += rtnText?","+text:text;
		}
	}
	return rtnText;
}

$(function() {
	loadPageData();
});

