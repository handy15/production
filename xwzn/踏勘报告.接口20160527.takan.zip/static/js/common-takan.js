/**
 * 
 * @param step 当前是第几大步骤
 * @param currentDetailStep 大步骤里面的第几小步骤，此为显示的步骤
 * @param roofType 屋顶类型
 * @param material 屋顶材质
 * @returns
 * {showTotal:右下角展示的总步骤数, showCurrent:右下角展示当前步骤数, showNext:右下角下一步步骤数, 
 *  lastStepId: 页面中上一步对应的块,curStepId:页面里定义展示的第几个块, nextStepId:页面里定义的下一步是第几块展示}
 * 例：
 * 页面中的定义：
 * <div step="1" class="hide"></div>
 * <div step="2" class="">！当前显示的步骤！</div>
 * <div step="3" class="hide">个人屋顶不显示此块</div>
 * <div step="4" class="hide"></div>
 * <div step="5" class="hide"></div>
 * <div step="6" class="hide"></div>
 * <div step="7" class="hide">瓦屋面、其他屋顶不显示此块</div>
 * <div step="8" class="hide"></div>
 * <div step="9" class="hide">瓦屋面、其他屋顶不显示此块</div>
 * 
 * getStepInfo(3, 2, 3, 4) --> {showTotal: 6, showCurrent:2, showNext: 3, curStepId: 2, nextStepId: 4}
 * 于是页面如下显示：
 * <div step="1" class="hide"></div>
 * <div step="2" class="hide">！当前显示的步骤！</div>
 * <div step="3" class="hide">个人屋顶不显示此块</div>
 * <div step="4" class="">！下一步时，我就显示了！</div>
 * <div step="5" class="hide"></div>
 * <div step="6" class="hide"></div>
 * <div step="7" class="hide">瓦屋面、其他屋顶不显示此块</div>
 * <div step="8" class="hide"></div>
 * <div step="9" class="hide">瓦屋面、其他屋顶不显示此块</div>
 */
function getTakanStepInfo( step, currentDetailStep, roofType, material ) {
	var detailStepNum = parseInt(currentDetailStep);
	
	var totalPage = 1;//页面中显示的分母页数：   分子 / 分母
	var showNext = 1;//页面中显示下一页的分子页数：   分子 / 分母
	
	var lastStep = 1;//根据页面显示的分子页数，获得页面中上一步应该显示的DIV或UL对应的数值
	var curStep = 1;//根据页面显示的分子页数，获得页面中当前显示的DIV或UL对应的数值
	var nextPage = 1;//页面中定义的DIV、UL第几块数值
	
	if( step==1 ) {
		totalPage = 1;
	} else if( step==2 ) {
		totalPage = 3;
	} else if( step==4 ) {
		totalPage = roofType==3?1:2;//个人屋顶，没有配电室信息页
	} else if( step==5 ) {
		totalPage = 4;
	} else if( step==6 ) {
		totalPage = 1;
	}
	if( totalPage>1 ) {
		detailStepNum = detailStepNum>totalPage?totalPage:detailStepNum;
		curStep = detailStepNum;
		lastStep = curStep>1?curStep-1:1;
		nextPage = curStep+1>totalPage?totalPage:curStep+1;
		showNext = nextPage;
	}
	
	if(step==3) {
		//个人屋顶展示：1、2、4、5、6、7、8、9
		//瓦屋面、其他材质屋顶展示：1、2、3、4、5、6、8
		totalPage = 9;
		detailStepNum = detailStepNum>totalPage?totalPage:detailStepNum;
		curStep = detailStepNum;
		lastStep = curStep>1?curStep-1:1;
		
		var flag1=false, flag2=false;
		if( roofType==3 ) { //个人屋顶
			totalPage = totalPage-1; //个人屋顶，没有第3小步，所以步数-1
			curStep = detailStepNum>=3?detailStepNum+1:detailStepNum;
			lastStep = curStep>1?curStep==4?curStep-2:curStep-1:1;
			nextPage = curStep==2?4:curStep+1;
			flag1 = true;
		}
		if( material==4||material==5 ) {//瓦屋面、其他
			totalPage = totalPage-2;  //瓦屋面、其他，没有第7、9小步，所以步数-2
			if( roofType==3 ) {
				curStep = flag1?curStep:detailStepNum>=3?detailStepNum+1:detailStepNum;
				curStep = curStep>=6?curStep+1:curStep;
				lastStep = curStep>1?curStep==4||curStep==8?curStep-2:curStep-1:1;
			} else {
				curStep = detailStepNum>=7?detailStepNum+1:detailStepNum;
				lastStep = curStep>1?curStep==8?curStep-2:curStep-1:1;
			}
			nextPage = flag1?nextPage:curStep+1;
			nextPage = nextPage==7?8:nextPage;
			flag2 = true;
		}
		showNext = detailStepNum+1>totalPage?totalPage:detailStepNum+1;
		if( !flag1&&!flag2 ) {
			nextPage = showNext;
		}
		if( flag2 ) {
			curStep = curStep>=9?8:curStep; // 因为第9步不会展示，所以做此判断
			nextPage = nextPage>=9?8:nextPage; // 因为第9步不会展示，所以做此判断
		}
	}
	return {showTotal: totalPage, showCurrent: detailStepNum, showNext: showNext, lastStepId:lastStep, curStepId: curStep, nextStepId: nextPage};
}


//踏勘的公共组件
var takanUtility = takanUtility || {};
$.extend(takanUtility, {
	/**
	 * 弹出层对话框
	 * @param opts{
	 * 		pop:弹出层的jquery对象,
	 * 		cancelCallback:“取消”的回调函数,
	 * 		confirmCallback:“确定”的回调函数,
	 * 		closeCallback:“关闭”按钮的回调函数
	 * }
	 */
	confirm: function (opts) {
		var options = $.extend({
			popObj: $('.cd-popup:first'),
			cancelCallback: function(){},
			confirmCallback: function(){},
			closeCallback: function(){}
		},opts);
		var $popup = options.popObj;
		if($popup.length){
			$popup.addClass("is-visible");
			var $ctn = $popup.find(".content-detail");
			if( $ctn.height()<100 ) {
				$ctn.height(100);
			}
			var $container = $popup.find(".cd-popup-container");
			if( $container.width()>350 ) {
				$container.width(350);
			}
			//取消
			$popup.off('click','.J_cancel').on('click','.J_cancel',function(){
				var $btn = $(this);
				$btn.closest(".cd-popup").removeClass("is-visible");
				//回调函数
				if(typeof options.cancelCallback == 'function'){
					options.cancelCallback();
				}
			});
			//确认
			$popup.off('click','.J_confirm').on('click','.J_confirm',function(){
				var $btn = $(this);
				$btn.closest(".cd-popup").removeClass("is-visible");
				if(typeof options.confirmCallback == 'function'){
					options.confirmCallback();
				}
			});
			//关闭按钮
			$popup.off('click','.cd-popup-close').on('click','.cd-popup-close',function(){
				var $btn = $(this);
				$btn.closest(".cd-popup").removeClass("is-visible");
				//回调函数
				if(typeof options.closeCallback == 'function'){
					options.closeCallback();
				}
			});
		}
	}
});

