﻿var stationDatasConfig= {
	//项目阶段
	projectStep: [
		{"id": "1", "name": "前期"},
		{"id": "2", "name": "已备案"},
		{"id": "3", "name": "在建"},
		{"id": "4", "name": "已建未并网"},
		{"id": "5", "name": "已并网"},
		{"id": "6", "name": "商转超过3个月"}
	]
	//项目类别
	, projectType: [
		{"id": "1", "name": "工业屋顶"},
		{"id": "2", "name": "商业屋顶"},
		{"id": "3", "name": "个人屋顶"},
		{"id": "4", "name": "闲置地面"},
		{"id": "5", "name": "其他资源"}
	]
	//屋顶材质
	, roofMaterial: [
		{"id": "1", "name": "钢筋混凝土"},
		{"id": "2", "name": "彩钢瓦屋顶"},
		{"id": "3", "name": "瓦屋面"}
	]
	//项目所发电力自发自用比例（%）
	, powerUse: [
		{"id": "1", "name": "全额上网"},
		{"id": "2", "name": "25%"},
		{"id": "3", "name": "50%"},
		{"id": "4", "name": "75%"},
		{"id": "5", "name": "100%"}
	]
	//土地性质
	, landNature: [
		{"id": "1", "name": "农业用地非基本农田"},
		{"id": "2", "name": "林业用地非生态公益林"},
		{"id": "3", "name": "工业用地"},
		{"id": "4", "name": "国有未利用地"},
		{"id": "5", "name": "基本农田"},
		{"id": "6", "name": "生态林"}
	]
	//需求类型
	, reqrType: [
		{"id": "1", "name": "开发咨询"},
		{"id": "2", "name": "融资合作"},
		{"id": "3", "name": "项目设计"},
		{"id": "4", "name": "现场踏勘"},
		{"id": "5", "name": "光伏施工"},
		{"id": "6", "name": "监理监造"},
		{"id": "7", "name": "项目验收"},
		{"id": "8", "name": "运维测评"},
		{"id": "9", "name": "尽调评估"},
		{"id": "10", "name": "光伏设备"}
	]
	//项目状态
	, projectStatus: [
		{"id": "2", "name": "待审核"},
		{"id": "4", "name": "已审核"},
		{"id": "3", "name": "已驳回"},
		{"id": "5", "name": "已终止"}
	]
	// 开始年份：1980-01-01
	, startTime: { year: 1980, month: 1, day: 1 }
	
	/**
	 * 2016-04-07 CUIGC
	 * 申请建电站：页面对应的内容数据展示配置
	 * status 配置来自于后台API接口文档
	 * statusTextStyle 状态在页面中的展示样式，内容在css文件里
	 * statusIcon 不同状态的数据，icon图标使用的图片配置，与状态有对应关系
	 * nodataHtml 我的电站列表页，如果没有数据时，展示的提示信息
	 */ 
	, pageConfig: {
		status: { "0": "未提交", "1": "已提交", "2": "待审核", "3": "已驳回", "4": "已审核", "5": "已终止" },
		statusTextStyle: {"default": "stateSpan1", "3": "stateSpan3", "4": "stateSpan4", "5": "stateSpan5"},
		statusIcon: {
			"default": "../../static/images/station/icon-status-nocheck.png", 
			"3": "../../static/images/station/icon-status-reject.png", 
			"4": "../../static/images/station/icon-status-checkok.png", 
			"5": "../../static/images/station/icon-status-stop.png" 
		},
		nodataHtml: {
			"default": "<label>没有</label>申请过任何电站哦",
			"2": "<label>没有</label>需要审核的电站哦", 
			"3": "<label>没有</label>申请的电站被驳回哦", 
			"4": "<label>没有</label>申请的电站被通过哦", 
			"5": "<label>没有</label>申请的电站被终止哦" 
		},
		projectStage: {"default":"未知", "1":"前期", "2":"已备案", "3":"在建", "4":"已建未并网", "5":"已并网", "6":"商转超过三个月"},
		projectType: {"default":"未知", "1":"工业屋顶", "2":"商业屋顶", "3":"个人屋顶", "4":"地面资源", "5":"其他资源"},
		projectMaterial: {"default":"未知", "1":"钢筋混凝土", "2":"彩钢瓦屋顶", "3":"瓦屋面"},
		projectLandNature: {"default":"未知", "1":"农业用地非基本农田", "2":"林业用地非生态公益林", "3":"工业用地", "4":"国有未利用地", "5":"基本农田", "6":"生态林"},
		projectAreaProportion: {"default":"未知", "1":"全额上网", "2":"25%", "3":"50%", "4":"75%", "5":"100%"},
		projectCategory: {"default":"未知", "1":"开发咨询", "2":"融资合作", "3":"项目设计", "4":"现场踏勘", "5":"光伏施工", "6":"监理监造", "7":"项目验收", "8":"运维测评", "9":"尽调评估", "10":"光伏设备"},
		yesOrNo: {"default":"未知", "0":"否", "1":"是"}
	}
	/**
	 * 2016-04-27 CUIGC
	 * 踏勘报告：页面对应的内容数据展示配置
	 */
	, takanConfig: {
		steps: {
			stepNum:6, 
			detail:[
				{ "stepId": "1", "stepName": "报告命名与基本信息", "stepPage": "step1.html"},
				{ "stepId": "2", "stepName": "与屋顶主沟通的信息", "stepPage": "step2.html"},
				{ "stepId": "3", "stepName": "屋顶360度详细信息", "stepPage": "step3.html"},
				{ "stepId": "4", "stepName": "配电电气相关信息", "stepPage": "step4.html"},
				{ "stepId": "5", "stepName": "图纸收集信息", "stepPage": "step5.html"},
				{ "stepId": "6", "stepName": "我的踏勘总结", "stepPage": "step6.html"}
			]
		},
		type: {"default":"未知", "1":"工业屋顶", "2":"商业屋顶", "3":"个人屋顶"},
		material: {"default":"未知", "1":"现浇混凝土", "2":"预制混凝土", "3":"彩钢瓦", "4":"瓦屋面", "5":"其他"},
		materialSub: {
			"1":{"1":"女儿墙","2":"电梯间或楼梯间","4":"通风设备","5":"屋面管道","6":"其他"},
			"2":{"1":"女儿墙","2":"电梯间或楼梯间","4":"通风设备","5":"屋面管道","6":"其他"},
			"3":{"1":"女儿墙","3":"采光带","4":"通风设备","6":"其他"}
		},
		yesOrNo: {"default":"未知", "0":"否", "1":"是"},
		investment:{"default":"未知", "1":"自己投资", "2":"找人投资", "3":"部分投资"},
		electricCharge:{"default":"未知", "1":"正常", "2":"趸售用电"},
		//电压
		voltage: {"default":"未知", "0.22":"0.22kV", "0.38":"0.38kV", "10":"10kV", "20":"20kV", "35":"35kV", "110":"110kV"},
		//屋面坡度
		gradient: {"default":"未知", "3°":"3°", "5°":"5°", "8°":"8°", "10°":"10°", "12°":"12°", "15°":"15°", "15°以上":"15°以上"}
	}
}