/**
 * 使用webViewJavascriptBridge组件实现JS和APP之间的交互
 * !!!注!!!
 * 1. H5文件中引入WebViewJavascriptBridge.js这个文件
 * Author: CUIGC
 * Date: 2016-04-13
 */
// ---------------------------------------------------------------------------------------------------
/**
 * 定义Bridge桥连接状态的监听
 * @param callback 监听连接成功后，回调的函数
 */
function connectWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) {
        callback(WebViewJavascriptBridge);
    } else {
        document.addEventListener( "WebViewJavascriptBridgeReady", function() { callback(WebViewJavascriptBridge); }, false);
    }
}
connectWebViewJavascriptBridge(function(bridge) {
	// bridge桥初始化
	bridge.init(function(message, responseCallback) {
		if (responseCallback) { responseCallback(message); }
	});
	
	// ------------------------------------ JS自定义函数，供APP调用 ----------------------------------------
	bridge.registerHandler("functionInJs", function(data, responseCallback) { responseCallback(data); });
	
	/**
	 * 左侧返回按钮的点击事件方法注册
	 * @param String data H5页面中，点击左侧图标时回调H5的方法名
	 */
	bridge.registerHandler("leftIconOper", function( data ) {
		data = data?data:"judgeLeftIcon";
		var funcName = eval(data);
		if( typeof funcName=="function" ) {
			funcName();
		}
	});
	/**
	 * 右侧自定义内容点击事件时的回调
	 * @param String data H5页面中，点击右侧自定义内容时回调H5的方法名
	 */
	bridge.registerHandler("callbackH5", function( data ) {
		data = data?data:"callbackH5";
		var funcName = eval(data);
		if( typeof funcName=="function" ) {
			funcName();
		}
	});
	/**
	 * 分享功能交互的方法注册
	 * @param String data H5页面中，分享内容对象变量的引用
	 */
	bridge.registerHandler("getShareInfoData", function( data, responseCallback ) {
		data = data?data:"shareInfo";  // 如果没有指定分享对象变量引用，则默认使用shareInfo
		responseCallback( eval(data) );
	});
});
/**
 * 调APP注册的分享功能
 * @param shareJsonObj 页面分享的参数信息。
 * 				 格式：{"siteUrl":"分享的出去的页面地址", "title":"分享的标题", "content":"分享的内容说明", "photo":"分享时的图标，如果为空，APP自己选择图标"}
 * returns 返回分享的结果。格式：{"status":"1", "msg":"成功"}
 */
function callShareServer( shareJsonObj ) {
	if( window.WebViewJavascriptBridge ) {
		window.WebViewJavascriptBridge.callHandler("shareServer", shareJsonObj, function(result) {
			if( result.status==1 ) {
				console.log("分享成功！");
			} else {
				console.log("分享失败！失败原因："+result.msg);
			}
		});
	}
}
/**
 * 关闭APP中的WEBVIEW，及关闭H5的页面
 */
function callCloseH5() {
	if( window.WebViewJavascriptBridge ) {
		window.WebViewJavascriptBridge.callHandler("closeH5");
	}
}
/**
 * 关闭APP中的WEBVIEW，及关闭H5的页面
 */
function callAppPhone( phoneStr ) {
	if( window.WebViewJavascriptBridge ) {
		window.WebViewJavascriptBridge.callHandler("callAppPhone", phoneStr);
	}
}
/**
 * author: CUIGUOCHAO
 * add time: 2016-04-19
 * 
 * 设置APP头部内容的方法
 * 
 * @param jsonObj 头部内容描述对象。
 * 	格式：
 * {"title":"标题", 
 *  "leftIcon":"回调的JS方法名，如果不传，webview自动go(-1)", 
 *  "rightIcon": [ {"icon":"显示的图标地址", "content":"内容描述，具体见下方说明"} ]
 *  }
 * 目前右侧rightIcon->icon图标出现的几种：
 * share：分享功能。具体APP点击分享时，会调H5自己注册的分享方法。参数格式：share#分享内容的对象引用("shareInfo")
 * qrCode：跳转到APP的用户二维码页面
 * cityname：地区选择功能。参数格式：cityname#全国#地区选择的url(http://we.solarbao.com/maker/tools/regionSelect.html?paramKey=paramValue)
 * collect：收藏功能。参数格式：collect#收藏状态(1收藏；0未收藏)#页面数据ID#页面数据类型(n新品中心 c活期理财 p光伏政策 l光照资源参数)
 * jumpurl: 跳转到指定页面。参数格式：jumpurl#跳转页面的url地址(http://we.solarbao.com/index.html?paramKey=paramValue)
 * callback: 点击右侧内容时，APP回调H5的方法。参数格式：callback#h5MethodName
 */
function callSetAppTitle( jsonObj ) {
	if( window.WebViewJavascriptBridge ) {
		window.WebViewJavascriptBridge.callHandler("setAppTitle", jsonObj, function( responseData ) {});
	}
}
