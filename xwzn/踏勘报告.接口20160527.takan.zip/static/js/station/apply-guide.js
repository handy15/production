if( fr=="spick" ) {
	$("body").append("<script type='text/javascript' src='../../static/js/WebViewJavascriptBridge.js'></script>");
	$("body").append("<script type='text/javascript' src='../../static/js/jsBridgeApp.js'></script>");
	var titleObj = {
		"title": document.title, 
		"leftIcon":"goLastPage", 
		"rightIcon":[ {"icon":config.appServerUrl+"/xwzn/m/static/images/icon-share.png", "content":"share#shareInfo"}]
	};
	callSetAppTitle( titleObj );
}

function shareServer() {
	callShareServer( shareInfo );
}

function jumpTo() {
	location.href = "apply-flow.html?userId="+userId+"&fr="+fr;
}

function loadPageData() {
	var url = config.gfServerUrl+"/project/count";
	var paramsStr = getCheckParams( userId, "paramsStr" );
	jqueryAjaxGetJsonp(url, paramsStr, function(result) {
		if( result.code==2000 ) {
			$("#count").html( result.data.count );
		}
	});
}

$(function() {
	loadPageData();
	if( share==1 ) {
		// 左上角的返回图标隐藏
		$(".left-icon").addClass("uhide");
		$(".apply-btn").remove();
	}
});
