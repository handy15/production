if( fr=="spick" ) {
	//$("body").append("<script type='text/javascript' src='../../static/js/outside_func.js'></script>");
	//var jumpicon = config.appServerUrl+"/xwzn/m/static/images/station/icon-jump.png";
	//var jumppage = config.appServerUrl+"/xwzn/m/template/station/apply-guide.html?userId="+userId+"&fr="+fr;
	//setAppTitleAndDetail( document.title, "jumpurl#"+jumpicon+"#"+jumppage );
	
	$("body").append("<script type='text/javascript' src='../../static/js/WebViewJavascriptBridge.js'></script>");
	$("body").append("<script type='text/javascript' src='../../static/js/jsBridgeApp.js'></script>");
	
	var hrf = location.href;
	hrf = encodeURIComponent(hrf);
	var titleObj = {
		"title": document.title, 
		"leftIcon":"callCloseH5", 
		"rightIcon":[
	        {"icon":config.appServerUrl+"/xwzn/m/static/images/station/icon-jump.png", 
	         "content":"jumpurl#"+config.appServerUrl+"/xwzn/m/template/station/apply-guide.html?userId="+userId+"&fr="+fr+"&rtnPage="+hrf}]
	};
	callSetAppTitle( titleObj );
}

// 4个状态条目item的点击切换功能
// obj表示点击的item； status表示被点击item代表的状态值
function chooseItem( obj, status ) {
	$(".item").removeClass("item-nosplitline");
	$(obj).siblings().removeClass("selected");
	$(obj).addClass("item-nosplitline");
	$(obj).next().addClass("item-nosplitline");
	$(obj).addClass("selected");
	
	jumpTo(status);
}
// 查看电站 图片的跳转
function jumpTo(status) {
	if( !status ) status = "";
	location.href = "my-station.html?userId="+userId+"&status="+status+"&fr="+fr;
}
// 申请电站 图片的跳转
function jumpToApply() {
	location.href = "apply-flow.html?userId="+userId+"&fr="+fr;
}
// 右上角图标点击跳转到向导页
function jumpToGuide() {
	var hrf = location.href;
	hrf = encodeURIComponent(hrf);
	location.href = "apply-guide.html?userId="+userId+"&fr="+fr+"&rtnPage="+hrf;
}

function loadPageData() {
	var url = config.gfServerUrl+"/proinfo/num";
	var paramsStr = getCheckParams( userId, "paramsStr" );
	jqueryAjaxGetJsonp(url, paramsStr, function(result) {
		if( result.code==2000 ) {
			$("#total").html( result.data.total?result.data.total:0 );
			$("#nocheck").html( result.data.nums["2"]?result.data.nums["2"]:0 );
			$("#checked").html( result.data.nums["4"]?result.data.nums["4"]:0 );
			$("#reject").html( result.data.nums["3"]?result.data.nums["3"]:0 );
			$("#stop").html( result.data.nums["5"]?result.data.nums["5"]:0 );
		}
	});
}

$(function() {
	loadPageData();
});
