if( fr=="spick" ) {
	$("body").append("<script type='text/javascript' src='../../static/js/WebViewJavascriptBridge.js'></script>");
	$("body").append("<script type='text/javascript' src='../../static/js/jsBridgeApp.js'></script>");
	
	var leftIconOper = "goBack";
	if( gn && gn=="app" ) {
		leftIconOper = "callCloseH5";
	} 
	var titleObj = {
		"title": document.title, 
		"leftIcon":leftIconOper, 
		"rightIcon":[]
	};
	callSetAppTitle( titleObj );
}

var page=1, pageSize=10, pageCount;
$(function() {
	//加载更多动态
    window.onscroll = function() {
        if($(".loading-info-success").length>0){
			return;
        }
        var $dH  = $(document).height(),
            $wH  = $(window).height(),
            $top = $(document).scrollTop();
        
        if($dH-$wH-$top<=200&&$(".loading-info").length==0&&$("#list>div").length>0) {
			$("#list").append(template.render("loading-info"));
			loadPageListData();
        }
    }
	
    loadPageListData();
});

// 分页加载当前页面数据
function loadPageListData() {
	var url = config.gfServerUrl+"/project";
	
	var paramsStr = "page="+page+"&size="+pageSize;
	paramsStr += "&"+getCheckParams( userId, "paramsStr" );
	if( statusType ) paramsStr += "&status="+statusType;
	
	jqueryAjaxGetJsonp(url, paramsStr, function(result) {
		if( result.code==2000 ) {
			$(".loading-info").remove(); // 将加载中的显示删除掉
			
			pageCount = result.data.pageCount;
			var datasArr = result.data.list;
			if( pageCount==0 ) { // 第一页返回的数据中数组为0
				$("#hasData").addClass("uhide");
				$("#noData").removeClass("uhide");
				if( !statusType ) statusType = "default";
				$("#noData").find(".status").html( stationDatasConfig.pageConfig.nodataHtml[statusType] );
				
			} else { // 正常有数据返回时
				var stepLiStr, status, statusIcon, statusText, statusTextStyle;
				for(var i=0; i<datasArr.length; i++) {
					
					status = datasArr[i]["status"];
					statusIcon = getStationTextWithValue( status, "statusIcon");
					statusText = getStationTextWithValue( status, "status");
					statusTextStyle = getStationTextWithValue( status, "statusTextStyle");
					
					stepLiStr = '';
					stepLiStr += '<div class="mystation"><div class="line"></div>';
					
					stepLiStr += '<header>';
					stepLiStr += '<div class="submitTime"><span></span><span>提交时间：'+datasArr[i]["create_time"]+'</span></div>';
					stepLiStr += '<div class="state"><img src="'+statusIcon+'"/><em>状态：</em><span class="'+statusTextStyle+'">'+statusText+'</span></div>';
					stepLiStr += '<div class="dashed"></div>';
					stepLiStr += '</header>';
					stepLiStr += '<div class="clear"></div>';
					
					stepLiStr += '<div class="project-brief">';
					stepLiStr += '<ul>';
					stepLiStr += '<li>项目编号：<span>'+datasArr[i]["project_number"]+'</span></li>';
					stepLiStr += '<li>项目名称：<span style="color:#333;">'+datasArr[i]["project_name"]+'</span></li>';
					stepLiStr += '<li>项目地点：<span>'+datasArr[i]["project_address"]+'</span></li>';
					stepLiStr += '<li>项目阶段：<span>'+datasArr[i]["project_stage"]+'</span></li>';
					stepLiStr += '</ul>';
					stepLiStr += '</div>';
					
					stepLiStr += '<div class="seeDetails"><div class="detai-dash">';
					stepLiStr += '<a href="#"><span class="oper-btn" onclick="lookDetail('+datasArr[i]["project_id"]+')">查看详情</span></a>';
					stepLiStr += '<a href="#"><span class="oper-btn special" onclick="lookProcess('+datasArr[i]["project_id"]+')">进度说明</span></a>';
					stepLiStr += '<div class="dash"></div>';
					stepLiStr += '</div></div>';
					
					stepLiStr += '</div>';
					
	        		$("#list").append( stepLiStr );
				}
				
				if( page==pageCount ) { // 加载页数和总页数相同，则没有数据加载了
					$("#list").append(template.render("loading-info-success"));
					return;
				} else {
					page += 1; // 当前页数据加载成功后，页面增加1
				}
				
			}
		}
		
	});
}
//根据接口返回的value值，在配置文件中查询对应的text中文内容
function getStationTextWithValue( value, configKey ) {
	var rtnText="", text;
	if( value ) {
		var valuesArr = value.split(",");
		for(var i=0; i<valuesArr.length; i++) {
			var text = stationDatasConfig.pageConfig[configKey][ valuesArr[i] ];
			if( !text ) { text = stationDatasConfig.pageConfig[configKey]["default"]; }
			rtnText += rtnText?","+text:text;
		}
	}
	return rtnText;
}
// 查看每个条目的详细页面数据
function lookDetail( projectId ) {
	location.href = "detail.html?id="+projectId+"&userId="+userId+"&fr="+fr+"&status="+status+"&lastPage=my-station";
}
// 查看每个条目的进度页面数据
function lookProcess( projectId ) {
	location.href = "process.html?id="+projectId+"&userId="+userId+"&fr="+fr+"&status="+status;
}
