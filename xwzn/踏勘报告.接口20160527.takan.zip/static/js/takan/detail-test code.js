/**
 * Created by wangyaru on 2016/5/20.
 */
var $itemBtn = $(".item-btn"),
    $itemList = $(".item-list"),
    $itemBtnTxt = $itemBtn.find("span"),
    $oMask = $(".mask"),
    $closeBtn = $(".close-btn"),
    $closeBtnTxt = $closeBtn.find("span"),
    $picListW = $(".pic-list li").eq(0).css("width"),
    animateFlag = false,
    //$detailBox = $(".detail-box"),
    //$dotLine = $(".dot-line"),
    //$decorationPicBottom = $(".decoration-pic2"),
    //$decorationPicTop = $(".decoration-pic"),
    $itemDrawing = $(".item-drawing"),//图纸
    $itemTalk = $(".item-talk"),//沟通信息
    $itemRoof = $(".item-roof"),//屋顶
    $itemElectric = $(".item-electric"),//配电
    $basic = $('.item-summary,.item-basic');//基本信息

var operatorCategory = {
    initMask:function(){
        var $documentH = $(document).height();
        $oMask.css("height",$documentH );
    },
    pop:function(){
        if(animateFlag){
            return;
        }
        animateFlag = true;
        $itemList.animate({
            "right":"0%"
        },1000,function(){
            animateFlag = false;
        });
        $oMask.add($closeBtn).css("display","block");
        $itemBtn.css("display","none");
    },
    pullBack:function(){
        if(animateFlag){
            return;
        }
        animateFlag = true;
        $itemBtn.css("display","block");
        $closeBtn.css("display","none");
        $itemList.animate({
            "right":"-100%"
        },1000,function(){
            $oMask.css("display","none");
            animateFlag = false;
        });
    },
    userId: getQueryString('userId'),
    reportId: getQueryString('reportId'),
    init:function(){
        var that = this;
        $(".detail-box:gt(2)").css("display","none");
        //选择步骤
        $itemList.find("ul li").on("click",function(){
            var oIndex = $(this).index();
            //当前状态设置
            $(this).addClass('selected').siblings().removeClass('selected');
            //返回顶部
            $(document).scrollTop(0);
            $closeBtnTxt.add($itemBtnTxt).html((oIndex + 1) + '/' + $itemList.find("ul li").length);
            $(".detail-box:gt(2)").css("display","none");
            $basic.hide();
            if(oIndex == 0){
                var loaded = $basic.eq(0).attr('loaded');
                if(loaded && loaded == '1'){
                    $basic.show();
                }else{
                    //踏勘总结与基本信息异步请求
                    that.ajaxData('base');
                }
            }else if(oIndex == 1){
                var loaded = $itemTalk.eq(0).attr('loaded');
                if(loaded && loaded == '1'){
                    $itemTalk.show();
                }else{
                    //与屋顶主沟通的信息
                    that.ajaxData('talk');
                }
            }else if(oIndex == 2){
                var loaded = $itemRoof.eq(0).attr('loaded');
                if(loaded && loaded == '1'){
                    $itemRoof.show();
                }else{
                    //屋顶360°详细信息
                    that.ajaxData('roof');
                }
            }else if(oIndex == 3){
                var loaded = $itemElectric.eq(0).attr('loaded');
                if(loaded && loaded == '1'){
                    $itemElectric.show();
                }else{
                    //配电电气情况
                    that.ajaxData('electric');
                }
            }else if(oIndex == 4){
                var loaded = $itemDrawing.eq(0).attr('loaded');
                if(loaded && loaded == '1'){
                    $itemDrawing.show();
                }else{
                    //图纸收集情况
                    that.ajaxData('drawing');
                }
            }
        });
        //step定位
        var number = location.href.match(/#step(\d+)$/);
        if(number){
            $itemList.find("ul li").eq(parseInt(number[1])-1).trigger('click');
        }else{
            //踏勘总结与基本信息异步请求
            that.ajaxData('base');
        }
    },
    lookBigPic:function(imgBox,picArr,length,k){
        $("."+ imgBox ).eq(k).find("li img").each(function(i,n){
            var $n = $(n);
            picArr.push($n.attr("src"));
            $n.click(function(){
                var gourl = "./responsive.html?index=" + i + "&length=" + length;
                location.href = gourl;
            })
        })
    },
    /**
     * 初始加载成功，显示必要dom
     * @param data{title:踏勘标题,username:踏勘人}
     */
    showMainDom: function(data){
        var that = this;
        var loaded = $(".title-box").attr('loaded');
        if(!(loaded && loaded == '1')){
            var titleStr = '<div class="detail-box-con"><h3 class="detail-title">'+ (data.title ? data.title : '') +'</h3><p>踏勘人：'+ (data.username ? data.username : '') +'</p></div><img src="../../static/images/takan/icon_07.png" class="report-pic" width="103" alt="踏勘报告" />';
            $(".title-box").html(titleStr).show().attr('loaded','1');
            $(".decoration-pic2,.decoration-pic").show();
            //显示导航
            $('.item-btn').show();
            that.initMask();
        }
    },
    ajaxData:function(ele){
        var that = this;
        if(that.userId && that.reportId){
            jqueryAjaxGetJsonp(config.xwServerUrl + '/ExplorationReport/Detail.json', 'userId=' + that.userId + '&reportId=' + that.reportId + '&step='+ele , function (result) {
                result.code = 2000;
                if(result.code == 2000){
                    if(ele == 'base'){
                        result.data = {
                            "title": "山西太原100000平米工业屋顶",
                            "username": "刘宇",
                            "base": {
                                "roof_type": "2",
                                "roof_typeDes": "商业屋顶",
                                "address": "山西省太原市小店区山西省太原市小店区第一大街39号",
                                "satellitp_picture": "http://img2.solarbao.com/a49fe891_1462266662.jpg"
                            },
                            "summary": {
                                "conclusion": "风险123123",
                                "question": "问题"
                            }
                        };
                        that.basicInit(result);
                    }else if(ele == 'talk'){
                        result.data = {
                            "title": "山西太原100000平米工业屋顶",
                            "username": "刘宇",
                            "owner": {
                                "own": {
                                    "equity_clear": "0",
                                    "equity_clearDes": "否",
                                    "equity_owner": "wang ",
                                    "contact": "王晓明",
                                    "phone": "18511111114"
                                },
                                "invest_payment": {
                                    "investment_intent": "2",
                                    "investment_intentDes": "找人投资",
                                    "electricity_fee_payment": "2",
                                    "electricity_fee_paymentDes": "趸售用电",
                                    "measure_type": "0",
                                    "measure_typeDes": "否"
                                },
                                "electricity_situation": {
                                    "tou": "1",
                                    "touDes": "是",
                                    "tip": "05:00-15:00",
                                    "tip_electrovalence": "123",
                                    "peak": "03:00-05:00、19:00-22:00",
                                    "peak_electrovalence": "123",
                                    "flat": "06:00-17:00、02:00-13:00",
                                    "flat_electrovalence": "13",
                                    "cereal": "02:00-07:00、11:00-15:00、18:00-23:00",
                                    "cerael_electrovalence": "123"
                                }
                            }
                        }
                        that.talkInit(result);
                    }else if(ele == 'roof'){
                        result.data = {
                            "title": "山西太原100000平米工业屋顶",
                            "username": "刘宇",
                            "roof": [
                                {
                                    "name": "1号",
                                    "base": {
                                        "know_architect": "0",
                                        "know_architectDes": "否",
                                        "architect": "设计单位",
                                        "buildtime": "2016-05-10",
                                        "area": "10000",
                                        "orientation": "4",
                                        "orientationDes": "北"
                                    },
                                    "material": {
                                        "roof_material": "3",
                                        "roof_materialDes": "彩钢瓦",
                                        "barrier": "2,3",
                                        "barrierDes": "电梯间或楼梯间、采光带",
                                        "roof_picture": {
                                            "1": "http://img2.solarbao.com/4f6a306c_1462431844.jpg",
                                            "2": "http://img2.solarbao.com/a49fe891_1462431846.jpg",
                                            "3": "http://img2.solarbao.com/06d3bc74_1462431849.jpg",
                                            "4": "http://img2.solarbao.com/571e32a9_1462431854.jpg",
                                            "5": "http://img2.solarbao.com/571e32a9_1462431857.jpg",
                                            "6": "http://img2.solarbao.com/87d07f90_1462431861.jpg"
                                        }
                                    },
                                    "work": {
                                        "am": "01:00 - 02:00",
                                        "pm": "04:00 - 04:00",
                                        "annual_holiday": "115",
                                        "operating_conditions": "2",
                                        "operating_conditionsDes": "一般",
                                        "plan_way_online": "1",
                                        "plan_way_onlineDes": "自发自用 余电上网"
                                    },
                                    "use_way": {
                                        "building_use": "1",
                                        "building_useDes": "自用",
                                        "lease_period": "15",
                                        "agree_installation": "1",
                                        "agree_installationDes": "是",
                                        "main_electrical_description": "555"
                                    },
                                    "roof_pollute": {
                                        "pollution": "1",
                                        "pollutionDes": "是",
                                        "pollution_level": "2",
                                        "pollution_levelDes": "中度",
                                        "rust": "1",
                                        "rustDes": "是",
                                        "rust_level": "2",
                                        "rust_levelDes": "中度",
                                        "pollution_rust_reason": "666"
                                    },
                                    "utilization": {
                                        "roof_length": "100",
                                        "roof_width": "200",
                                        "roof_height": "50"
                                    },
                                    "waterproof": {
                                        "waterproof_type": "1",
                                        "waterproof_typeDes": "刚性防水",
                                        "is_leaking": "0",
                                        "is_leakingDes": "否",
                                        "waterproof_use": "0",
                                        "gradient": "10°",
                                        "higher_window": "1",
                                        "higher_windowDes": "是",
                                        "window_height": "0",
                                        "plate_type": "1",
                                        "plate_typeDes": "直立锁边型",
                                        "peak_spacing": "20",
                                        "plate_rust": "1",
                                        "plate_rustDes": "有",
                                        "plate_points": "1",
                                        "plate_pointsDes": "有",
                                        "plate_leaking": "0",
                                        "plate_leakingDes": "无"
                                    },
                                    "picture": {
                                        "interior_picture": {
                                            "1": "http://img2.solarbao.com/4f6a306c_1462431883.jpg",
                                            "2": "http://img2.solarbao.com/a49fe891_1462431886.jpg",
                                            "3": "http://img2.solarbao.com/06d3bc74_1462431890.jpg",
                                            "4": "http://img2.solarbao.com/06d3bc74_1462431894.jpg",
                                            "5": "http://img2.solarbao.com/538dcf9d_1462431897.jpg",
                                            "6": "http://img2.solarbao.com/bd666123_1462431901.jpg"
                                        }
                                    },
                                    "internal": {
                                        "roof_hang": "0",
                                        "roof_hangDes": "无",
                                        "structure_accordance": "1",
                                        "structure_accordanceDes": "是",
                                        "fan_hole": "0",
                                        "fan_holeDes": "无",
                                        "modify": "0",
                                        "modifyDes": "否",
                                        "cable_pipe": "9999"
                                    }
                                },
                                {
                                    "name": "2号",
                                    "base": {
                                        "know_architect": "0",
                                        "know_architectDes": "否",
                                        "architect": "设计单位",
                                        "buildtime": "2016-05-10",
                                        "area": "10000",
                                        "orientation": "4",
                                        "orientationDes": "北"
                                    },
                                    "material": {
                                        "roof_material": "3",
                                        "roof_materialDes": "彩钢瓦",
                                        "barrier": "2,3",
                                        "barrierDes": "电梯间或楼梯间、采光带",
                                        "roof_picture": {
                                            "1": "http://img2.solarbao.com/4f6a306c_1462431844.jpg",
                                            "2": "http://img2.solarbao.com/a49fe891_1462431846.jpg",
                                            "3": "http://img2.solarbao.com/06d3bc74_1462431849.jpg",
                                            "4": "http://img2.solarbao.com/571e32a9_1462431854.jpg",
                                            "5": "http://img2.solarbao.com/571e32a9_1462431857.jpg",
                                            "6": "http://img2.solarbao.com/87d07f90_1462431861.jpg"
                                        }
                                    },
                                    "work": {
                                        "am": "01:00 - 02:00",
                                        "pm": "04:00 - 04:00",
                                        "annual_holiday": "115",
                                        "operating_conditions": "2",
                                        "operating_conditionsDes": "一般",
                                        "plan_way_online": "1",
                                        "plan_way_onlineDes": "自发自用 余电上网"
                                    },
                                    "use_way": {
                                        "building_use": "1",
                                        "building_useDes": "自用",
                                        "lease_period": "15",
                                        "agree_installation": "1",
                                        "agree_installationDes": "是",
                                        "main_electrical_description": "555"
                                    },
                                    "roof_pollute": {
                                        "pollution": "1",
                                        "pollutionDes": "是",
                                        "pollution_level": "2",
                                        "pollution_levelDes": "中度",
                                        "rust": "1",
                                        "rustDes": "是",
                                        "rust_level": "2",
                                        "rust_levelDes": "中度",
                                        "pollution_rust_reason": "666"
                                    },
                                    "utilization": {
                                        "roof_length": "100",
                                        "roof_width": "200",
                                        "roof_height": "50"
                                    },
                                    "waterproof": {
                                        "waterproof_type": "1",
                                        "waterproof_typeDes": "刚性防水",
                                        "is_leaking": "0",
                                        "is_leakingDes": "否",
                                        "waterproof_use": "0",
                                        "gradient": "10°",
                                        "higher_window": "1",
                                        "higher_windowDes": "是",
                                        "window_height": "0",
                                        "plate_type": "1",
                                        "plate_typeDes": "直立锁边型",
                                        "peak_spacing": "20",
                                        "plate_rust": "1",
                                        "plate_rustDes": "有",
                                        "plate_points": "1",
                                        "plate_pointsDes": "有",
                                        "plate_leaking": "0",
                                        "plate_leakingDes": "无"
                                    },
                                    "picture": {
                                        "interior_picture": {
                                            "1": "http://img2.solarbao.com/4f6a306c_1462431883.jpg",
                                            "2": "http://img2.solarbao.com/a49fe891_1462431886.jpg",
                                            "3": "http://img2.solarbao.com/06d3bc74_1462431890.jpg",
                                            "4": "http://img2.solarbao.com/06d3bc74_1462431894.jpg",
                                            "5": "http://img2.solarbao.com/538dcf9d_1462431897.jpg",
                                            "6": "http://img2.solarbao.com/bd666123_1462431901.jpg"
                                        }
                                    },
                                    "internal": {
                                        "roof_hang": "0",
                                        "roof_hangDes": "无",
                                        "structure_accordance": "1",
                                        "structure_accordanceDes": "是",
                                        "fan_hole": "0",
                                        "fan_holeDes": "无",
                                        "modify": "0",
                                        "modifyDes": "否",
                                        "cable_pipe": "9999"
                                    }
                                }
                            ]
                        }
                        that.roofInit(result);
                    }else if(ele == 'electric'){
                        result.data = {
                            "title": "山西太原100000平米工业屋顶",
                            "username": "刘宇",
                            "electric": {
                                "voltage": {
                                    "primary_voltage": "35",
                                    "measure_points_voltage": "10",
                                    "transformer_num": "20",
                                    "high_pressure": "35",
                                    "low_pressure": "0.22",
                                    "transformer_capacity": "120000"
                                },
                                "switching": [
                                    {
                                        "name": "1号",
                                        "type": "2",
                                        "typeDes": "总配电室",
                                        "property": "白白",
                                        "picture": {
                                            "1": "http://img2.solarbao.com/4f6a306c_1462269740.jpg",
                                            "2": "http://img2.solarbao.com/a49fe891_1462269743.jpg",
                                            "3": "http://img2.solarbao.com/06d3bc74_1462269747.jpg",
                                            "4": "http://img2.solarbao.com/45385952_1462269751.jpg",
                                            "5": "http://img2.solarbao.com/87d07f90_1462269755.jpg",
                                            "6": "http://img2.solarbao.com/538dcf9d_1462269758.jpg"
                                        }
                                    },
                                    {
                                        "name": "2号",
                                        "type": "2",
                                        "typeDes": "总配电室",
                                        "property": "2",
                                        "picture": {
                                            "1": "http://img2.solarbao.com/4f6a306c_1462269740.jpg",
                                            "2": "http://img2.solarbao.com/a49fe891_1462269743.jpg",
                                            "3": "http://img2.solarbao.com/06d3bc74_1462269747.jpg",
                                            "4": "http://img2.solarbao.com/45385952_1462269751.jpg",
                                            "5": "http://img2.solarbao.com/87d07f90_1462269755.jpg",
                                            "6": "http://img2.solarbao.com/538dcf9d_1462269758.jpg"
                                        }
                                    }
                                ]
                            }
                        }
                        that.electricInit(result);
                    }else if(ele == 'drawing'){
                        result.data = {
                            "title": "山西太原100000平米工业屋顶",
                                "username": "刘宇",
                                "drawing": {
                                "architectural": {
                                    "factory_plane": "1",
                                        "building_design": "1",
                                        "building_construction": "1"
                                },
                                "structure": {
                                    "structure_design": "0",
                                        "structural_construction": "0"
                                },
                                "electric": {
                                    "electric_plane": "1",
                                        "electric_design": "1",
                                        "high_low_pressure": "1",
                                        "lightning_protection": "1",
                                        "troughing": "1",
                                        "switching_plane": "1"
                                },
                                "other": {
                                    "roof_hvac": "1",
                                        "roof_fire": "1"
                                },
                                "architecturalDes": "厂区总平图、建筑设计总说明图、建筑施工图整册",
                                    "structureDes": "无",
                                    "electricDes": "电气总平面图、电气设计总说明、高低压一次系统图、防雷接地图、电缆走线图、配电室平面布置图",
                                    "otherDes": "屋顶暖通管线布置图、屋顶消防管线布置图"
                            }
                        }
                        that.drawingInit(result);
                    }
                }else{
                    $('body').html('<div class="error">' + result.msg +'</div>');
                }
            },function(){
                $('body').html('<div class="error">网络问题，请稍后再试！</div>');
            });
        }else {
            $('body').html('<div class="error">参数错误！</div>');
        }

    },
    basicInit:function(result){
        var that = this;
        //保存屋顶类型
        var data = result.data;
        that.roofType = data.base.roof_type;
        var $itemSummary = $(".item-summary"),
            $itemBasic = $(".item-basic .detail-box").eq(0),
            $itemBasicPic = $(".item-basic-pic"),
            data = result.data,
            str = '<div class="tab-title"><img src="../../static/images/takan/icon_14.png" height="21" class="tab-title-decoration-pic1"/>踏勘总结<img src="../../static/images/takan/icon_56.png" height="29" class="tab-title-decoration-pic2"/></div><div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>总结概述及对各分项评价</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div><div class="detail-box-con"><p>'+ (data.summary.conclusion ? data.summary.conclusion :"") +'</p></div><div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>问题描述及风险提示</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div><div class="detail-box-con"><p>'+ (data.summary.question ? data.summary.question : "") +'</p></div>',
            itemBasicStr = '<div class="tab-title"><img src="../../static/images/takan/icon_32.png" height="21" class="tab-title-decoration-pic1"/>项目基本信息<img src="../../static/images/takan/icon_56.png" height="29" class="tab-title-decoration-pic2"/></div><div class="detail-box-con"><ul class="basic-mes-list"><li><span>屋顶类型：</span>'+ (data.base.roof_typeDes ? data.base.roof_typeDes : "" )+'</li><li><span>踏勘地点：</span>'+ (data.base.address ? data.base.address : "") +'</li></ul></div>',
            itemBasicPicStr = '<div class="detail-box-con"><h3 class="detail-title">所在位置卫星图全景图</h3><div class="mt10 J_satelliteImg"><img indx="0" src="'+ (data.base.satellitp_picture ? data.base.satellitp_picture  : '') +'" height="103" /></div></div>';
        $itemSummary.html(str);
        $itemBasic.html(itemBasicStr);
        $itemBasicPic.html(itemBasicPicStr);
        //显示内容
        $basic.show().eq(0).attr('loaded','1');
        that.showMainDom({
            title: data.title,
            username: data.username
        });
        //查看大图
        var $imgs = $('.J_satelliteImg').find('img');
        $imgs.click(function(){
            that.viewBigImg($imgs,$(this).attr('index'));
        });
    },
    talkInit:function(result){
        var that = this;
        var str = [],
            data = result.data.owner;
        str.push('<div class="tab-title"><img src="../../static/images/takan/icon_14.png" height="21" class="tab-title-decoration-pic1"/>与屋顶主沟通的信息<img src="../../static/images/takan/icon_56.png" height="29" class="tab-title-decoration-pic2"/></div>');
        str.push('<div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>屋顶产权及联系人</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
        str.push('<div class="detail-box-con"><ul class="basic-mes-list">');
        str.push('<li><span>产权是否清晰：</span>'+ (data.own.equity_clearDes ? data.own.equity_clearDes : '') +'</li>');
        if('1' == data.own.equity_clear){
            str.push('<li><span>产权所有者：</span>'+ (data.own.equity_owner ? data.own.equity_owner : '') +'</li>');
        }
        str.push('<li><span>联系人：</span>'+ (data.own.contact ? data.own.contact : '') +'</li>');
        str.push('<li><span>联系电话：</span>'+ (data.own.phone ? data.own.phone :'') +'</li>');
        str.push('</ul></div>');
        str.push('<div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>投资意向与缴费情况</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
        str.push('<div class="detail-box-con"><ul class="basic-mes-list">');
        str.push('<li><span>用户投资意向：</span>'+ (data.invest_payment.investment_intentDes ? data.invest_payment.investment_intentDes: '') +'</li>');
        str.push('<li><span>用户电费缴纳情况：</span>'+ (data.invest_payment.electricity_fee_paymentDes ? data.invest_payment.electricity_fee_paymentDes: '') +'</li>');
        str.push('<li><span>商业照明与工业照明是否分开计量：</span>'+ (data.invest_payment.measure_typeDes ? data.invest_payment.measure_typeDes: '') +'</li>');
        str.push('</ul></div>');
        str.push('<div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>用电情况</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
        str.push('<div class="detail-box-con"><ul class="elec-list">');
        //that.roofType = 3;
        if('3' == that.roofType){
            //个人屋顶
            str.push('<li class="clearfix"><span>电价：</span><em>'+ (data.electricity_situation.electrovalence ? data.electricity_situation.electrovalence :'')+'元/kWh</em></li>');
            str.push('<li class="clearfix"><span>月用电量：</span><em>'+ (data.electricity_situation.month_electricity ? data.electricity_situation.month_electricity :'') +'万kWh</em></li>');
        }else{
            //data.electricity_situation.tou = 0;
            str.push('<li class="clearfix"><span>是否执行峰谷平电价：</span><em>'+ (data.electricity_situation.touDes ? data.electricity_situation.touDes : '') +'</em></li>');
            if('1' == data.electricity_situation.tou){
                //峰谷平电价
                str.push('<li class="clearfix"><span>峰时间段：</span><em>'+ (data.electricity_situation.peak ? data.electricity_situation.peak :'')+'</em></li>');
                str.push('<li class="clearfix"><span>峰电价：</span><em>'+ (data.electricity_situation.peak_electrovalence ? data.electricity_situation.peak_electrovalence :'') +'元/kWh</em></li>');
                str.push('</ul></div><div class="gap-line"></div><div class="detail-box-con"><ul class="elec-list">');
                str.push('<li class="clearfix"><span>谷时间段：</span><em>'+ (data.electricity_situation.cereal ? data.electricity_situation.cereal :'') +'</em></li>');
                str.push('<li class="clearfix"><span>谷电价：</span><em>'+ (data.electricity_situation.cerael_electrovalence ? data.electricity_situation.cerael_electrovalence :'') +'元/kWh</em></li>');
                str.push('</ul></div><div class="gap-line"></div><div class="detail-box-con"><ul class="elec-list">');
                str.push('<li class="clearfix"><span>平时间段：</span><em>'+ (data.electricity_situation.flat ? data.electricity_situation.flat :'') +'</em></li>');
                str.push('<li class="clearfix"><span>平电价：</span><em>'+ (data.electricity_situation.flat_electrovalence ? data.electricity_situation.flat_electrovalence :'') +'元/kWh</em></li>');
                if(data.electricity_situation.tip_electrovalence != '' || data.electricity_situation.tip != ''){
                    str.push('<li class="clearfix"><span>尖峰时间段：</span><em>'+ (data.electricity_situation.tip ? data.electricity_situation.tip :'') +'</em></li>');
                    str.push('<li class="clearfix"><span>尖峰电价：</span><em>'+ (data.electricity_situation.tip_electrovalence ? data.electricity_situation.tip_electrovalence :'') +'元/kWh</em></li>');
                }
            }else{
                //非峰谷平电价
                str.push('<li class="clearfix"><span>电价：</span><em>'+ (data.electricity_situation.electrovalence ? data.electricity_situation.electrovalence :'')+'元/kWh</em></li>');
                str.push('<li class="clearfix"><span>月用电量：</span><em>'+ (data.electricity_situation.month_electricity ? data.electricity_situation.month_electricity :'') +'万kWh</em></li>');
            }
        }
        str.push('</ul></div>');
        $itemTalk.html(str.join('')).show().attr('loaded','1');
        that.showMainDom({
            title: result.data.title,
            username: result.data.username
        });
    },
    roofInit:function(result){
        var that = this;
        var str = [],
            data = result.data.roof;
        str.push('<div class="tab-title"><img src="../../static/images/takan/icon_14.png" height="21" class="tab-title-decoration-pic1"/>屋顶360°详细信息<img src="../../static/images/takan/icon_56.png" height="29" class="tab-title-decoration-pic2"/></div>');
        //循环多个屋顶
        for(var i = 0; i < data.length; i++){
            var arrRoof = [];
            var currentRoof = data[i];
            //屋顶基本信息
            arrRoof.push('<h2 class="detail-second-title">'+ (currentRoof.name ? currentRoof.name :'') +'</h2>');
            arrRoof.push('<div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>屋顶基本信息</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
            arrRoof.push('<div class="detail-box-con"><ul class="basic-mes-list">');
            arrRoof.push('<li><span>是否清楚屋顶的设计单位：</span>'+ (currentRoof.base.know_architectDes ? currentRoof.base.know_architectDes : '') +'</li>');
            if('1' == currentRoof.base.know_architect){
                arrRoof.push('<li><span>设计单位：</span>'+ (currentRoof.base.architect ? currentRoof.base.architect : '') +'</li>');
            }
            arrRoof.push('<li><span>建成时间：</span>'+ (currentRoof.base.buildtime ? currentRoof.base.buildtime :'') +'</li>');
            arrRoof.push('<li><span>屋顶面积：</span>'+ (currentRoof.base.area ? currentRoof.base.area : '') +'平方米</li>');
            arrRoof.push('<li><span>屋顶朝向：</span>'+ (currentRoof.base.orientationDes ? currentRoof.base.orientationDes :'') +'</li>');
            arrRoof.push('</ul></div><div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>屋顶实景照片</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
            arrRoof.push('<div class="detail-box-con"><ul class="basic-mes-list">');
            arrRoof.push('<li><span>屋顶的材质：</span>'+ (currentRoof.material.roof_materialDes ? currentRoof.material.roof_materialDes :'') +'</li>');
            if(-1 != $.inArray(currentRoof.roof_material,['4','5'])){
                arrRoof.push('<li><span>障碍物：</span>'+ (currentRoof.material.barrierDes ? currentRoof.material.barrierDes :'') +'</li>');
            }
            arrRoof.push('</ul></div>');
            //实景照片
            if(currentRoof.material.roof_picture['1']){
                arrRoof.push('<div class="gap-line"></div><div class="detail-box-con">');
                arrRoof.push('<p class="black-color ">屋顶实景照片</p><ul class="pic-list clearfix mt10 ceil-pic-list">');
                var index = 0;
                for(var j in currentRoof.material.roof_picture){
                    arrRoof.push('<li><img index="' + index +'" src="'+ currentRoof.material.roof_picture[j] +'" /></li>');
                    index++;
                }
                arrRoof.push('</ul></div>');
            }
            //企业工作制及经营状况
            if('3' != that.roofType){
                arrRoof.push('<div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>企业工作制及经营状况</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
                arrRoof.push('<div class="detail-box-con"><ul class="basic-mes-list">');
                arrRoof.push('<li><span>上午工作时间段：</span>'+ (currentRoof.work.am ? currentRoof.work.am :'') +'</li>');
                arrRoof.push('<li><span>下午工作时间段：</span>'+ (currentRoof.work.pm ? currentRoof.work.pm :'') +'</li>');
                arrRoof.push('<li><span>全年放假天数：</span>'+ (currentRoof.work.annual_holiday ? currentRoof.work.annual_holiday :'') +' 天</li>');
                arrRoof.push('<li><span>企业经营状况：</span>'+ (currentRoof.work.operating_conditionsDes ? currentRoof.work.operating_conditionsDes :'') +'</li>');
                arrRoof.push('<li><span>计划上网方式：</span>'+ (currentRoof.work.plan_way_onlineDes ? currentRoof.work.plan_way_onlineDes :'') +'</li>');
                arrRoof.push('</ul></div>');
            }
            //屋顶使用方式
            arrRoof.push('<div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>屋顶使用方式</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
            arrRoof.push('<div class="detail-box-con"><ul class="basic-mes-list">');
            arrRoof.push('<li><span>使用方式：</span>'+ (currentRoof.use_way.building_useDes ? currentRoof.use_way.building_useDes :'') +'</li>');
            if('2' == currentRoof.use_way.building_use){
                arrRoof.push('<li><span>租赁年限：</span>'+ (currentRoof.use_way.lease_period ? currentRoof.use_way.lease_period :'') +'年</li>');
                arrRoof.push('<li><span>租赁方是否同意安装电站：</span>'+ (currentRoof.use_way.agree_installationDes ? currentRoof.use_way.agree_installationDes :'') +'</li>');
            }
            arrRoof.push('<li><span>主要用电设备描述：</span>'+ (currentRoof.use_way.main_electrical_description ? currentRoof.use_way.main_electrical_description :'') +'</li>');
            arrRoof.push('</ul></div>');
            //屋顶污染或锈蚀情况
            arrRoof.push('<div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>屋顶污染或锈蚀情况</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
            arrRoof.push('<div class="detail-box-con"><ul class="basic-mes-list">');
            arrRoof.push('<li><span>屋顶是否污染：</span>'+ (currentRoof.roof_pollute.pollutionDes ? currentRoof.roof_pollute.pollutionDes :'') +'</li>');
            if('1' == currentRoof.roof_pollute.pollution){
                arrRoof.push('<li><span>污染程度：</span>'+ (currentRoof.roof_pollute.pollution_levelDes ? currentRoof.roof_pollute.pollution_levelDes :'') +'</li>');
            }
            arrRoof.push('<li><span>屋顶是否锈蚀：</span>'+ (currentRoof.roof_pollute.rustDes ? currentRoof.roof_pollute.rustDes :'') +'</li>');
            if('1' == currentRoof.roof_pollute.rust){
                arrRoof.push('<li><span>锈蚀程度：</span>'+ (currentRoof.roof_pollute.rust_levelDes ? currentRoof.roof_pollute.rust_levelDes :'') +'</li>');
            }
            if('1' == currentRoof.roof_pollute.pollution || '1' == currentRoof.roof_pollute.rust){
                arrRoof.push('<li><span>污染或锈蚀原因：</span>'+ (currentRoof.roof_pollute.pollution_rust_reason ? currentRoof.roof_pollute.pollution_rust_reason :'') +'</li>');
            }
            arrRoof.push('</ul></div>');
            //屋顶可利用情况
            arrRoof.push('<div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>屋顶可利用情况</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
            arrRoof.push('<div class="detail-box-con"><ul class="basic-mes-list">');
            arrRoof.push('<li><span>屋顶长度：</span>'+ (currentRoof.utilization.roof_length ? currentRoof.utilization.roof_length :'') +' 米</li>');
            arrRoof.push('<li><span>屋顶宽度：</span>'+ (currentRoof.utilization.roof_width ? currentRoof.utilization.roof_width : '') +' 米</li>');
            arrRoof.push('<li><span>距地面高度：</span>'+ (currentRoof.utilization.roof_height ? currentRoof.utilization.roof_height :'') +' 米</li>');
            arrRoof.push('</ul></div>');
            //屋顶防水情况
            if(-1 != $.inArray(currentRoof.roof_material,['4','5'])) {
                //非瓦屋面、其他的屋顶材质
                arrRoof.push('<div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>屋顶防水情况</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
                arrRoof.push('<div class="detail-box-con"><ul class="basic-mes-list">');
                if('3' == currentRoof.roof_material){
                    //“彩钢瓦”防水情况页
                    arrRoof.push('<li><span>彩钢板类型：</span>' + (currentRoof.waterproof.plate_typeDes ? currentRoof.waterproof.plate_typeDes : '') + '</li>');
                    arrRoof.push('<li><span>屋面坡度：</span>' + (currentRoof.waterproof.gradient ? currentRoof.waterproof.gradient : '') + '</li>');
                    arrRoof.push('<li><span>彩钢瓦波峰间距：</span>' + (currentRoof.waterproof.peak_spacing ? currentRoof.waterproof.peak_spacing : '') + '厘米</li>');
                    arrRoof.push('<li><span>彩钢板有无明显锈蚀：</span>' + (currentRoof.waterproof.plate_rustDes ? currentRoof.waterproof.plate_rustDes : '') + '</li>');
                    arrRoof.push('<li><span>彩钢板有无明显坏点：</span>' + (currentRoof.waterproof.plate_pointsDes ? currentRoof.waterproof.plate_pointsDes : '') + '</li>');
                    arrRoof.push('<li><span>彩钢板有无漏水：</span>' + (currentRoof.waterproof.plate_leakingDes ? currentRoof.waterproof.plate_leakingDes : '') + '</li>');
                }else{
                    //“现浇混凝土”&“预制混凝土”防水情况页
                    arrRoof.push('<li><span>防水类型：</span>' + (currentRoof.waterproof.waterproof_typeDes ? currentRoof.waterproof.waterproof_typeDes : '') + '</li>');
                    arrRoof.push('<li><span>是否漏水：</span>' + (currentRoof.waterproof.is_leakingDes ? currentRoof.waterproof.is_leakingDes : '') + '</li>');
                    arrRoof.push('<li><span>屋面防水已使用年限：</span>' + (currentRoof.waterproof.waterproof_use ? currentRoof.waterproof.waterproof_use : '') + '年</li>');
                    arrRoof.push('<li><span>屋面坡度：</span>' + (currentRoof.waterproof.gradient ? currentRoof.waterproof.gradient : '') + '</li>');
                    arrRoof.push('<li><span>是否有高出层面的采光窗：</span>' + (currentRoof.waterproof.higher_windowDes ? currentRoof.waterproof.higher_windowDes : '') + '</li>');
                    if('1' == currentRoof.waterproof.higher_window){
                        arrRoof.push('<li><span>采光窗高度：</span>' + (currentRoof.waterproof.window_height ? currentRoof.waterproof.window_height : '') + '米</li>');
                    }
                }
                arrRoof.push('</ul></div>');
                //屋顶内部照片
                if(currentRoof.picture.interior_picture['1']){
                    arrRoof.push('<div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>屋顶内部照片</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
                    arrRoof.push('<div class="detail-box-con"><ul class="pic-list clearfix inner-pic-list">');
                    var index = 0;
                    for(var j in currentRoof.picture.interior_picture){
                        arrRoof.push('<li><img index="' + index +'" src="'+ currentRoof.picture.interior_picture[j] +'" /></li>');
                        index++;
                    }
                    arrRoof.push('</ul></div>');
                }
                //屋顶内部情况
                arrRoof.push('<div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>屋顶内部情况</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
                arrRoof.push('<div class="detail-box-con"><ul class="basic-mes-list">');
                if('3' == currentRoof.roof_material) {
                    //“彩钢瓦”
                    arrRoof.push('<li><span>立柱用钢材质：</span>'+ (currentRoof.internal.upright_steel ? currentRoof.internal.upright_steel :'') +'</li>');
                    arrRoof.push('<li><span>钢梁用钢材质：</span>'+ (currentRoof.internal.girder_steel ? currentRoof.internal.girder_steel :'') +'</li>');
                    arrRoof.push('<li><span>檩条用钢材质：</span>'+ (currentRoof.internal.purline_steel ? currentRoof.internal.purline_steel :'') +'</li>');
                    arrRoof.push('<li><span>檩条用钢规格：</span>'+ (currentRoof.internal.purline_specification ? currentRoof.internal.purline_specification :'') +'</li>');
                    arrRoof.push('<li><span>檩条型号：</span>'+ (currentRoof.internal.purline_model ? currentRoof.internal.purline_model :'') +'</li>');
                    arrRoof.push('<li><span>檩条跨度：</span>'+ (currentRoof.internal.purline_span ? currentRoof.internal.purline_span :'') +'米</li>');
                    arrRoof.push('<li><span>屋面板有无吊顶：</span>'+ (currentRoof.internal.is_ceilingDes ? currentRoof.internal.is_ceilingDes :'') +'</li>');
                    arrRoof.push('<li><span>檩条有无变形情况：</span>'+ (currentRoof.internal.purline_deformedDes ? currentRoof.internal.purline_deformedDes :'') +'</li>');
                    arrRoof.push('<li><span>檩条有无腐蚀情况：</span>'+ (currentRoof.internal.purline_rustDes ? currentRoof.internal.purline_rustDes :'') +'</li>');
                    arrRoof.push('<li><span>檩条间拉条情况：</span>'+ (currentRoof.internal.purline_braceDes ? currentRoof.internal.purline_braceDes :'') +'</li>');
                    arrRoof.push('<li><span>屋内结构或构件尺寸是否与施工图纸一致：</span>'+ (currentRoof.internal.structure_accordanceDes ? currentRoof.internal.structure_accordanceDes :'') +'</li>');
                    arrRoof.push('<li><span>内部是否有掉挂：</span>'+ (currentRoof.internal.purline_hangDes ? currentRoof.internal.purline_hangDes :'') +'</li>');
                    if('1' == currentRoof.internal.purline_hang){
                        arrRoof.push('<li><span>吊挂物情况：</span>'+ (currentRoof.internal.purline_hang_conditionDes ? currentRoof.internal.purline_hang_conditionDes :'') +'</li>');
                    }
                    arrRoof.push('<li><span>屋面建成后有无改动后加设备：</span>'+ (currentRoof.internal.modifyDes ? currentRoof.internal.modifyDes :'') +'</li>');
                    arrRoof.push('<li><span>电缆桥架位置描述：</span>'+ (currentRoof.internal.purline_cable ? currentRoof.internal.purline_cable :'') +'</li>');
                }else{
                    //“现浇混凝土”&“预制混凝土”
                    arrRoof.push('<li><span>屋面梁或板有无吊挂荷载：</span>'+ (currentRoof.internal.roof_hangDes ? currentRoof.internal.roof_hangDes :'') +'</li>');
                    arrRoof.push('<li><span>屋内结构或构件尺寸是否与图纸一致：</span>'+ (currentRoof.internal.structure_accordanceDes ? currentRoof.internal.structure_accordanceDes :'') +'</li>');
                    arrRoof.push('<li><span>屋面板有无风机开孔：</span>'+ (currentRoof.internal.roof_hangDes ? currentRoof.internal.roof_hangDes :'') +'</li>');
                    arrRoof.push('<li><span>屋面建成后有无改动后加设备：</span>'+ (currentRoof.internal.modifyDes ? currentRoof.internal.modifyDes :'') +'</li>');
                    arrRoof.push('<li><span>电缆井/管道位置描述：</span>'+ (currentRoof.internal.cable_pipe ? currentRoof.internal.cable_pipe :'') +'</li>');
                }
                arrRoof.push('</ul></div>');
            }
            str.push(arrRoof.join(''));
        }
        $itemRoof.html(str.join('')).show().attr('loaded','1');
        that.showMainDom({
            title: result.data.title,
            username: result.data.username
        });

        //查看大图
        var $imgGroup = $itemRoof.find(".ceil-pic-list");
        $imgGroup.each(function(){
            var $this = $(this);
            var $imgs = $this.find('li img');
            $imgs.click(function(){
                that.viewBigImg($imgs,$(this).attr('index'));
            });
        });
    },
    electricInit:function(result){
        var that = this;
        var data = result.data.electric,
            str = [];
        str.push('<div class="tab-title"><img src="../../static/images/takan/icon_14.png" height="21" class="tab-title-decoration-pic1"/>配电电气情况<img src="../../static/images/takan/icon_56.png" height="29" class="tab-title-decoration-pic2"/></div><div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>电压与变压器情况</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
        str.push('<div class="detail-box-con"><ul class="basic-mes-list">');
        str.push('<li><span>变电进线电压：</span>'+ (data.voltage.primary_voltage ? data.voltage.primary_voltage :'') +' kV</li>');
        str.push('<li><span>计量点电压：</span>'+ (data.voltage.measure_points_voltage ? data.voltage.measure_points_voltage :'') +' kV</li>');
        if('3' != that.roofType){
            //工商业屋顶
            str.push('<li><span>变压器台数：</span>'+ (data.voltage.transformer_num ? data.voltage.transformer_num :'') +' 台</li>');
            str.push('<li><span>变压器高压：</span>'+ (data.voltage.high_pressure ? data.voltage.high_pressure :'') +' kV</li>');
            str.push('<li><span>变压器低压：</span>'+ ( data.voltage.low_pressure ? data.voltage.low_pressure :'') +' kV</li>');
            str.push('<li><span>变压器容量：</span>'+ (data.voltage.transformer_capacity ? data.voltage.transformer_capacity :'') +' kVA</li>');
        }
        str.push('</ul></div>');
        if('3' != that.roofType) {
            //工商业屋顶
            str.push('<div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>配电室情况</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div>');
            for(var j = 0; j < data.switching.length;j++){
                var arrayHTML = [];
                var currentElectric = data.switching[j];
                var name = (j+1) +'号配电室';
                arrayHTML.push('<h2 class="detail-second-title">'+ name +'</h2>');
                arrayHTML.push('<div class="detail-box-con" style="padding-top:0px;"><ul class="basic-mes-list">')
                arrayHTML.push('<li><span>'+ name +'类型：</span>'+ (currentElectric.typeDes ? currentElectric.typeDes :'') +'</li>');
                arrayHTML.push('<li><span>'+ name +'产权：</span>'+ (currentElectric.property ? currentElectric.property :'') +'</li>');
                arrayHTML.push('</ul></div><div class="gap-line"></div>');
                if(currentElectric.picture['1']){
                    arrayHTML.push('<div class="detail-box-con"><p class="black-color ">'+ name +'现场实景照片</p><ul class="pic-list clearfix mt10 electric-pic-list">');
                    var index = 0;
                    for(var k in currentElectric.picture){
                        arrayHTML.push('<li><img index="' + index + '" src="'+ currentElectric.picture[k] +'" /></li>');
                        index++;
                    }
                    arrayHTML.push('</ul></div>');
                }
                str.push(arrayHTML.join(''));
            }
            $itemElectric.html(str.join('')).show().attr('loaded','1');
            that.showMainDom({
                title: result.data.title,
                username: result.data.username
            });

            //查看大图
            var $imgGroup = $itemElectric.find(".electric-pic-list");
            $imgGroup.each(function(){
                var $this = $(this);
                var $imgs = $this.find('li img');
                $imgs.click(function(){
                    that.viewBigImg($imgs,$(this).attr('index'));
                });
            });
        }
    },
    drawingInit:function(result){
        var that = this;
        var data = result.data,
            str = '';
        str += '<div class="tab-title"><img src="../../static/images/takan/icon_14.png" height="21" class="tab-title-decoration-pic1"/>图纸收集情况<img src="../../static/images/takan/icon_56.png" height="29" class="tab-title-decoration-pic2"/></div><div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>建筑图</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div><div class="paper-collect-con"><h3 class="detail-title">'+ (data.drawing.architecturalDes ? data.drawing.architecturalDes :'' ) +'</h3></div><div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>结构图</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div><div class="paper-collect-con"><h3 class="detail-title">'+ (data.drawing.structureDes ? data.drawing.structureDes :'' )  +'</h3></div><div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>电气图</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div><div class="paper-collect-con"><h3 class="detail-title">'+ (data.drawing.electricDes ? data.drawing.electricDes :'' ) +'</h3></div><div class="sub-tab-title-wrapper"><h3 class="sub-tab-title"><span>其他</span><img src="../../static/images/takan/icon_19.png" height="21" class="sub-tab-title-decoration-lt"/><img src="../../static/images/takan/icon_23.png" height="21" class="sub-tab-title-decoration-rb"/></h3></div><div class="paper-collect-con"><h3 class="detail-title">' + (data.drawing.otherDes ? data.drawing.otherDes :'' ) +'</h3></div>';
        $itemDrawing.html(str).show().attr('loaded','1');
        that.showMainDom({
            title: result.data.title,
            username: result.data.username
        });
    },
    /**
     * 查看大图
     * @param $imgs img的jquery对象
     * @param showIndex 显示第几个图片
     */
    viewBigImg: function ($imgs,showIndex) {
        $(".swiper-wrapper").html("");
        var attrHTML = [];
        $imgs.each(function(index,element){
            attrHTML.push('<div class="swiper-slide"><div><img src="'+ $(element).attr('src') +'" /></div></div>');
        });
        $(".swiper-wrapper").html(attrHTML.join(''));
        $(".swiper-container").show();
        var swiper = new Swiper('.swiper-container', {
            pagination: '.swiper-pagination',
            paginationClickable: true,
            initialSlide: parseInt(showIndex) ? parseInt(showIndex) : 0
        });
        $('div.swiper-slide div').each(function () {
            var zoomer = new RTP.PinchZoom($(this), {});
            var fator = zoomer.getInitialZoomFactor();
        });
        //关闭
        $('.swiper-container').off('click').click(function(e){
            if(!(e.target.tagName.toUpperCase() == 'IMG' || $(e.target).hasClass('swiper-pagination-bullet'))){
                $(this).hide();
                swiper.destroy();
            }
        });
    }
};

$(function(){
    var that = operatorCategory;
    //$(".pic-list li").css({"height":$picListW,"overflow":"hidden"});
    that.init();
    $itemBtn.on("click",function(){
        that.pop();
    });
    $closeBtn.on("click",function(){
        that.pullBack();
    });
});