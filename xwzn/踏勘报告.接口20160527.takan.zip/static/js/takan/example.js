/**
 * Created by wangyaru on 2016/5/23.
 */
var fr = getQueryString('fr');
var swiper = null;
if( fr=="spick" ) {
    $("body").append("<script type='text/javascript' src='../../static/js/WebViewJavascriptBridge.js'></script>");
    $("body").append("<script type='text/javascript' src='../../static/js/jsBridgeApp.js'></script>");
    setAppNewTitle(document.title);
}
function setAppNewTitle( title ) {
    var titleObj = {
        "title": title,
        "leftIcon":"judgeLeftIcon",
        "rightIcon":[]
    };
    if( fr=="spick" ){
        callSetAppTitle( titleObj );
    }
}
// 左侧返回按钮的点击事件
function judgeLeftIcon() {
    var $bigImg = $('.swiper-container');
    if($bigImg.is(':visible')){
        $bigImg.hide();
        if(swiper){
            swiper.destroy();
        }
    }else{
        //返回
        goBack();
    }
}
var $itemBtn = $(".item-btn"),
    $itemList = $(".item-list"),
    $itemBtnTxt = $itemBtn.find("span"),
    $oMask = $(".mask"),
    $closeBtn = $(".close-btn"),
    $closeBtnTxt = $closeBtn.find("span"),
    animateFlag = false,
    $itemDrawing = $(".item-drawing"),//图纸
    $itemTalk = $(".item-talk"),//沟通信息
    $itemRoof = $(".item-roof"),//屋顶
    $itemElectric = $(".item-electric"),//配电
    $basic = $('.item-summary,.item-basic');//基本信息
var operatorCategory = {
    initMask: function () {
        var $documentH = $(document).height();
        $oMask.css("height", $documentH);
    },
    pop: function () {
        if (animateFlag) {
            return;
        }
        animateFlag = true;
        $itemList.animate({
            "right": "0%"
        }, 1000, function () {
            animateFlag = false;
        });
        $oMask.add($closeBtn).css("display", "block");
        $itemBtn.css("display", "none");
    },
    pullBack: function () {
        if (animateFlag) {
            return;
        }
        animateFlag = true;
        $itemBtn.css("display", "block");
        $closeBtn.css("display", "none");
        $itemList.animate({
            "right": "-100%"
        }, 1000, function () {
            $oMask.css("display", "none");
            animateFlag = false;
        });
    },
    init:function(){
        var that = this;
        $(".detail-box:gt(2)").css("display","none");
        //选择步骤
        $itemList.find("ul li").on("click",function(){
            var oIndex = $(this).index();
            //当前状态设置
            $(this).addClass('selected').siblings().removeClass('selected');
            //返回顶部
            $(document).scrollTop(0);
            $closeBtnTxt.add($itemBtnTxt).html((oIndex + 1) + '/' + $itemList.find("ul li").length);
            $(".detail-box:gt(2)").css("display","none");
            $basic.hide();
            if(oIndex == 0){
                $basic.show();
            }else if(oIndex == 1){
                $itemTalk.show();
            }else if(oIndex == 2){
                $itemRoof.show();
            }else if(oIndex == 3){
                $itemElectric.show();
            }else if(oIndex == 4){
                $itemDrawing.show();
            }
        });
        //step定位
        var number = location.href.match(/#step(\d+)$/);
        if(number){
            $itemList.find("ul li").eq(parseInt(number[1])-1).trigger('click');
        }
        //查看大图--基本信息
        var $imgsSatellite = $('.J_satelliteImg').find('img');
        $imgsSatellite.click(function(){
            that.viewBigImg($imgsSatellite,$(this).attr('index'));
        });
        //查看大图--屋顶
        var $imgGroupRoof = $itemRoof.find(".ceil-pic-list");
        $imgGroupRoof.each(function(){
            var $this = $(this);
            var $imgs = $this.find('li img');
            $imgs.click(function(){
                that.viewBigImg($imgs,$(this).attr('index'));
            });
        });
        //查看大图--配电室
        var $imgGroupElec = $itemElectric.find(".electric-pic-list");
        $imgGroupElec.each(function(){
            var $this = $(this);
            var $imgs = $this.find('li img');
            $imgs.click(function(){
                that.viewBigImg($imgs,$(this).attr('index'));
            });
        });
    },
    /**
     * 查看大图
     * @param $imgs img的jquery对象
     * @param showIndex 显示第几个图片
     */
    viewBigImg: function ($imgs,showIndex) {
        $(".swiper-wrapper").html("");
        var attrHTML = [];
        $imgs.each(function(index,element){
            attrHTML.push('<div class="swiper-slide"><div><img src="'+ $(element).attr('src') +'" /></div></div>');
        });
        $(".swiper-wrapper").html(attrHTML.join(''));
        $(".swiper-container").show();
        swiper = new Swiper('.swiper-container', {
            pagination: '.swiper-pagination',
            paginationClickable: true,
            initialSlide: parseInt(showIndex) ? parseInt(showIndex) : 0
        });
        $('div.swiper-slide div').each(function () {
            var zoomer = new RTP.PinchZoom($(this), {});
            var fator = zoomer.getInitialZoomFactor();
        });
        //关闭
        $('.swiper-container').off('click').click(function(e){
            if(!(e.target.tagName.toUpperCase() == 'IMG' || $(e.target).hasClass('swiper-pagination-bullet'))){
                $(this).hide();
                swiper.destroy();
            }
        });
    }
};
$(function(){
    var that = operatorCategory;
    $itemBtn.on("click",function(){
        that.pop();
    });
    $closeBtn.on("click",function(){
        that.pullBack();
    });
    that.init();
});