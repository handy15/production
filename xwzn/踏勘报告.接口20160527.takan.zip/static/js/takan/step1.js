/**
 * Created by wangyaru on 2016/5/3.
 * 报告命名与基本信息
 */
var fr = getQueryString('fr');
if( fr=="spick" ) {
	$("body").append("<script type='text/javascript' src='../../static/js/WebViewJavascriptBridge.js'></script>");
	$("body").append("<script type='text/javascript' src='../../static/js/jsBridgeApp.js'></script>");
	setAppNewTitle(document.title);
}
function setAppNewTitle( title ) {
	var titleObj = {
		"title": title, 
		"leftIcon":"judgeLeftIcon", 
		"rightIcon":[]
	};
    if( fr=="spick" ){
        callSetAppTitle( titleObj );
    }
}
// 左侧返回按钮的点击事件
function judgeLeftIcon() {
	var hasDeal = false;// 标识左侧的图标是否已经处理过事件
	$.each( $(".my-sel-frame "), function(i, iframe) {
		if( $(iframe).is(":visible") ) {
			hasDeal = true;
			$(iframe).addClass("uhide");
            $("body").css("overflow-y", "auto");
            $("form#applyForm").show();
            if('ios' == judgePhoneSysType()){
                $(iframe).contents().find("#province, #city, #area").html('<li>加载中...</li>');
            }
            setAppNewTitle(document.title);
		}
	});
	// 左上角的图标没有被操作事件，那么就直接返回上一个页面
	if( !hasDeal ) {
        var that = reportName;
        //移除光标
        $('form:visible input:focus').blur();
        var $editorableDiv = $("form:visible [name='base[address]']:focus");
        if($editorableDiv.length){
            $editorableDiv.blur();
        }
        takanUtility.confirm({
            popObj: $('#backPop'),
            confirmCallback: function() {
                if (that.userId) {
                    //提交参数
                    var para = 'userId=' + that.userId + '&submit=0&' + that.getFormValues($('#applyForm')) + '&version=' + config.interfaceVersion;
                    var $address = $("[name='base[address]']");
                    if ($address.length && $address.text() != '') {
                        para += '&base[address]=' + $address.text();
                    }
                    if (that.reportId) {
                        para += '&reportId=' + that.reportId;
                    }
                    jqueryAjaxGetJsonp(config.tkServerUrl + '/ExplorationReport/Base.json', para, function (result) {
                        if (result.code == 2000) {
                            goBack();
                        } else {
                            that.hideTip(result.msg);
                        }
                    }, function () {
                        that.hideTip('网络问题，请稍后再试！');
                    });
                } else {
                    that.hideTip('参数错误！');
                }
            }
        });
	}
}

var timer = null;
var $loading = $(".loading");
var $mask = $(".mask");
var reportName = {
    //申请项目初始化
    init:function(){
        var that = this;
        //初始化数据
        that.loadPageInitDatas();
        //手动选择省市区
        $("#chooseAddr").click(function(){
            that.openAreaSel();
        });
        //地图
        $("#chooseMap").click(function(){
            that.openMap();
        });
        //上传图片
        that.uploadImg();

        // 屋顶类型选择初始化选中
        $(".roof-type div:first").trigger('click');

        //设置按钮在最底层
        setTimeout(function(){
            that.judgePageHeight();
        },0);
        //提交
        that.submitForm();
        //使用html5 的postMessage必须处理的
        that.postMessage();
    },
    //修改项目初始化
    initModify: function(){
        var that = this;
        //数据初始化
        that.loadPageInitDatas();
        //获取电站信息
        that.getProjectInfo(function(result){
            //手动选择省市区
            $("#chooseAddr").click(function(){
                that.openAreaSel();
            });
            //地图
            $("#chooseMap").click(function(){
                that.openMap();
            });
            var info = result.data;
            //that.deleteInputText();
            $("input[name='base[name]']").val(info.name);
            var reg = new RegExp(info.provinceDes+info.cityDes+info.areaDes);
            $("[name='base[address]']").text(info.address.replace(reg,''));
            $('#province').val(info.province==0?'':info.province);
            $('#city').val(info.city==0?'':info.city);
            $('#area').val(info.area==0?'':info.area);
            var address = (info.provinceDes?info.provinceDes:'') + '—' + (info.cityDes?info.cityDes:'') + '—'  + (info.areaDes?info.areaDes:'');
            if('——' != address){
                $('#address-h').text(address).addClass('dark-color');
            }
            //照片
            var imgUrl = info.satellitp_picture;
            if(imgUrl){
                var $container = $('.upload-imgs .per-upload').eq(0);
                $container.find('img').attr('src',imgUrl);
                //处理不规则图片
                that.dealImg(imgUrl,$container);
                //删除按钮
                $container.append('<div class="btn-del" onclick="">&times;</div>');
                $('#img0').val(imgUrl);
            }
            //上传图片事件
            that.uploadImg();
            //项目阶段
            $('.roof-type div[value=' + info.roof_type +']').trigger('click');

            //提交
            that.submitForm();
            //设置按钮在最底层
            setTimeout(function(){
                that.judgePageHeight();
            },0);
        });
    },
    //用户ID
    userId: getQueryString('userId'),
    //报告id
    reportId: getQueryString('reportId'),
    //手动选择省市区
    openAreaSel: function () {
        var userId = getQueryString('userId');
        // 如果当前页面有滚动条，则处理这行
        $("body").css("overflow-y", "hidden");
        $("form").hide();
        //定位数据
        var provice = $('#province').val();
        var city = $('#city').val();
        var area = $("#area").val();
        var urlStr = '../tools/region-select.html?userId=' + userId;
        if(provice || city || area){
            urlStr += '&provice=' + provice + '&city=' + city + '&area=' + area;
        }
        $("#regionSel").attr("src", urlStr).removeClass("uhide");
        setAppNewTitle( "地域选择" );
    },
    // 地图
    openMap: function () {
        var $mapSel = $("#mapSel");
        if(!$mapSel.attr('src')){
            $mapSel.attr('src','../station/map.html');
        }
        $mapSel.removeClass("uhide");
        setAppNewTitle( "地图选择" );
        // 如果当前页面有滚动条，则处理这行
        $("body").css("overflow-y", "hidden");
        $("form").hide();
    },
    // 加载页面内容需要初始化的数据
    loadPageInitDatas: function() {
        var that = this;
        // 加载屋顶类型数据
        var $roofType = $(".roof-type");
        if($roofType.length){
            var roofType = stationDatasConfig["takanConfig"]['type'];
            arrayStr = [];
            for(var p in roofType){
                if('default' != p){
                    arrayStr.push('<div value="'+p+'">'+roofType[p]+'</div>');
                }
            }
            $roofType.append(arrayStr.join(''));
            // 屋顶类型选择的点击事件
            $roofType.find("div").on('click',function(){
                var $obj = $(this);
                $obj.siblings().removeClass("selected");
                $obj.addClass("selected");
                $("#roofType").val( $obj.attr("value") );
            });
        }
    },
    // 判断底部的按钮是否处于页面的底部
    judgePageHeight: function () {
        var clientH = initParams.clientHeight;
        var htmlH = $("html").height();//alert(clientH + ',' + htmlH);
        if( htmlH<clientH ) {
            $.each( $(".steps"), function(i, step) {
                var $step = $(step);
                var $btnBlock = $step.find(".btn-block");
                if( !$step.hasClass("uhide") && !$btnBlock.hasClass("page-bottom") ) {
                    $btnBlock.addClass("page-bottom");
                }
            });
        }
    },
    //表单验证
    validForm: function(){
        var that = this;
        var province = $('#province').val(),
            city = $('#city').val(),
            area = $('#area').val();
        //报告名称
        var $proName = $("input[name='base[name]']");
        if($proName.length && '' == $.trim($proName.val())){
            that.hideTip('别忘了给您的报告起个名字哦');
            return false;
        }
        //地址验证
        if(!(province && city && area)){
            that.hideTip('请填写资源地址哦');
            return false;
        }
        if(!$("[name='base[address]']").text()){
            that.hideTip('请填写完整的地址信息哦');
            return false;
        }
        //上传图片验证
        if(!$('#img0').val()){
            that.hideTip('上传1张屋顶所在位置的卫星图全景图片');
            return false;
        }
        return true;
    },
    //提交表单
    submitForm: function(){
        var that = this;
        $('#btnSubmit').click(function(){
            var $this = $(this);
            //‘保存’按钮锁定
            var isDisabled = $this.attr('locked');
            if(!(isDisabled && '1' == isDisabled)) {
                //表单验证
                $this.attr('locked', '1');
                //表单验证
                var isPass = that.validForm();
                if (isPass) {
                    //弹出确认框
                    takanUtility.confirm({
                        popObj: $('#submitPop'),
                        cancelCallback: function(){
                            $this.attr('locked', '0');
                        },
                        confirmCallback: function(){
                            if (that.userId) {
                                //提交参数
                                var para = 'userId=' + that.userId + '&submit=1&' + $('#applyForm').serialize() + '&version=' + config.interfaceVersion;
                                var $address = $("[name='base[address]']");
                                if($address.length){
                                    para += '&base[address]=' + $address.text();
                                }
                                if(that.reportId){
                                    para += '&reportId=' + that.reportId;
                                }
                                jqueryAjaxGetJsonp(config.tkServerUrl + '/ExplorationReport/Base.json',para , function (result) {
                                    if (result.code == 2000) {
                                        window.history.go(-1);
                                    } else {
                                        that.hideTip(result.msg);
                                        $this.attr('locked', '0');
                                    }
                                }, function () {
                                    that.hideTip('网络问题，请稍后再试！');
                                    $this.attr('locked', '0');
                                });
                            } else {
                                that.hideTip('参数错误！');
                                $this.attr('locked', '0');
                            }
                        },
                        closeCallback: function(){
                            $this.attr('locked', '0');
                        }
                    });
                }else{
                    $this.attr('locked', '0');
                }
            }
        });
    },
    //点击图片上传
    uploadImg: function(){
        var that = this;
        $('body').on('click', '.per-upload img', function(){
            var $this = $(this);
            var $parent = $this.parent();
            //如果未上传图片
            if($this.attr('src') == $this.attr('oldsrc') && !$this.attr('src').match(/^http/i)){
                var index = $parent.index();
                $('.upload').attr('forIndex',index);
                $("#Filedata").trigger('click');
            }
        });
        //删除图片
        $('.per-upload').on('click','.btn-del',function(){
            var $this = $(this);
            var $popup = $(".cd-popup");
            //确认框
            takanUtility.confirm({
                popObj: $('#delImgPop'),
                confirmCallback: function(){
                    var $img = $this.siblings('img');
                    $img.attr('src',$img.attr('oldsrc'));
                    //隐藏域置空
                    $('#img'+$this.parent().index()).val('');
                    $this.remove();
                }
            });
        });
        // 图片上传时的点击事件
        $("body").on("change", "input[type='file']", function () {
            fileSize = this.files[0].size/1000;
            if(fileSize > 1024*5){
                that.hideTip('图片不得超过5M');
                return;
            }else{
                that.hideTip('上传中...',1);
            }
            if('undefind' != $('.upload').attr('forIndex')) {
                $(".upload").trigger('touchend');
            }
        });
        $(".upload").upload({
            uploadUrl: config.apiServerUrl + "/image/upload.json",
            uploadData: '',
            successFn: "success",
            deleteData: {
                id: function () {
                    return "asdfasdf"
                }
            }
        });
    },
    //弹出层 data:显示的文字；showImg:是否显示等待符
    hideTip: function(data,showImg){
        if(timer){
            clearTimeout(timer);
        }
        $loading.css("display","block");
        if(showImg){
            $mask.css('position','fixed').show();
            $loading.children('img').show();
        }else{
            $mask.hide();
            $loading.children('img').hide();
        }
        $loading.children("span").text(data);
        if(!showImg) {
            timer = setTimeout(function(){
                $loading.css("display","none");
            },2000);
        }
    },
    //删除文本框内容
    deleteInputText: function(){
        var $inputs = $('.btn-del01').prev();
        $inputs.each(function(index,element){
            var $this = $(element);
            var timer = null;
            var $thisDel = $this.next('.btn-del01');
            $this.focus(function(){
                var thisValule = $.trim($this.val());
                if($this[0].tagName.toLowerCase() == 'div'){
                    thisValule = $.trim($this.text());
                }
                if('' == thisValule){
                    if(timer){
                        clearTimeout(timer);
                    }
                    $thisDel.hide();
                }else{
                    if(timer){
                        clearTimeout(timer);
                    }
                    $thisDel.show();
                }
            }).blur(function(){
                timer = setTimeout(function(){
                    $thisDel.hide();
                    timer = null;
                },3000);
            });
            //监控变化
            $this[0].oninput = function(){
                var thisValule = $.trim($this.val());
                if($this[0].tagName.toLowerCase() == 'div'){
                    thisValule = $.trim($this.text());
                }
                if('' == thisValule){
                    $thisDel.hide();
                }else{
                    $thisDel.show();
                }
            };
        });
        //清除text中的文字
        $('.btn-del01').click(function(){
            var $this = $(this);
            var $input = $this.prev();
            if($input[0].tagName.toLowerCase() == 'div'){
                $input.text('').focus();
            }else{
                $input.val('').focus();
            }
        });
    },
    //获取当前报告信息
    getProjectInfo: function(callback){
        var that = this;
        if(that.userId && that.reportId){
            jqueryAjaxGetJsonp(config.tkServerUrl + '/ExplorationReport/GetBase.json','userId=' + that.userId + '&reportId=' + that.reportId + '&version=' + config.interfaceVersion,function(result){
                if(result.code == 2000){
                    if(callback && 'function' == typeof callback){
                        callback(result);
                    }
                }else{
                    that.hideTip(result.msg);
                }
            },function(){
                that.hideTip('网络问题，请稍后再试！');
            });
        }else{
            that.hideTip('参数错误！');
        }
    },
    //处理不规则图片，显示一致
    dealImg: function(imgUrl,$container){
        var img = new Image();
        img.src = imgUrl;
        img.onload = function(){
            var imgWidth = img.naturalWidth;
            var imgHeight = img.naturalHeight;
            if(imgWidth > imgHeight){
                $container.find("img").css({
                    //"width":"auto",
                    "height":$('.upload-imgs').width()*0.3 + 'px'
                });
            }else{
                $container.css({
                    "height":$('.upload-imgs').width()*0.3 + 'px',
                    "overflow":"hidden"
                });
            }
        };
    },
    //H5 postMessage
    receiveMessage: function (e) {
        var data = e.data;
        if(data=="returnMapVal") {
            returnMapVal() ;
        }
    },
    // 获取form表单里面的值。参数是jquery获取到的form对象
    getFormValues: function ( $form ) {
        var $inputs = $form.find("input");
        var params = "", name, value;
        $.each( $inputs, function(i, input) {
            var $input = $(input);
            name = $input.attr("name");
            value = $input.val();
            if( name&&value ) {
                params += (params?"&":"") + (name+"="+value);
            }
        });
        return encodeURI(params);
    },
    postMessage: function(){
        var that = this;
        //使用html5 的postMessage必须处理的
        if (typeof window.addEventListener != 'undefined') {
            window.addEventListener('message', that.receiveMessage, false);
        } else if (typeof window.attachEvent != 'undefined') {
            window.attachEvent('onmessage', that.receiveMessage);
        }
    }
}
//手动选择省市区--返回值
function returnAreaVal (val) {
    $("#regionSel").addClass("uhide");
    setAppNewTitle( document.title );
    // 如果当前页面有滚动条，则处理这行
    $("body").css("overflow-y", "auto");
    $("form#applyForm").show();
    var regionSelResult = eval("("+val+")");
    //regionSelResult = { "province": {"id":"", "name":""}, "city": {"id":"", "name":""}, "area": {"id":"", "name":""} }

    // TODO 用户自己的业务逻辑处理... ...
    var selCnt;
    if( regionSelResult["province"].name ) selCnt = '—' + regionSelResult["province"].name;
    if( regionSelResult["city"].name ) selCnt += '—' + regionSelResult["city"].name;
    if( regionSelResult["area"].name ) selCnt += '—' + regionSelResult["area"].name;

    var addClassName = 'dark-color';
    var $address = $("#address-h");
    if( selCnt ) {
        selCnt = selCnt;
        $address.addClass(addClassName);
    } else {
        selCnt = "您没有做任何选择";
        $address.removeClass(addClassName);
    }
    $address.html(selCnt.substring(1,selCnt.length));
    $('#province').val(regionSelResult["province"].id);
    $('#city').val(regionSelResult["city"].id);
    $('#area').val(regionSelResult["area"].id);
}
//地图返回值
function returnMapVal(val) {
    $("#mapSel").addClass("uhide");
    setAppNewTitle( document.title );
    // 如果当前页面有滚动条，则处理这行
    $("body").css("overflow-y", "auto");
    $("form#applyForm").show();
    var mapSelResult = eval("("+val+")");
    //mapSelResult = { "province": "省份", "city": "城市", "area": "地区", "detail": "具体街道", "fulladdress": "","areaCode":"区的code"}
    var selCnt = mapSelResult["province"]+ ' ' + mapSelResult["city"]+ ' '+mapSelResult["area"];
    var $provice = $('#province');
    var $city = $('#city');
    var $area = $("#area");
    var reset = 0;
    //匹配code
    if(mapSelResult["province"] && mapSelResult["city"] && mapSelResult["area"]){
        var addClassName = 'dark-color';
        var $address = $("#address-h");
        var region = mapSelResult["province"] + ',' + mapSelResult["city"] + ',' + mapSelResult["area"];
        jqueryAjaxGetJsonp(config.gfServerUrl + '/proinfo/region',getCheckParams(getQueryString('userId'),'paramsStr') + '&region=' + region + '&version=' + config.interfaceVersion, function (result) {
            if (result.code == 2000) {
                var datas = result.data;
                if(datas && datas.length > 0){
                    var selCnt = '';
                    $.each(datas,function(index,element){
                        if(0 == index){
                            $provice.val(element.region_id);
                        }else if(1 == index){
                            $city.val(element.region_id);
                        }else if(2 == index){
                            $area.val(element.region_id);
                        }
                        selCnt += element.region_name + '—';
                    });
                    $address.html(selCnt.substring(0,selCnt.length-1)).addClass(addClassName);
                }else{
                    //cod值置空
                    $provice.val("");
                    $city.val("");
                    $area.val("");
                    $address.html('请您手动选择').removeClass(addClassName);
                }
            } else {
                //cod值置空
                $provice.val("");
                $city.val("");
                $area.val("");
                $address.html('请您手动选择').removeClass(addClassName);
            }
        },function(){
            //cod值置空
            $provice.val("");
            $city.val("");
            $area.val("");
            $address.html('请您手动选择').removeClass(addClassName);
        });
    }else{
        if(!$.trim(selCnt)){
            $address.html('您没有做任何选择').removeClass(addClassName);
            //cod值置空
            $provice.val("");
            $city.val("");
            $area.val("");
        }else{
            $address.html('请您手动选择').removeClass(addClassName);
            //cod值置空
            $provice.val("");
            $city.val("");
            $area.val("");
        }
    }
    //$("input[name='base[address]']").val(mapSelResult["detail"]);
    $("[name='base[address]']").text(mapSelResult["detail"]);
}
//上传成功
function success(response, statusText, xhr, $this) {
    var that = reportName;
    that.hideTip('上传成功');
    if( statusText=='success' ) {
        var index = $('.upload').attr('forIndex');
        //操作对应的图片容器
        var $container = $('.per-upload').eq(index);
        $container.find('img').attr("src", response.data.thumbUrl_1);
        $container.append('<div class="btn-del" onclick="">&times;</div>');
        //隐藏域赋值
        $('#img'+index).val(response.data.path);
        $('.upload').removeAttr('forIndex');
        //处理不规则图片，显示一致
        that.dealImg(response.data.url,$container);
    }
}
//上传失败
function error(response, statusText, xhr, $this){
    reportName.hideTip('上传失败');
}
//页面加载完成，执行初始化方法
$(function(){
    //form表单禁止提交
    $('form').each(function(index,element){
        element.onsubmit = function(){
            return false;
        }
    });
    var that = reportName;
    //报告id
    if(that.reportId){
        that.initModify();
    }else{
        that.init();
    }
    $('.steps input[type=text],.steps input[type=number]').focus(function(){
        //设置按钮在最底层
        $('.steps:visible .btn-block').removeClass('page-bottom');
    }).blur(function(){
        that.judgePageHeight();
    });
});
