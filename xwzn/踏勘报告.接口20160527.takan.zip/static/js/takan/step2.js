/**
 * Created by wangyaru on 2016/5/3.
 * 报告命名与基本信息
 */
var fr = getQueryString('fr');
if( fr=="spick" ) {
	$("body").append("<script type='text/javascript' src='../../static/js/WebViewJavascriptBridge.js'></script>");
	$("body").append("<script type='text/javascript' src='../../static/js/jsBridgeApp.js'></script>");
	setAppNewTitle(document.title);
}
function setAppNewTitle( title ) {
	var titleObj = {
		"title": title, 
		"leftIcon":"judgeLeftIcon", 
		"rightIcon":[]
	};
    if( fr=="spick" ){
        callSetAppTitle( titleObj );
    }
}
// 左侧返回按钮的点击事件
function judgeLeftIcon() {
    var that = communication;
    $('form:visible input:focus').blur();
    takanUtility.confirm({
        popObj: $('#backPop'),
        confirmCallback: function(){
            var stepId = $('form[id^=step]:visible').attr('id');
            var para = 'submit=0' + '&' + encodeURI('owner[step]=2-'+ stepId.match(/\d+$/g)[0]);
            if('step1' == stepId || 'step2' == stepId){//第一步、第二步
                para += '&' + $('#' + stepId).serialize();
            }else if('step3' == stepId){//第三步
                para += '&' + that.getStep3FormData();
            }
            that.submitForm({
                formData: para,
                callback: function(result){
                    //返回
                    goBack();
                }
            });
        }
    });
}

var timer = null;
var $loading = $(".loading");
var $mask = $(".mask");
var communication = {
    //申请项目初始化
    init:function(){
        var that = this;
        //初始化数据
        that.loadPageInitDatas();

        //是、否事件 ==> 产权是否清晰
        that.yesOrNo();
        //联系电话
        that.validTel();

        //步骤事件
        that.stepEvent();

        //屋顶类型
        var roofType = getQueryString('roofType');
        //商业照明
        if('3' == roofType){//个人屋顶
            $('#measure').remove();
            $('#isExe').remove();
            $('#compositePriceYes').remove();
            $('#compositePriceNo').removeClass('uhide');
        }

        that.getProjectInfo(function(result){
            if(result.code == 2000){
                var info = result.data;
                //屋顶类型
                //var roofType = info.roof_type;
                //第几步
                var step = info.step.split('-')[1];
                $('#step' + step).removeClass('uhide');
                /*===============第一步数据绑定===============*/
                //产权是否清晰
                var $clear = $("input[name='owner[equity_clear]']").prev('.yes-no-bar').children('div');
                var $owner = $("input[name='owner[equity_owner]']");
                if(0 == info.equity_clear){
                    $clear.eq(1).trigger('touchend');
                    $owner.parent('li').hide();
                }else{
                    $clear.eq(0).trigger('touchend');
                    //产权所有者
                    $owner.val(info.equity_owner);
                }
                //现场联系人
                $("input[name='owner[contact]']").val(info.contact);
                //联系电话
                $("input[name='owner[phone]']").val(info.phone);
                /*===============第二步数据绑定===============*/
                //用户投资意向初始化选中
                if('' != info.investment_intent){
                    $("#listInvestment .per-step[value=" + info.investment_intent +"]").trigger('click');
                }else{
                    $("#listInvestment .per-step:first").trigger('click');
                }
                //用户电费缴纳情况初始化选中
                if('' != info.electricity_fee_payment){
                    $("#listElecticCharge .per-step[value=" + info.electricity_fee_payment +"]").trigger('click');
                }else{
                    $("#listElecticCharge .per-step:first").trigger('click');
                }
                //商业照明
                if('3' != roofType){//非个人屋顶
                    var $measure = $("input[name='owner[measure_type]']").prev('.yes-no-bar').children('div');
                    if(0 == info.measure_type){
                        $measure.eq(1).trigger('touchend');
                    }else{
                        $measure.eq(0).trigger('touchend');
                    }
                }
                /*===============第三步数据绑定===============*/
                if('3' == roofType){//个人屋顶
                    //电价
                    $("input[name='owner[electrovalence]']").val(info.electrovalence);
                    //月用电量
                    $("input[name='owner[month_electricity]']").val(info.month_electricity);
                }else{
                    //是否执行峰谷平电价
                    var $tou = $("input[name='owner[tou]']").prev('.yes-no-bar').children('div');
                    if(0 == info.tou){
                        $tou.eq(1).trigger('touchend');
                        //电价
                        $("input[name='owner[electrovalence]']").val(info.electrovalence);
                        //月用电量
                        $("input[name='owner[month_electricity]']").val(info.month_electricity);
                    }else{
                        $tou.eq(0).trigger('touchend');
                        //价格赋值
                        $("input[name='owner[peak_electrovalence]']").val(info.peak_electrovalence);
                        $("input[name='owner[cerael_electrovalence]']").val(info.cerael_electrovalence);
                        $("input[name='owner[flat_electrovalence]']").val(info.flat_electrovalence);
                        $("input[name='owner[tip_electrovalence]']").val(info.tip_electrovalence);
                        //初始化时间段
                        that.renderTimeHTML('peak',info.peak);
                        that.renderTimeHTML('cereal',info.cereal);
                        that.renderTimeHTML('flat',info.flat);
                        that.renderTimeHTML('tip',info.tip);
                        //峰谷平 尖峰时间段全局赋值
                        that.timeInterval.peak0 = info.peak ? info.peak : [];
                        that.timeInterval.cereal0 = info.cereal ? info.cereal : [];
                        that.timeInterval.flat0 = info.flat ? info.flat : [];
                        that.timeInterval.tip0 = info.tip ? info.tip : [];
                        //峰谷平 尖峰 时间点全局存储
                        that.timeInterval.peak = that.timeInterval.periodConvertToPoint(info.peak);
                        that.timeInterval.cereal = that.timeInterval.periodConvertToPoint(info.cereal);
                        that.timeInterval.flat = that.timeInterval.periodConvertToPoint(info.flat);
                        that.timeInterval.tip = that.timeInterval.periodConvertToPoint(info.tip);
                    }
                }
            }else if(result.code == 5000){//暂无数据
                //用户投资意向初始化选中
                $("#listInvestment .per-step:first").trigger('click');
                //用户电费缴纳情况初始化选中
                $("#listElecticCharge .per-step:first").trigger('click');
                //展示第一步
                $('#step1').removeClass('uhide');
            }

            //设置按钮在最底层
            setTimeout(function(){
                that.judgePageHeight();
            },0);
            //使用html5 的postMessage必须处理的
            that.postMessage();
        });
    },
    //用户ID
    userId: getQueryString('userId'),
    //报告id
    reportId: getQueryString('reportId'),
    // 加载页面内容需要初始化的数据
    loadPageInitDatas: function() {
        var that = this;
        // 加载用户投资意向数据
        var $projectStep = $('#listInvestment');
        if($projectStep.length){
            var projectStep = stationDatasConfig["takanConfig"]['investment'];
            var arrayStr = [];
            for(var p in projectStep){
                if('default' != p){
                    arrayStr.push('<div class="per-step" value="'+p+'">'+projectStep[p]+'</div>');
                }
            }
            $projectStep.append(arrayStr.join(''));
            //项目阶段事件
            $projectStep.find(".per-step").on('click',function(){
                that.chooseItem(this);
            });
        }

        // 加载用户电费缴纳情况数据
        var $electricCharge = $('#listElecticCharge');
        if($electricCharge.length){
            var electricCharge = stationDatasConfig["takanConfig"]['electricCharge'];
            arrayStr = [];
            for(var p in electricCharge){
                if('default' != p){
                    arrayStr.push('<div class="per-step" value="'+p+'">'+electricCharge[p]+'</div>');
                }
            }
            $electricCharge.append(arrayStr.join(''));
            // 屋顶材质选择的点击事件
            $electricCharge.find("div").on('click',function(){
                that.chooseItem(this);
            });
        }

        //峰谷平时间段
        var objTime = that.renderTime();

        var optionsHours = {
            lang: 'zh',
            theme: 'time-interval',
            display: 'bottom',
            headerText: '',
            setText:'完成',
            rows:5,
            invalid:[objTime.keys[1],objTime.keys[0]],
            validate: function (dw, i, time) {
                //return false;
            },
            onBeforeShow: function (dw) {
                var $this = $(this);
                var inst = $this.scroller('getInst');
                //重置时间
                inst.val = objTime.keys[0] + ' ' + objTime.keys[1];
                inst.temp = [objTime.keys[0],objTime.keys[1]];
                optionsHours.invalid = [objTime.keys[1],objTime.keys[0]];
            },
            onShow: function(dw,v){
                var $this = $(this);
                var inst = $this.scroller('getInst');
                //td中间添加文字
                $(dw).find('table td').eq(0).after('<td class="betweenText"><div>至</div></td>');
                //点击蒙版关闭
                $(dw).off('touchend','.dwo').on('touchend','.dwo',function(){
                    inst.cancel();
                });
                //不可选择设置
                if(optionsHours.invalid.length){
                    $('.dwwl0 .dw-li[data-val="' + optionsHours.invalid[0] + '"]').removeClass('dw-v');
                    $('.dwwl1 .dw-li[data-val="' + optionsHours.invalid[1] + '"]').removeClass('dw-v');
                }
            },
            onChange: function(v){
                var $this = $(this);
                var selectedValues = v.split(' ');
                optionsHours.invalid = [selectedValues[1],selectedValues[0]];
                $('.dwwl .dw-li').addClass('dw-v');
                //不可选择设置
                if(optionsHours.invalid.length){
                    $('.dwwl0 .dw-li[data-val="' + optionsHours.invalid[0] + '"]').removeClass('dw-v');
                    $('.dwwl1 .dw-li[data-val="' + optionsHours.invalid[1] + '"]').removeClass('dw-v');
                }
            },
            onSelect: function (v) {
                var $this = $(this);
                var selectedValues = v.split(' ');
                var startTime = parseInt(selectedValues[0]);
                var endTime = parseInt(selectedValues[1]);
                //对应的峰平谷、尖峰
                var range = that.timeInterval[$this.attr('for')];
                if(startTime < endTime){
                    for(var sv=startTime+0.5;sv<endTime;sv++){
                        range.push(sv);
                    }
                }else{
                    for(var sv=startTime+0.5;sv<24;sv++){
                        range.push(sv);
                    }
                    for(var sv=0.5;sv<endTime;sv++){
                        range.push(sv);
                    }
                }
                //添加时间段
                $this.parent().before('<li class="time-interval">' + that.renderCertainTime(startTime) +' 至 ' + that.renderCertainTime(endTime) +'<span class="btn-del01" data-start="'+startTime+'"  data-end="'+endTime+'">&times;</span></li>');
                //判断按钮位置
                var $step3Btn = $('#step3 .btn-block');
                if(initParams.clientHeight <= $("html").height()+$step3Btn.height()){
                    if($step3Btn.hasClass('page-bottom')){
                        $step3Btn.removeClass('page-bottom');
                    }
                }else{
                    if(!$step3Btn.hasClass('page-bottom')){
                        $step3Btn.addClass('page-bottom');
                    }
                }
                //储存提交表单需要的数据
                that.timeInterval[$this.attr('for')+'0'].push({
                    startTime:that.renderCertainTime(startTime),
                    endTime:that.renderCertainTime(endTime)
                })
                //恢复点击“添加”，弹出时间段选择
                if($this.parent().siblings('li.time-interval').length >= 3){
                    $this.scroller('destroy').off('click').on('click',function(){
                        $this.attr('hasDestroy','1');
                        takanUtility.confirm({
                            popObj: $('#maxTips')
                        });
                    });
                }
            },
            onClose: function (v,btn) {
                //点击“完成”时
                if('set' == btn){
                    var $this = $(this);
                    var selectedValues = v.split(' ');
                    var startTime = parseInt(selectedValues[0]);
                    var endTime = parseInt(selectedValues[1]);
                    //开始和结束时间是否相等
                    if(startTime == endTime){
                        takanUtility.confirm({
                            popObj: $('#startAndEndEqual')
                        });
                        return false;
                    }
                    //判断是否有重复的时间段
                    //对应的峰平谷、尖峰
                    var range = that.timeInterval[$this.attr('for')];
                    var flag = true;
                    if(range.length){
                        if(startTime < endTime){
                            for(var sv=startTime+0.5;sv<endTime && flag;sv++){
                                if('-1' != $.inArray(sv, range)){
                                    flag = false;
                                    break;
                                }
                            }
                        }else{
                            for(var sv=startTime+0.5;sv<24&&flag;sv++){
                                if('-1' != $.inArray(sv, range)){
                                    flag = false;
                                    break;
                                }
                            }
                            for(var sv=0.5;sv<endTime&&flag;sv++){
                                if(flag && '-1' != $.inArray(sv, range)){
                                    flag = false;
                                    break;
                                }
                            }
                        }
                    }
                    if(!flag){
                        takanUtility.confirm({
                            popObj: $('#repeatTips')
                        });
                    }
                    return flag;
                }
            },
            wheels:[[{
                label:'开始时间'
                ,keys: objTime.keys
                ,values: objTime.values
            },{
                label:'结束时间'
                ,keys: objTime.keys
                ,values: objTime.values
            }]]
        }
        $('.addTxt em').scroller('destroy').scroller(optionsHours);
        //删除时间段
        $('.peak').on('click','.time-interval .btn-del01',function(){
            var $this = $(this);
            var startTime = parseInt($this.attr('data-start'));
            var endTime = parseInt($this.attr('data-end'));
            var $parent = $this.parent();
            var objName = $parent.siblings('.addTxt').find('[for]').attr('for');
            var range = that.timeInterval[objName];
            var startIndex = $.inArray(startTime+0.5,range);
            if('-1' != startIndex){
                var account = endTime-startTime;
                if(account < 0){
                    account = 24-startTime+endTime;
                }
                range.splice(startIndex,account);
            }
            //删除提交表单需要的数据
            that.timeInterval[objName+'0'].splice($parent.parent().find('.time-interval').index($parent),1);
            //至多添加3个时间段
            var $add = $parent.siblings('.addTxt').find('[for]');
            if('1' == $add.attr('hasDestroy')){
                $add.off('click').scroller(optionsHours);
            }
            //删除时间段
            $parent.remove();
            //判断按钮位置
            var $step3Btn = $('#step3 .btn-block');
            if(initParams.clientHeight <= $("html").height()+$step3Btn.height()){
                if($step3Btn.hasClass('page-bottom')){
                    $step3Btn.removeClass('page-bottom');
                }
            }else{
                if(!$step3Btn.hasClass('page-bottom')){
                    $step3Btn.addClass('page-bottom');
                }
            }
        });
    },
    // 用户投资意向选择事件
    chooseItem: function (obj) {
        var $obj = $(obj);
        $obj.siblings().removeClass("selected");
        $obj.addClass("selected");
        $obj.parent().siblings('input[name]').val( $obj.attr("value") );
    },
    //生成时间对象
    renderTime: function(){
        var starHours = 0;
        var endHours = 23;
        var keys = [];
        var values = [];
        for(var i=starHours;i<=endHours;i++){
            var time = i + ':00';
            if(i<10){
                time = '0' + time;
            }
            keys.push(i);
            values.push(time);
        }
        return {keys:keys,values: values};
    },
    //峰谷平、尖峰时间段全局存储
    timeInterval: {
        peak: [],//峰
        cereal: [],//谷
        flat: [],//平
        tip: [],//尖峰
        //对应的时间段
        peak0: [],//峰
        cereal0: [],//谷
        flat0: [],//平
        tip0: [],//尖峰
        //时间段转化为时间点,时间段数组[{starTime:'01:00',endTime:'10:00'},{starTime:'01:00',endTime:'10:00'}]
        periodConvertToPoint: function(arr){
            var range = [];
            if(arr && '' != arr){
                for(var i= 0,len=arr.length;i<len;i++){
                    var obj = arr[i];
                    var startTime = parseInt(obj.startTime.match(/\d{2}(?=:00)/g)[0].replace(/^0/g,''));
                    var endTime = parseInt(obj.endTime.match(/\d{2}(?=:00)/g)[0].replace(/^0/g,''));
                    //遍历时间段
                    if(startTime < endTime){
                        for(var sv=startTime+0.5;sv<endTime;sv++){
                            range.push(sv);
                        }
                    }else{
                        for(var sv=startTime+0.5;sv<24;sv++){
                            range.push(sv);
                        }
                        for(var sv=0.5;sv<endTime;sv++){
                            range.push(sv);
                        }
                    }
                }
            }
            return range;
        }
    },
    //根据value值生成时间字符串
    renderCertainTime: function(val){
        var j = parseInt(val);
        var time = j + ':00';
        if(j<10){
            time = '0' + time;
        }
        return time;
    },
    /**
     * 修改时，初始化时间段显示
     * @param belongs string 峰谷平 尖峰名称
     * @param arr Array [{starTime:'01:00',endTime:'10:00'},{starTime:'01:00',endTime:'10:00'}]
     */
    renderTimeHTML: function(belongs,arr){
        var arrHTML = [];
        if(arr && '' != arr){
            for(var i= 0,len=arr.length;i<len;i++){
                var obj = arr[i];
                var startNumber = parseInt(obj.startTime.match(/\d{2}(?=:00)/g)[0].replace(/^0/g,''));
                var endNumber = parseInt(obj.endTime.match(/\d{2}(?=:00)/g)[0].replace(/^0/g,''));
                arrHTML.push('<li class="time-interval">' + obj.startTime +' 至 ' + obj.endTime +'<span class="btn-del01" data-start="' + startNumber +'" data-end="' + endNumber +'">×</span></li>');
            }
        }
        var $add = $('.addTxt em[for=' + belongs +']').parent();
        $add.before(arrHTML.join(''));
    },
    //是、否事件
    yesOrNo: function(){
        var that = this;
        $("body").on("touchend", ".yes-no-bar > div", function() {
            var $this = $(this);
            $this.siblings().removeClass("selected");
            $this.addClass("selected");
            //设置input的value值
            var thisValue = $.trim($this.text()) == '是' ? 1 : 0;
            var $input = $this.parent().siblings('input[name]');
            $input.val(thisValue);
            //产权是否清晰
            if('propertyRight' == $input.attr('id')){
                var $property = $this.parents('li').next('li');
                if(0 == thisValue){
                    //$property.hide().find('input[name]').val('');
                    $property.hide();
                }else if(1 == thisValue){
                    $property.show();
                }
                //设置按钮在最底层
                $('.steps:visible .btn-block').removeClass('page-bottom');
                that.judgePageHeight();
            }
            //是否执行峰谷平电价
            if('compositePrice' == $input.attr('id')){
                var $no = $('#compositePriceNo');
                var $yes = $('#compositePriceYes');
                if(0 == thisValue){
                    $no.removeClass('uhide');
                    $yes.addClass('uhide');
                }else if(1 == thisValue){
                    $no.addClass('uhide');
                    $yes.removeClass('uhide');
                }
                //设置按钮在最底层
                $('.steps:visible .btn-block').removeClass('page-bottom');
                that.judgePageHeight();
            }
        });
    },
    //联系电话验证
    validTel: function(){
        var that = this;
        $("input[name='owner[phone]']").blur(function(){
            var $this = $(this);
            var $tips = $this.parent().siblings('.error-red');
            if(!('' == $this.val() && !$this[0].validity.badInput)){
                if(that.validForm().tel($this.val())){
                    $tips.hide();
                }else{
                    $tips.show();
                }
            }else{
                $tips.hide();
            }
        });
    },
    // 判断底部的按钮是否处于页面的底部
    judgePageHeight: function () {
        var clientH = initParams.clientHeight;
        var htmlH = $("html").height();//alert(clientH + ',' + htmlH);
        if( htmlH<clientH ) {
            $.each( $('form[id^=step]'), function(i, step) {
                var $step = $(step);
                var $btnBlock = $step.find(".btn-block");
                if( !$step.hasClass("uhide") && !$btnBlock.hasClass("page-bottom") ) {
                    $btnBlock.addClass("page-bottom");
                }
            });
        }
    },
    // 总共有多少步
    totalStep: 3,
    // 页面按钮点击时，显示第n步的内容
    showStep: function ( n ) {
        var that = this;
        if( n<1 || n>that.totalStep ) return false;
        $('form[id^=step]:visible').addClass("uhide");
        $( "#step"+n ).removeClass("uhide");
        that.judgePageHeight();
        //返回顶部
        document.body.scrollTop = 0;
        //$('body,html').animate({scrollTop:0},1000);
    },
    stepEvent: function(){
        var that = this;
        //第1步 下一步
        $('#step1Next').click(function(){
            //表单验证
            if(that.validForm().step1()){
                var $this = $(this);
                var para = $('#step1').serialize() + '&submit=0' + '&' + encodeURI('owner[step]=2-1');
                that.submitForm({
                    btn: $this,
                    formData: para,
                    callback: function(result){
                        //跳转到下一步
                        that.showStep(2);
                    }
                });
            }
        });
        //第2步 上一步
        $('#step2Previous').click(function(){
            var para = 'submit=0' + '&' + encodeURI('owner[step]=2-2');
            para += '&' + $('#step2').serialize();
            that.submitForm({
                formData: para,
                callback: function(result){
                    that.showStep(1);
                }
            });
        });
        //第2步 下一步
        $('#step2Next').click(function(){
            //表单验证
            if(that.validForm().step2()){
                var $this = $(this);
                var para = $('#step2').serialize() + '&submit=0' + '&' + encodeURI('owner[step]=2-2');
                that.submitForm({
                    btn: $this,
                    formData: para,
                    callback: function(result){
                        //跳转到下一步
                        that.showStep(3);
                    }
                });
            }
        });
        //第3步 上一步
        $('#step3Previous').click(function(){
            var para = 'submit=0' + '&' + encodeURI('owner[step]=2-3');
            para += '&' + that.getStep3FormData();
            that.submitForm({
                formData: para,
                callback: function(result){
                    that.showStep(2);
                }
            });
        });
        //第3步 完成
        $('#step3next').click(function(){
            //表单验证
            if(that.validForm().step3()) {
                var $this = $(this);
                var para = 'submit=1' + '&' + encodeURI('owner[step]=2-3');
                para += '&' + that.getStep3FormData();
                that.submitForm({
                    btn: $this,
                    formData: para,
                    callback: function(result){
                        //返回到上一页
                        history.go(-1);
                    }
                });
            }
        });
    },
    //获取第三步的表单数据
    getStep3FormData: function(){
        var that = this;
        var str = '';
        //是否执行峰谷平电价
        var $compositePrice = $('#compositePrice');
        if($compositePrice.length){
            var formData = 'owner[tou]=' + $compositePrice.val();
            if('1' == $compositePrice.val()){
                //执行峰谷平电价
                //峰时间段、电价
                formData += '&owner[peak]=' + JSON.stringify(that.timeInterval.peak0)
                    + '&owner[peak_electrovalence]=' + dealPrice($("input[name='owner[peak_electrovalence]']").val());
                //谷时间段、电价
                formData += '&owner[cereal]=' + JSON.stringify(that.timeInterval.cereal0)
                    + '&owner[cerael_electrovalence]=' + dealPrice($("input[name='owner[cerael_electrovalence]']").val());
                //平时间段、电价
                formData += '&owner[flat]=' + JSON.stringify(that.timeInterval.flat0)
                    + '&owner[flat_electrovalence]=' + dealPrice($("input[name='owner[flat_electrovalence]']").val());
                //尖峰时间段、电价
                formData += '&owner[tip]=' + JSON.stringify(that.timeInterval.tip0)
                    + '&owner[tip_electrovalence]=' + dealPrice($("input[name='owner[tip_electrovalence]']").val());
            }else{
                //不执行峰谷平电价
                //电价、月用电量
                formData += '&owner[electrovalence]=' + dealPrice($("input[name='owner[electrovalence]']").val())
                    + '&owner[month_electricity]=' + $("input[name='owner[month_electricity]']").val();
            }
            str += encodeURI(formData);
        }else{
            var $electrovalence = $("input[name='owner[electrovalence]']");
            if('' == $electrovalence.val()){
                $electrovalence.val('0');
            }
            str += '&' + $('#step3').serialize();
        }
        //处理价格
        function dealPrice(price){
            var str = 0;
            if('' != price){
                str = price;
            }
            return str;
        }
        return str;
    },
    //表单验证
    validForm: function(){
        var that = this;
        return {
            step1: function () {
                //产权所有者
                if ('1' == $('#propertyRight').val() && '' == $.trim($("input[name='owner[equity_owner]']").val())) {
                    that.hideTip('请填写产权所有者');
                    return false;
                }
                //现场联系人
                if ('' == $.trim($("input[name='owner[contact]']").val())) {
                    that.hideTip('请填写现场联系人');
                    return false;
                }
                //联系电话
                var $tel = $("input[name='owner[phone]']");
                var telValue = $tel.val();
                if('' == telValue && !$tel[0].validity.badInput){
                    that.hideTip('请填写联系电话');
                    return false;
                }else{
                    if (!that.validForm().tel(telValue)) {
                        that.hideTip('请输入正确的手机号');
                        return false;
                    }
                }
                return true;
            },
            step2: function () {
                return true;
            },
            step3: function () {
                var compositePriceValue = $('#compositePrice').val();
                if('1' == compositePriceValue){
                    //执行峰谷平电价
                    var storage = that.timeInterval;
                    //峰时间段
                    if(!storage.peak.length){
                        that.hideTip('请选择峰时间段');
                        return false;
                    }
                    //峰电价
                    var $price = $("input[name='owner[peak_electrovalence]']");
                    if('' == $price.val() && !$price[0].validity.badInput){
                        that.hideTip('请填写峰电价');
                        return false;
                    }

                    //谷时间段
                    if(!storage.cereal.length){
                        that.hideTip('请选择谷时间段');
                        return false;
                    }
                    //谷电价
                    $price = $("input[name='owner[cerael_electrovalence]']");
                    if('' == $price.val() && !$price[0].validity.badInput){
                        that.hideTip('请填写谷电价');
                        return false;
                    }

                    //平时间段
                    if(!storage.flat.length){
                        that.hideTip('请选择平时间段');
                        return false;
                    }
                    //平电价
                    $price = $("input[name='owner[flat_electrovalence]']");
                    if('' == $price.val() && !$price[0].validity.badInput){
                        that.hideTip('请填写平电价');
                        return false;
                    }

                    //尖峰时间段
                    //if(!storage.tip.length){
                    //    that.hideTip('请选择尖峰时间段');
                    //    return false;
                    //}
                    //尖峰电价
                    //$price = $("input[name='owner[tip_electrovalence]']");
                    //if('' == $price.val() && !$price[0].validity.badInput){
                    //    that.hideTip('请填写尖峰电价');
                    //    return false;
                    //}
                    //峰谷平时间段重复判断
                    var noCross = true;
                    var peak = storage.peak;
                    var cereal = storage.cereal;
                    var flat = storage.flat;
                    var tip = storage.tip;
                    //峰谷对比
                    for(var i= 0,len=cereal.length;i<len && noCross;i++){
                        if('-1' != $.inArray(cereal[i],peak)){
                            noCross = false;
                            break;
                        }
                    }
                    //峰平对比
                    for(var i= 0,len=flat.length;i<len && noCross;i++){
                        if('-1' != $.inArray(flat[i],peak)){
                            noCross = false;
                            break;
                        }
                    }
                    //谷平对比
                    for(var i= 0,len=flat.length;i<len && noCross;i++){
                        if('-1' != $.inArray(flat[i],cereal)){
                            noCross = false;
                            break;
                        }
                    }
                    if(!noCross){
                        //that.hideTip('峰、谷、平时间段不能有交叉');
                        takanUtility.confirm({
                            popObj: $('#errorTips')
                        });
                        return false;
                    }

                    //尖峰在峰时间段内
                    if(storage.tip.length){
                        noCross = false;
                        for(var i= 0,len=tip.length;i<len && !noCross;i++){
                            if('-1' == $.inArray(tip[i],peak)){
                                noCross = true;
                                break;
                            }
                        }
                        if(noCross){
                            //that.hideTip('尖峰时间段必须在峰时间段内');
                            takanUtility.confirm({
                                popObj: $('#errorTips')
                            });
                            return false;
                        }
                    }
                }else{
                    //个人屋顶 或 非峰谷平电价
                    var $inputs = $("input[name='owner[electrovalence]']");
                    if('' == $inputs.val() && !$inputs[0].validity.badInput){
                        that.hideTip('请填写电价');
                        return false;
                    }
                    //月用电量
                    $inputs = $("input[name='owner[month_electricity]']");
                    if('' == $inputs.val() && !$inputs[0].validity.badInput){
                        that.hideTip('请填写月用电量');
                        return false;
                    }
                }
                return true;
            },
            tel: function(value){
                if('' == $.trim(value) || /^(13|15|18|17)\d{9}$/.test(value)){
                    return true;
                }else{
                    return false;
                }
            }
        }
    },
    //提交表单
    submitForm: function(opts){
        var that = this;
        var options = $.extend({
            btn: null,
            formData: '',
            callback: function(){}
        },opts);
        var $this = options.btn;
        //‘下一步’按钮锁定
        var isDisabled = '';
        if($this){
            isDisabled = $this.attr('locked');
        }
        if(!(isDisabled && '1' == isDisabled)) {
            if($this){
                $this.attr('locked', '1');
            }
            if (that.userId && that.reportId) {
                var para = options.formData + '&userId=' + that.userId + '&reportId=' + that.reportId + '&version=' + config.interfaceVersion;
                jqueryAjaxGetJsonp(config.tkServerUrl + '/ExplorationReport/Owner.json',para , function (result) {
                    if (result.code == 2000) {
                        if(options.callback && typeof options.callback == 'function'){
                            options.callback(result);
                        }
                    } else {
                        that.hideTip(result.msg);
                    }
                    if($this){
                        $this.attr('locked', '0');
                    }
                }, function () {
                    that.hideTip('网络问题，请稍后再试！');
                    if($this){
                        $this.attr('locked', '0');
                    }
                });
            } else {
                that.hideTip('参数错误！');
                if($this){
                    $this.attr('locked', '0');
                }
            }
        }
    },
    //弹出层 data:显示的文字；showImg:是否显示等待符
    hideTip: function(data,showImg){
        if(timer){
            clearTimeout(timer);
        }
        $loading.css("display","block");
        if(showImg){
            $mask.css('position','fixed').show();
            $loading.children('img').show();
        }else{
            $mask.hide();
            $loading.children('img').hide();
        }
        $loading.children("span").text(data);
        if(!showImg) {
            timer = setTimeout(function(){
                $loading.css("display","none");
            },2000);
        }
    },
    //删除文本框内容
    deleteInputText: function(){
        //$('.btn-del01')选择方式 后续需要修改。。。。。。。
        var $inputs = $('.btn-del01').prev();
        $inputs.each(function(index,element){
            var $this = $(element);
            var timer = null;
            var $thisDel = $this.next('.btn-del01');
            $this.focus(function(){
                var thisValule = $.trim($this.val());
                if($this[0].tagName.toLowerCase() == 'div'){
                    thisValule = $.trim($this.text());
                }
                if('' == thisValule){
                    if(timer){
                        clearTimeout(timer);
                    }
                    $thisDel.hide();
                }else{
                    if(timer){
                        clearTimeout(timer);
                    }
                    $thisDel.show();
                }
            }).blur(function(){
                timer = setTimeout(function(){
                    $thisDel.hide();
                    timer = null;
                },3000);
            });
            //监控变化
            $this[0].oninput = function(){
                var thisValule = $.trim($this.val());
                if($this[0].tagName.toLowerCase() == 'div'){
                    thisValule = $.trim($this.text());
                }
                if('' == thisValule){
                    $thisDel.hide();
                }else{
                    $thisDel.show();
                }
            };
        });
        //清除text中的文字
        $('.btn-del01').click(function(){
            var $this = $(this);
            var $input = $this.prev();
            if($input[0].tagName.toLowerCase() == 'div'){
                $input.text('').focus();
            }else{
                $input.val('').focus();
            }
        });
    },
    //获取当前项目信息
    getProjectInfo: function(callback){
        var that = this;
        if(that.userId && that.reportId){
            jqueryAjaxGetJsonp(config.tkServerUrl + '/ExplorationReport/GetOwner.json','userId=' + that.userId + '&reportId=' + that.reportId + '&version=' + config.interfaceVersion,function(result){
                if(result.code == 2000 || result.code == 5000){
                    if(callback && 'function' == typeof callback){
                        callback(result);
                    }
                }else{
                    that.hideTip(result.msg);
                }
            },function(){
                that.hideTip('网络问题，请稍后再试！');
            });
        }else{
            that.hideTip('参数错误！');
        }
    },
    //H5 postMessage
    receiveMessage: function (e) {
        var data = e.data;
        if(data=="returnMapVal") {
            returnMapVal() ;
        }
    },
    postMessage: function(){
        var that = this;
        //使用html5 的postMessage必须处理的
        if (typeof window.addEventListener != 'undefined') {
            window.addEventListener('message', that.receiveMessage, false);
        } else if (typeof window.attachEvent != 'undefined') {
            window.attachEvent('onmessage', that.receiveMessage);
        }
    }
}
//页面加载完成，执行初始化方法
$(function(){
    //form表单禁止提交
    $('form').each(function(index,element){
        element.onsubmit = function(){
            return false;
        }
    });
    var that = communication;
    that.init();
    $('.steps input[type=text],.steps input[type=number],.steps input[type=tel]').focus(function(){
        //设置按钮在最底层
        $('.steps:visible .btn-block').removeClass('page-bottom');
    }).blur(function(){
        that.judgePageHeight();
    });
});